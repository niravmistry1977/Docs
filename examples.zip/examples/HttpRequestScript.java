package com.cloakware.cspm.client;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mortbay.http.HttpContext;
import org.mortbay.http.HttpServer;
import org.mortbay.http.SocketListener;
import org.mortbay.jetty.servlet.ServletHandler;

/**
 * Very simple Jetty HTTP server+servlet to accept external GET and POST requests, to pass ALIAS
 * and BYPASSCACHE parameters to CSPMClient.class, and to return the credential from the PA client
 * (if Request Script is authorized). The server can be run as a standalone Java program or
 * embedded by another program (ex: PA client) to provide a simple web service interface. Default
 * bind address:port from command line is 127.0.0.1:12345, but can be overriden. No defaults for
 * embedded option, the embedding application can impose defaults if it chooses.
 *
 * Example URLs:
 * 
 *    http://localhost:12345/requestScript/retrieveCredentials?aliasName=sample&bypassCache=true&contentType=html
 *    http://127.0.0.1:12345/requestScript/retrieveCredentials?aliasName=sample&bypassCache=false&contentType=xml
 *    http://localhost:12345/requestScript/retrieveCredentials?aliasName=sample
 * 
 * @author justin.cranford
 */
public class HttpRequestScript extends HttpServlet {
	private static final long serialVersionUID = 1L;

    private static final String XML_HEADER_V1 = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n\n";
    private static final String CONTEXT_PATH  = "/requestScript/retrieveCredentials";

    private static boolean IS_DAEMON = false;

    private final String ALIAS_NAME = "aliasName";
	private final String BYPASS_CACHE = "bypassCache";
	private final String CONTENT_TYPE = "contentType";

	// Required by Jetty. It instantiates the class.
	public HttpRequestScript() throws Exception {
		// do nothing
	}

	// non-HttpServlet class used by main() to start the server, and prevent duplicates from starting
	public synchronized static HttpServer startServer(InetAddress bindInetAddress, int bindPort, boolean isDaemon) throws Throwable {
		if (null == bindInetAddress) {
			throw new Exception("Initialize 'inetAddress' before calling constructor.");
		} else if (-1 == bindPort) {
			throw new Exception("Initialize 'port' before calling constructor.");
		}

		HttpRequestScript.IS_DAEMON = isDaemon;
		if (HttpRequestScript.IS_DAEMON) {
			Log.info("HttpRequestScript::startServer", "Using InetAddress:Port="+bindInetAddress.getHostAddress()+":"+bindPort);	
		} else {
			System.out.println("Using InetAddress:Port="+bindInetAddress.getHostAddress()+":"+bindPort);	
		}

		// SocketListener
		SocketListener socketListener = new SocketListener();
		socketListener.setInetAddress(bindInetAddress);
		socketListener.setPort(bindPort);
		socketListener.setLingerTimeSecs(0);

		// ServletHandler
	    ServletHandler servletHandler = new ServletHandler();
	    servletHandler.addServlet(HttpRequestScript.class.getSimpleName(), HttpRequestScript.CONTEXT_PATH, HttpRequestScript.class.getCanonicalName());

	    // HttpContext
		HttpContext httpContext = new HttpContext();
		httpContext.setContextPath("/");	// only service /requestScript/retrieveCredentials
//		if (!bindInetAddress.isLoopbackAddress()) {
//			httpContext.setResourceBase(Configuration.getWhiteboxHomeDirectory());
//			httpContext.addHandler(new ResourceHandler());
//		}
		httpContext.addHandler(servletHandler);

	    // HttpServer
		HttpServer httpServer = new HttpServer();
		httpServer.addListener(socketListener);
		httpServer.addContext(httpContext);
		httpServer.start();
		return httpServer;
	}

	// HttpServlet HTTP-GET handler
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			performTask(req, resp);
		} catch(Throwable t) {
			writeMessage(resp, "text/html", "<HTML><HEAD></HEAD><BODY>Exception: " + t.getLocalizedMessage() + "</BODY></HTML>");
			t.printStackTrace();
		}
	}

	// HttpServlet HTTP-POST handler
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			performTask(req, resp);
		} catch(Throwable t) {
			writeMessage(resp, "text/html", "<HTML><HEAD></HEAD><BODY>Exception: " + t.getLocalizedMessage() + "</BODY></HTML>");
			t.printStackTrace();
		}
	}

	// private HTTP-GET or HTTP-POST handler
	private void performTask(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		long time = System.currentTimeMillis();

		String alias       = req.getParameter(ALIAS_NAME);
		String bypassCache = req.getParameter(BYPASS_CACHE);
		String contentType = req.getParameter(CONTENT_TYPE);
		if (HttpRequestScript.IS_DAEMON) {
			Log.debug("HttpRequestScript::performTask", "Received request " + req.getRequestURI()+"?"+req.getQueryString());	
			Log.debug("HttpRequestScript::performTask", "Processing request alias=" + alias + ", bypassCache=" + bypassCache + ", contentType=" + contentType);	
		} else {
			System.out.println("Received request " + req.getRequestURI()+"?"+req.getQueryString());	
			System.out.println("Processing request alias=" + alias + ", bypassCache=" + bypassCache + ", contentType=" + contentType);	
		}
		String statusCode = null;
		String userId     = null;
		try {
			if (alias != null && 0 != alias.length()) {
				CSPMClient cspmClient = (HttpRequestScript.IS_DAEMON ? new CSPMClient(true) : new CSPMClient());
				if (null == bypassCache) {
					cspmClient.retrieveCredentials(alias); 
				} else {
					cspmClient.retrieveCredentials(alias, bypassCache); 
				}
				statusCode = cspmClient.getStatusCode();
				userId = cspmClient.getUserId();

				time = (System.currentTimeMillis()-time);
				if ((null != contentType) && (contentType.equalsIgnoreCase("xml"))) {
					String message = XML_HEADER_V1 + "<C>" + statusCode + "</C><U>" + userId + "</U><P>" + cspmClient.getPassword() + "</P><T>" + time + "msec</T>";
					writeMessage(resp, "text/xml", message);
				} else {
					String message = "<HTML><HEAD></HEAD><BODY>ReturnCode=" + statusCode + "<BR>User=" + userId + "<BR>Password=" + cspmClient.getPassword() + "<BR>Time=" + time + "msec<BR></BODY></HTML>";
					writeMessage(resp, "text/html", message);
				}
				return;
			}
			writeMessage(resp, "text/html", "<HTML><HEAD></HEAD><BODY>Parameter '" + ALIAS_NAME + "' is mandatory.</BODY></HTML>");
		} finally {
			if (HttpRequestScript.IS_DAEMON) {
				Log.debug("HttpRequestScript::performTask", "Processed alias=" + alias + ", bypassCache=" + bypassCache + ", contentType=" + contentType + ", status=" + statusCode + ", userId=" + userId + ", time=" + time + "msec");	
			} else {
				System.out.println("Processed alias=" + alias + ", bypassCache=" + bypassCache + ", contentType=" + contentType + ", status=" + statusCode + ", userId=" + userId + ", time=" + time + "msec");	
			}
		}
	}

	public void writeMessage(HttpServletResponse resp, String contentType, String message) {
		PrintWriter out = null;
        try {
        	resp.setContentType(contentType);
            out = resp.getWriter();
			out.write(message, 0, message.length());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
        	if (null != out) {
                out.flush();
                out.close();
        	}
        }
	}

	/**
	 * Launch embedded HTTP server which binds to address:port=127.0.0.1:12345 by default.
	 * Optional address and port arguments on command line can override these defaults.
	 * 
	 * @param args[0] - localhost, caott-dtfac999.cpa.intra, 127.0.0.1, 192.168.1.100, 0.0.0.0
	 * @param args[1] - 1-65535
	 */
	public static void main(String[] args) throws Throwable {
		InetAddress bindInetAddress = ((null != args) && (args.length > 0) && (null != args[0]) && (0 != args[0].length()) ? InetAddress.getByName(args[0]) : InetAddress.getByName("127.0.0.1"));
		int         bindPort        = ((null != args) && (args.length > 1) && (null != args[1]) && (0 != args[1].length()) ? Integer.parseInt(args[1])      : 12345);

		HttpRequestScript.startServer(bindInetAddress, bindPort, false);
		Thread.sleep(7 * 24 * 60 * 60 * 1000);	// 1 week = 7 days = 168 hours = 10080 minutes = 604800 seconds = 604800000 milliseconds
	}
}