<?php

##########################################
#
# Php example. To execute, do:
# prompt> php test2.php
#
##########################################

$alias="test";
$bypassCacheFlag="false";

$data = getCredential($alias, $bypassCacheFlag);
echo "Return code: $data[retCode]\n";
echo "User name: $data[user]\n";
echo "Password: $data[password]\n";

function getCredential($inAlias, $inFlag){
	$exec    = "THE_CLIENT_HOME/cspmclient/bin/cspmclient";
	$command = "$exec $inAlias $inFlag";
	$hndl=popen($command, 'r') or die ("Unable to open pipe for command $command\n");

	echo "About to execute command: $command\n";
	$retVal=fread($hndl, 2096) or die ("Unable to execute command $command\n");
	$n = sscanf($retVal, "%s %s %s", $retCode, $user, $password);
	$arr=array("retCode"  => $retCode,  
	           "user"     => $user,
	           "password" => $password);
	return $arr;
} 
?> 
