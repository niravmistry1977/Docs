/* 
 * Copyright � 2008 Cloakware. All rights reserved. 
 */
package com.cloakware.cspm.sample;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cloakware.cspm.client.CSPMClient;

/**
 * Simple factory class used to create and get object references used in the 
 * web application.<br/> 
 * <br/>
 * The class can:<br/>
 * - Create a CSPMClient object<br/>
 * - Lookup the JNDI tree to find DataSources.<br/>
 */
public class ClassFactory {

	/* Datasource using CSPM technology used in the example */
	private static DataSource cspmDataSource = null;

	/* Datasource not using CSPM technology used in the example */
	private static DataSource dataSource = null;

	/* JNDI Name used to retrieve the datasource using the CSPM technology */
	private static final String DS_CSPM_JNDI_NAME = "java:comp/env/CSPMSampleDS";

	/* JNDI Name used to retrieve the datasource */
	private static final String DS_JNDI_NAME = "java:comp/env/SampleDS";

	/*
	 * Private constructor. Singleton
	 */
	private ClassFactory() {
	
	}
	
	/**
	 * This static method performs a JNDI Lookup to find the DataSource
	 * using the CSPM technology.<br/>
	 * <br/>
	 * The method throws NamingException if the JNDI Named Object cannot be 
	 * found.
	 * 
	 * @return DataSource
	 * @throws NamingException
	 */
	public static DataSource getCSPMDataSource() 
			throws NamingException {

		// if need to locate the DS
		if (cspmDataSource == null) {
			// Get the datasource using a JNDI name lookup.
			cspmDataSource = lookupDataSource(DS_CSPM_JNDI_NAME);
		}
		
		return cspmDataSource;
	}
	
	/**
	 * This static method performs a JNDI Lookup to find the DataSource
	 * <strong>NOT</strong> using the CSPM technology.<br/>
	 * <br/>
	 * The method throws NamingException if the JNDI Named Object cannot be 
	 * found.
	 * 
	 * @return DataSource
	 * @throws NamingException
	 */
	public static DataSource getDataSource() 
			throws NamingException {

		// if need to locate the DS
		if (dataSource == null) {
			
			// Get the datasource using a JNDI name lookup.
			dataSource = lookupDataSource(DS_JNDI_NAME);
		}
		
		return dataSource;
	}	
	
	/**
	 * This static method performs a JNDI Lookup to find a DataSource.<br/>
	 * <br/>
	 * The method throws NamingException if the JNDI Named Object cannot be 
	 * found.
	 * 
	 * @param jndiName jndiName to find
	 * @return DataSource
	 * @throws NamingException
	 */
	private static DataSource lookupDataSource(String jndiName) 
			throws NamingException {
		DataSource dataSource = null;
		
		Context initContext = null;
		try {
			// Create the context object.
			initContext = new InitialContext();
			
			// Get the datasource using a JNDI name lookup.
			dataSource = (DataSource) 
				initContext.lookup(jndiName);
		} finally {
			// if class was allocated.
			if (initContext != null) {
				try {
					// Close it.
					initContext.close();
				} catch (NamingException nex) {
					// Do Nothing
				}
			}
		}
		
		return dataSource;
	}	
		
	/**
	 * Create a CSPMClient object to be used by the web application. 
	 * 
	 * @return CSPMClient
	 */
	public static CSPMClient getCSPMClient() { 
		return new CSPMClient();
	}
}
