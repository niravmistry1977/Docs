/* 
 * Copyright � 2008 Cloakware. All rights reserved. 
 */

package com.cloakware.cspm.sample.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.cloakware.cspm.sample.ClassFactory;

/**
 * This servlet class is used to test the JDBC connections defined in the web
 * application. <br>
 * The class can retrieve a datasource using embedded credentials or a
 * datasource using the CSPM technology.
 * 
 */
public class ConnectionTester extends HttpServlet {

	/* Attributes used to display information in the response page */
	private final String ERROR_MSG = "errorMsg";
    private final String STATUS_MSG = "statusMsg";

    /* Parameter and attribute for response */
    private final String CSPM_ENABLE_FLD = "cspmEnabled";
     
    /* Error message */
    private final String MSG_CONNECTED = "Connected to the %s with %s.";
    private final String MSG_NOTCONNECTED = "Error Connecting to the database";
 
    /* Response page */
    private final String TARGET_JSP = "/connect.jsp";

    /* Number of connections to create. */
    final private int NUM_CONNECTIONS = 5;
    
	/**
	 * Constructor of the object.
	 */
	public ConnectionTester() {
		super();
	}

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * The method retrieves a DataSource using the Factory class and tries to 
	 * connect to the database. A checkbox allows to specify which connection
	 * should be used.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// By default, no error message
		request.removeAttribute(ERROR_MSG);

		// Retrieve the parameters
		Object cspmEnabled = request.getParameter(CSPM_ENABLE_FLD);
		
		// Set attribute used to reset the checkbox.
		request.setAttribute(CSPM_ENABLE_FLD, 
				(cspmEnabled != null) ? "checked" : null);

		Connection connection = null;
		List connections = new ArrayList();
		
		try {
			// Create a connection to the sample database.
			DataSource dataSource = cspmEnabled == null ? 
					ClassFactory.getDataSource() : 
					ClassFactory.getCSPMDataSource();
					
			for (int loop = 0; loop < NUM_CONNECTIONS; ++loop) {
				// Create the connection to the database.
				connection = dataSource.getConnection();
				if (connection != null) {
					connections.add(connection);
					
					PreparedStatement statement = connection.prepareStatement(
						"select * from TESTTBL");
					statement.executeQuery();
				} else {
		
					// return an error message.
					request.setAttribute(ERROR_MSG, MSG_NOTCONNECTED);
					
					break;
				}
			}
			
			if (connections.size() > 0) {
				Object[] arguments = {
						connection.getMetaData().getDatabaseProductName(),
						connection.getMetaData().getDriverName()
				};
				
				// return an error message.
				request.setAttribute(STATUS_MSG, 
						String.format(MSG_CONNECTED, arguments) );
			} 
		} catch (SQLException sqlEx) {
			// return an error message.
			request.setAttribute(ERROR_MSG, sqlEx.toString());
		} catch (NamingException nex) {
			// return an error message.
			request.setAttribute(ERROR_MSG, nex.toString());
		} finally {
			for (short loop = 0; loop < connections.size(); ++loop) {
				Connection conn = (Connection) connections.get(loop);
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException sqlEx) {
						// Do Nothing
					}
				}
			}
		}

		// Get the request dispatcher
		RequestDispatcher dispatcher = getServletContext()
			.getRequestDispatcher(TARGET_JSP);

		// Forward to the jsp file to display the connect page again
		dispatcher.forward(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post. The call is passed to doGet method.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// call the doGet method
		this.doGet(request, response);
	}

}
