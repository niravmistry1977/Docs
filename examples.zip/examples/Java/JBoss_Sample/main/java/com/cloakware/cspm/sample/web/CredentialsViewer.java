/* 
 * Copyright � 2008 Cloakware. All rights reserved. 
 */

package com.cloakware.cspm.sample.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cloakware.jdbc.StatusCodeMapping;
import com.cloakware.cspm.client.CSPMClient;
import com.cloakware.cspm.sample.ClassFactory;

/**
 * This servlet class is used to retrieve credentials using the 
 * CSPM Client class.<br>
 * <br>
 * The user enters a CSPM Alias Name and the servlet displays the information
 * returned by the CSPM Client class. <br>
 * <br>	
 * Since the CSPM Client class only returns a status code, the base class 
 * provides a class to convert the status code to a more meaningful sentence.  
 */
public class CredentialsViewer extends HttpServlet {
	
	/* Attribute names */
	private final String ERROR_MSG = "errorMsg";

	/* Parameter names and attributes when refreshing the page */
	private final String ALIAS_NAME = "aliasName";
	private final String BYPASS_CACHE = "byPassCache";
	
	/* Attributes used when displaying credentials/response from 
	 * the CSPM Client class.
	 */
	private final String RETURN_CODE = "returnCode";
	private final String RETURN_MSG = "returnMsg";
    private final String USERNAME = "username";
    private final String PASSWORD = "password";
    
    /* Error message */
    private final String MSG_ALIAS_EMPTY = "Alias cannot be empty";
    
    /* Response page */
    private final String TARGET_JSP = "/index.jsp";
	
	/**
	 * Constructor of the object.
	 */
	public CredentialsViewer() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		// Just puts "destroy" string in log
		super.destroy(); 
	}

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * The method retrieves the alias name and the value of the checkbox
	 * indicating if the CSPM Client cache needs to be bypassed. It then calls
	 * the retrieveCredentials method of the CSPM Client class and displays the
	 * results. <br>
	 * <br>
	 * An error message is displayed if the alias name is missing.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Retrieve the parameters
		String alias = (String)request.getParameter(ALIAS_NAME);
		Object byPassCache = request.getParameter(BYPASS_CACHE);
		
		// Make sure to redisplay the alias name. 
		request.setAttribute(ALIAS_NAME, alias);
		request.setAttribute(BYPASS_CACHE, 
				(byPassCache != null) ? "checked" : null);

		// if we have an alias
		if (alias != null && !"".equals(alias)) {
			// Class used to retrieve the credential. 
			CSPMClient cspmClient = ClassFactory.getCSPMClient();

			// Retrieve the credentials. 
			if (byPassCache == null) {
				cspmClient.retrieveCredentials(alias); 
			} else {
				cspmClient.retrieveCredentials(alias, "true"); 
			}

			// Set the credentials in the request
			request.removeAttribute(ERROR_MSG);
			request.setAttribute(RETURN_CODE, cspmClient.getStatusCode());
			String statusMsg = StatusCodeMapping
				.getStatusText(cspmClient);
			request.setAttribute(RETURN_MSG, statusMsg);
			request.setAttribute(USERNAME, cspmClient.getUserId());
			request.setAttribute(PASSWORD, cspmClient.getPassword());
		} else {
			// return an error message.
			request.setAttribute(ERROR_MSG, MSG_ALIAS_EMPTY);
			request.removeAttribute(RETURN_CODE);
		}

		// Get the request dispatcher
		RequestDispatcher dispatcher = getServletContext()
			.getRequestDispatcher(TARGET_JSP);

		// Forward to the jsp file to display the credentials
		dispatcher.forward(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post. The call is passed to the doGet method.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// call the doGet method
		this.doGet(request, response);
	}
}
