import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.TreeMap;

import com.cloakware.cspm.client.CSPMClient;

/*
 * Demonstrate concurrent execution of CSPMClient.jar or CSPMClient executable.
 *
 * Note: When using CSPMClient executable, each Java thread launches a child process, so numThread
 * exceeding number of CPUs may cause significant performance degradation of your entire system.
 * It is only safe to specify large numThreads when using CSPMClient.jar API.
 *
 * Execute pre-compiled ExampleConcurrent.class:   (java can be in the path or its path explicitly specified)
 * 
 *  a) Windows
 *    > cd %CSPM_CLIENT_HOME%\examples
 *    > java  -Djava.library.path=%CSPM_CLIENT_HOME%\lib -classpath %CSPM_CLIENT_HOME%\lib\cspmclient.jar;%CSPM_CLIENT_HOME%\lib\cwjcafips.jar ExampleConcurrent targetalias false 10 2 true
 *  b) *NIX
 *    > export CSPM_CLIENT_HOME=/opt/cloakware
 *    > cd $CSPM_CLIENT_HOME/examples/
 *    > java  -Djava.library.path=$CSPM_CLIENT_HOME/lib -classpath $CSPM_CLIENT_HOME/lib/cspmclient.jar:$CSPM_CLIENT_HOME/lib/cwjcafips.jar ExampleConcurrent targetalias false 10 2 true
 *
 * Compile:  (javac can be in the path or its path explicitly specified)
 *  a) Windows
 *    > cd %CSPM_CLIENT_HOME%\examples
 *    > javac.exe -source 1.5 -target 1.5 .\ExampleConcurrent.java
 *  b) *NIX
 *    > export CSPM_CLIENT_HOME=/opt/cloakware
 *    > cd $CSPM_CLIENT_HOME/examples/
 *    > javac -source 1.5 -target 1.5 ./ExampleConcurrent.java
 */
public class ExampleConcurrent extends Thread {
	private static final boolean IS_WINDOWS = System.getProperty("os.name").toLowerCase().startsWith("win");
	private static final String CSPM_CLIENT_HOME = ExampleConcurrent.getClientHomeEnvOrDefault();

	// application settings
	private static String TARGET_ALIAS;
	private static String BYPASS_CACHE;
	private static int NUM_THREADS;
	private static int NUM_ITERATIONS;
	private static boolean USE_CSPMCLIENT_JAVA_STUB;

	// thread settings
	private int threadNum;
	private TreeMap<String,Integer> statusCounts = new TreeMap<String,Integer>();	// sorted by key

	public ExampleConcurrent(int threadNum) {
		this.threadNum = threadNum;
	}

	/**
	 * @param args[0], target alias
	 * @param args[1], bypass cache flag
	 * @param args[2], number of iterations/thread (default: 1)
	 * @param args[3], number of threads (default: 1)
	 * @param args[4], use Java stub flag (default: true)
	 */
	public static void main(String[] args) throws Exception {
		if ((args.length < 2) || (args.length > 5)) {
			String libDir = IS_WINDOWS ? "%CSPM_CLIENT_HOME%\\lib" : "$CSPM_CLIENT_HOME/lib";
			System.out.println("Request an alias repeatedly, optionally using multiple threads");
			System.out.println("java -Djava.library.path="+libDir);
			System.out.println("     -classpath "+libDir+File.separator+"cspmclient.jar"+File.pathSeparator+libDir+File.separator+"cwjcafips.jar");
			System.out.println("     ExampleConcurrent <targetAlias> <bypassCache> [<#Iterations/Thread> [<#threads> [<useJavaStub>]]]");
			System.out.println();
			System.out.println("Where: targetAlias        - target alias to get");
			System.out.println("       bypassCache        - force getting the credential from the server");
			System.out.println("       #Iterations/Thread - # of requests each thread should make, default=1");
			System.out.println("       #threads           - # of threads to make requests (parallelization), default=1");
			System.out.println("       useStub            - Use the Java stub?");
			System.exit(256);
		}
		ExampleConcurrent.TARGET_ALIAS             = args[0];
		ExampleConcurrent.BYPASS_CACHE             = args[1];
		ExampleConcurrent.NUM_ITERATIONS           = (args.length > 2 ? Integer.parseInt(args[2]) : 1);
		ExampleConcurrent.NUM_THREADS              = (args.length > 3 ? Integer.parseInt(args[3]) : 1);
		ExampleConcurrent.USE_CSPMCLIENT_JAVA_STUB = (args.length > 4 ? args[4].equalsIgnoreCase("true") : true);
		
		long overallTime = System.currentTimeMillis();

		// launch threads and track them
		final ArrayList<ExampleConcurrent> exampleThreads = new ArrayList<ExampleConcurrent>(ExampleConcurrent.NUM_THREADS);
		for (int threadNum = 0; threadNum < ExampleConcurrent.NUM_THREADS; threadNum++) {
			ExampleConcurrent exampleConcurrent = new ExampleConcurrent(threadNum);
			exampleThreads.add(exampleConcurrent);
			exampleConcurrent.start();
		}

		// wait for each thread to complete normally, tally results
		final TreeMap<String,Integer> overallStatusCounts = new TreeMap<String,Integer>();
		for (ExampleConcurrent exampleConcurrent : exampleThreads) {
			exampleConcurrent.join();	// wait for thread to complete normally
			// add thread status counts to overall counts
			for (Entry<String, Integer> statusCodeAndCount : exampleConcurrent.statusCounts.entrySet()) {
				final String  statusCode		= statusCodeAndCount.getKey();
				final Integer threadStatusCount = statusCodeAndCount.getValue();
				final Integer overallStatusCount = overallStatusCounts.get(statusCode);
				if (null == overallStatusCount) {
					overallStatusCounts.put(statusCode, new Integer(threadStatusCount.intValue()));
				} else {
					overallStatusCounts.put(statusCode, new Integer(threadStatusCount.intValue() + overallStatusCount.intValue()));
				}
			}
		}

		// remove success count to separate from failure counts
		final Integer successStatusCount = overallStatusCounts.remove("400");
		final int numSuccesses = (null == successStatusCount ? 0 : successStatusCount.intValue());

		// format failure counts
		final StringBuilder formattedFailedCounts = new StringBuilder(100);
		for (Entry<String, Integer> statusCodeAndCount : overallStatusCounts.entrySet()) {
			final String  statusCode		 = statusCodeAndCount.getKey();
			final Integer overallStatusCount = statusCodeAndCount.getValue();
			formattedFailedCounts.append(", Failed[").append(statusCode).append("]=").append(overallStatusCount);
		}

		// print overall summary
		overallTime = System.currentTimeMillis() - overallTime;	// overall duration in msec
		final float rate = (0 == overallTime ? -1F : ExampleConcurrent.NUM_THREADS * ExampleConcurrent.NUM_ITERATIONS * 1000F / overallTime);
		System.out.println("OVERALLSUMMARY> Threads=" + ExampleConcurrent.NUM_THREADS + ", Iterations/Thread=" + ExampleConcurrent.NUM_ITERATIONS + ", Succeeded=" + numSuccesses + formattedFailedCounts + ", Time=" + overallTime + "msec, Iterations=" + rate + "/sec");
		System.exit(0);
	}

	public void run() {
		final Runtime runtime = Runtime.getRuntime();
		long threadtime = System.currentTimeMillis();
		for (int iteration = 0; iteration < ExampleConcurrent.NUM_ITERATIONS; iteration++) {
			long iterationTime = System.currentTimeMillis();
			String statusCode = "n/a";
			String userId     = "n/a";
			String password   = "n/a";
			String xmlField   = "n/a";
			if (ExampleConcurrent.USE_CSPMCLIENT_JAVA_STUB) {
				final CSPMClient cspmClient = new CSPMClient("28088", false);
				cspmClient.retrieveCredentials(ExampleConcurrent.TARGET_ALIAS, ExampleConcurrent.BYPASS_CACHE, "-x");	// PA CLIENT API CALL
				statusCode = cspmClient.getStatusCode();
				userId	   = cspmClient.getUserId();
				password   = cspmClient.getPassword();
				xmlField   = cspmClient.getXmlField();
			} else {
				InputStream is = null;
				InputStreamReader isr = null;
				BufferedReader br = null;
				try {
					String executableRelativePath = (ExampleConcurrent.IS_WINDOWS ? "\\cspmclient\\bin\\cspmclient.exe" : "/cspmclient/bin/cspmclient");
					final Process prs = runtime.exec(ExampleConcurrent.CSPM_CLIENT_HOME + executableRelativePath + " " + ExampleConcurrent.TARGET_ALIAS + " " + ExampleConcurrent.BYPASS_CACHE);
					is = prs.getInputStream();
					isr = new InputStreamReader(is);
					br = new BufferedReader(isr);
					final String line = br.readLine();
					if (line != null) {
						final String[] output = line.split("\\s+", 4);
						statusCode = (output.length >= 1 ? output[0] : "n/a");
						userId     = (output.length >= 2 ? output[1] : "n/a");
						password   = (output.length >= 3 ? output[2] : "n/a");
						xmlField   = (output.length >= 4 ? output[3] : "n/a");
					}
				} catch (Throwable t) {
					t.printStackTrace();
				} finally {
					if (null != br) {
						try {
							br.close();
						} catch (Throwable t) {
							t.printStackTrace();
						}
					}
					if (null != isr) {
						try {
							isr.close();
						} catch (Throwable t) {
							t.printStackTrace();
						}
					}
					if (null != is) {
						try {
							is.close();
						} catch (Throwable t) {
							t.printStackTrace();
						}
					}
				}
			}
			final Integer statusCount = this.statusCounts.get(statusCode);
			if (null == statusCount) {
				this.statusCounts.put(statusCode, new Integer(1));
			} else {
				this.statusCounts.put(statusCode, new Integer(1 + statusCount.intValue()));
			}
			iterationTime = System.currentTimeMillis() - iterationTime;	// duration in msec
			System.out.println("RESULT> Iteration=" + (iteration+1) + ", Thread=" + (this.threadNum+1) + ", Status=" + statusCode + ", UserId=" + userId + ", Password=" + password + ", XmlData=" + xmlField + ", Time=" + iterationTime + "msec " + (statusCode.equals("400") ? "(PASSED)" : "(FAILED)"));
		}

		// get success count
		final Integer successStatusCount = this.statusCounts.get("400");
		final int numSuccesses = (null == successStatusCount ? 0 : successStatusCount.intValue());

		// format failure counts
		final StringBuilder formattedFailedCounts = new StringBuilder(100);
		for (Entry<String, Integer> statusCodeAndCount : this.statusCounts.entrySet()) {
			final String  statusCode		= statusCodeAndCount.getKey();
			final Integer threadStatusCount = statusCodeAndCount.getValue();
			if (!statusCode.equals("400")) {
				formattedFailedCounts.append(", Failed[").append(statusCode).append("]=").append(threadStatusCount);
			}
		}

		// print thread summary
		threadtime = System.currentTimeMillis() - threadtime;	// duration in msec
		final float threadIterationRate = (0 == threadtime ? -1F : ExampleConcurrent.NUM_ITERATIONS * 1000F / threadtime);
		System.out.println("THREADSUMMARY> Thread=" + (this.threadNum+1) + ", Iterations/Thread=" + ExampleConcurrent.NUM_ITERATIONS + ", Succeeded=" + numSuccesses + formattedFailedCounts + ", Time=" + threadtime + "msec, Iterations=" + threadIterationRate + "/sec");
	}

	public static String getClientHomeEnvOrDefault() {
		String envVar = System.getenv("CSPM_CLIENT_HOME");
		
		if (null != envVar) {
			return envVar;
		}
		if (ExampleConcurrent.IS_WINDOWS) {
			return "C:\\cspm\\cloakware";	// Win x32/x64
		}
		return "/opt/cloakware";	// *NIX
	}
}
