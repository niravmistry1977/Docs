#!/usr/bin/perl -w

#use strict;

# No sourcing of environment variables requires this
if (("$^O" ne "MSWin32") && ("$^O" ne "cygwin")) {
	if (!defined($ENV{'CSPM_CLIENT_HOME'})) {
		$ENV{'CSPM_CLIENT_HOME'} = "THE_CLIENT_HOME";
	}
}

unshift(@INC,  "$ENV{'CSPM_CLIENT_HOME'}/cspmclient/lib");
require CAPAM_Client;
import CAPAM_Client;

if ("$^O" eq "cygwin") {
	$GETCR =~ s#\\#/#g;
}

my ($password, $rc, $userid, $argv);

my $msg="";
my $bypass_cache = "";
my $alias = "";
my $isXMLOutput = 0;

foreach $argv (@ARGV){
	if($argv eq "-x"){
		$isXMLOutput = 1;
	}   
}
# $GETCR = "GET CRedentials" ; defined in the CSPM_CLIENT.pm
# it is the main and only call when using Perl to retrieve
# the userid and password from the Xsuite/PA Server

my $command = qq{$GETCR @ARGV};
my $answer = `$command`;

if ($isXMLOutput) {
	print qq($answer\n);
} else {
	my @array = split(/\s+/, $answer);
	print qq(Return Code: $array[0]\n);
	print qq(UserID:	  $array[1]\n);
	print qq(Password:	$array[2]\n); 

	if ($array[0] ne "400" ) {
	  	for my $i (3..$#array){
			$msg = $msg." ".$array[$i];
	  	}
	  	print qq(Message: $msg\n);
	} else {
	  	print qq(PASSED\n);	  			   
	}
}

__END__
