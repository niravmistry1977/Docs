<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.targetAliasBox = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Command1 = New System.Windows.Forms.Button
        Me.BypassCache = New System.Windows.Forms.CheckBox
        Me.XMLOutput = New System.Windows.Forms.CheckBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'targetAliasBox
        '
        Me.targetAliasBox.Location = New System.Drawing.Point(35, 50)
        Me.targetAliasBox.Name = "targetAliasBox"
        Me.targetAliasBox.Size = New System.Drawing.Size(207, 20)
        Me.targetAliasBox.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(32, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Enter Target Alias:"
        '
        'Command1
        '
        Me.Command1.Location = New System.Drawing.Point(127, 125)
        Me.Command1.Name = "Command1"
        Me.Command1.Size = New System.Drawing.Size(103, 23)
        Me.Command1.TabIndex = 4
        Me.Command1.Text = "Get Credentials"
        Me.Command1.UseVisualStyleBackColor = True
        '
        'BypassCache
        '
        Me.BypassCache.AutoSize = True
        Me.BypassCache.Location = New System.Drawing.Point(35, 96)
        Me.BypassCache.Name = "BypassCache"
        Me.BypassCache.Size = New System.Drawing.Size(94, 17)
        Me.BypassCache.TabIndex = 5
        Me.BypassCache.Text = "Bypass Cache"
        Me.BypassCache.UseVisualStyleBackColor = True
        '
        'XMLOutput
        '
        Me.XMLOutput.AutoSize = True
        Me.XMLOutput.Location = New System.Drawing.Point(150, 96)
        Me.XMLOutput.Name = "XMLOutput"
        Me.XMLOutput.Size = New System.Drawing.Size(83, 17)
        Me.XMLOutput.TabIndex = 6
        Me.XMLOutput.Text = "XML Output"
        Me.XMLOutput.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Command1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(255, 177)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(292, 236)
        Me.Controls.Add(Me.XMLOutput)
        Me.Controls.Add(Me.BypassCache)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.targetAliasBox)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "CPA Client 64-bit VB Sample"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents targetAliasBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Public WithEvents Command1 As System.Windows.Forms.Button
    Friend WithEvents BypassCache As System.Windows.Forms.CheckBox
    Friend WithEvents XMLOutput As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox

End Class
