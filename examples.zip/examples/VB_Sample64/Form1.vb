Imports System
Imports System.Text
Imports Microsoft.VisualBasic

Public Class Form1


    Private Sub Command1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Command1.Click
        Dim x As New Cspmclientc64.ccspmclientc64
        Dim ret As Integer
        Dim userId As String
        Dim password As String
        Dim xmlData As String
        Dim targetAlias As String
        Dim bypassCache As String
        Dim cliOpt As String
        Dim isXMLOutput As Boolean
        Dim message As String
        Dim size As Long = 0
        Dim bytes(256) As Byte


        bypassCache = "false"
        cliOpt = ""
        targetAlias = Me.targetAliasBox.Text

        If (Me.BypassCache.Checked) Then
            bypassCache = "true"
        End If

        If (Me.XMLOutput.Checked) Then
            cliOpt = "-x"
            isXMLOutput = True
        End If
        ret = x.retrieveCredentials(targetAlias, bypassCache, cliOpt)

        If (isXMLOutput) Then
            xmlData = x.getUtf16XML()
            MsgBox("XML Data = " & xmlData)
        ElseIf (ret = 400) Then
            userId = x.getUtf16UserId()
            password = x.getPassword()

            MsgBox("password = " & password & ", userId=" & userId)

        Else
            message = x.getMessage()
            MsgBox("Failed to process request with errorCode: " & CStr(ret) & ", message: " & x.getMessage())
        End If

    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub XMLButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Cache_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BypassCache.CheckedChanged

    End Sub

    Private Sub XML_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles XMLOutput.CheckedChanged

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class
