#!/usr/bin/env python

import os,time
import sys

def getCredential(alias, getFromServer, displayXml):
	cspmClientHome = os.getenv('CSPM_CLIENT_HOME')
	if cspmClientHome == None:
		cspmClientHome="THE_CLIENT_HOME"

	cmd = cspmClientHome+"/cspmclient/bin/cspmclient" +" "+ alias+" "+getFromServer+" "+displayXml

	f=os.popen(cmd)
	retVal= f.read()
	print(retVal)

if __name__ == "__main__": 
	nArgs =  len(sys.argv)

	if nArgs == 1:
		print("Usage: "+sys.argv[0]+" <alias> [true|false] [-x]")
		sys.exit()

	nArgs = nArgs - 1
	alias=""
	getFromServer=""
	displayXml=""

	alias=sys.argv[1]
	if (nArgs == 2) and (nArgs != "-x"):
		getFromServer = sys.argv[2]
	elif (nArgs == 2) and (nArgs == "-x"):
		displayXml = sys.argv[2]
	elif (nArgs == 3):
		displayXml = sys.argv[3] 

	getCredential(alias, getFromServer, displayXml)
