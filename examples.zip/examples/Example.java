import com.cloakware.cspm.client.CSPMClient;

/*
 * An example class to demonstrate calling the CSPMClient class to retrieve credentials
 * with support for all CSPMClient constructor and retrieveCredentials method overloads.
 *
 * Notes:
 * FIPS mode is enabled by default between the client application and the client daemon.
 * It can be disabled by either:
 * 1. Adding the line '<enablefips>false</enablefips>' to $CSPM_CLIENT_HOME/cspmclient/config/cspm_client_config.xml
 * 2. Specifying the daemon's port# and 'noFips' arguments to invoke the CSPMClient(port#, false) contructor
 * 
 * If FIPS mode is enabled between the 'stub' and the client daemon,
 * you will need to ensure that the library path to the PA library directory
 * is set by one of the following methods:
 *
 * a. Adding $CSPM_CLIENT_HOME/cspmclient/lib to LD_LIBRARY_PATH/LIBPATH
 * b. Passing the following option on the java command line:
 *	  -Djava.library.path=$CSPM_CLIENT_HOME/cspmclient/lib
 */
public class Example {
	/**
	 * Main entry point. See usage() for command line parameters or run with no parameters specified.
	 *
	 * @return int 0 if successful, 100 if an exception occurred, otherwise
	 *         documented error codes for the CSPMClient class.
	 */
	public static void main(String[] args) {
		boolean useSwDefaultForFips = true;   // Use the software default to determine whether to use FIPS or not
		boolean enableFips = false;           // Use FIPS? (only applicable if !useSwDefaultForFips
		String bypassCache = null;            // Should client cache be bypassed (boolean string) or null to use client's default
		boolean verbose = false;              // Display verbose logging of what is being done
		String daemonPortN = null;            // port the daemon is listening on
		String outputXML = "";                // output XML?

		try {
			//check the arguments
			if (args.length < 1) {
				System.err.println("Missing argument: <targetAlias>");
				System.out.println();
				usage();
				System.exit(256);
			}

			// get arguments from the command line
			String targetAlias = args[0];

			if (args.length > 1) {
				for (int i = 1; i < args.length; i++) {
					String arg = args[i].toUpperCase();
					if (arg.endsWith("FIPS")) {
						useSwDefaultForFips = false;
						enableFips = !arg.startsWith("NO");
					} else if (arg.equals("VERBOSE"))
						verbose = true;
					else if (arg.equals("XML") || arg.equals("-X"))
						outputXML = "-x";
					else if (arg.equals("TRUE") || arg.equals("FALSE") ||
					         arg.endsWith("BYPASSCACHE"))
						bypassCache = arg.endsWith("BYPASSCACHE")
						               ? Boolean.toString(arg.startsWith("NO"))
						               : args[i];
					else try {
						Integer.parseInt(arg);
						daemonPortN = arg;
					} catch (NumberFormatException e) {
						System.err.println("Unsupported argument "+arg);
					}
				}
			}

			if (!useSwDefaultForFips && (daemonPortN == null)) {
				System.err.println("daemon's port# must be specified if FIPS mode specified");
				System.out.println();
				usage();
				System.exit(256);
			}
			
			CSPMClient testInterface = null;
			if (verbose)
				System.out.println("Connecting to client daemon using default constructor");
			testInterface = new CSPMClient();

			if (bypassCache == null) {
				if (verbose)
					System.out.println("Retrieving credentials with no value for bypassCache");
				testInterface.retrieveCredentials(targetAlias);
			} else {
				if (verbose)
					System.out.println("Retrieving credentials "+(bypassCache == "false" ? "not" : "") +" bypassing the client cache"+(!outputXML.isEmpty() ? " displaying raw XML ("+outputXML+")" : ""));
				testInterface.retrieveCredentials(targetAlias, bypassCache, outputXML);
			}

			// get the result
			String statusCode = testInterface.getStatusCode();

			System.out.println("Status Code: " + statusCode);

			//set the return value
			if (statusCode.equals("400")) {
				System.out.println("UsedId:	     " + testInterface.getUserId());
				System.out.println("Password:    " + testInterface.getPassword());
				if (!outputXML.isEmpty())
					System.out.println("XML:        "+testInterface.getXMLData());
				System.exit(0);
			} else {
				System.out.println("FAILED");
				if (!outputXML.isEmpty())
					System.out.println("XML:        "+testInterface.getXMLData());
				System.exit(Integer.parseInt(statusCode));
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(100);
		}
	}

	/**
	 * Display usage information to STDOUT
	*/
	public static void usage() {
		System.out.println("Retrieve the credentials from the server identified by the given alias");
		System.out.println();
		System.out.println("Usage: <targetAlias> [true|false|[no]bypassCache] [[no]daemon|[<port#>] [[no]fips]] [xml|-x] [verbose]");
		System.out.println();
		System.out.println("Where: targetAlias = target alias (case-sensitive)");
		System.out.println("       bypassCache = bypass the client cache (prefix with 'no' to not bypass the");
		System.out.println("                     client's cache");
		System.out.println("                     Default is to use the software default");
		System.out.println("       standalone  = Use the CSPMClient(isDaemon) constructor");
		System.out.println("       port#       = connect to daemon listening on given port#");
		System.out.println("                     Use the CSPMClient(port#) constructor");
		System.out.println("       fips        = enable FIPS (prefix with 'no' to not use FIPS");
		System.out.println("                     Default is to use the software default");
		System.out.println("                     Use the CSPMClient(port#, fips) constructor");
		System.out.println("       xml         = output raw XML");
		System.out.println("       verbose     = display messages specifying what is being done");
		System.out.println();
		System.out.println("Notes:");
		System.out.println("- keywords are NOT case sensitive");
		System.out.println("- keywords may be specified in any order");
		System.out.println("- if FIPS mode (<enablefips>false</enablefips> not specified in cspm_client_config.xml & ");
		System.out.println("  noFips not specified as a parameter, '-Djava.library.path=$CSPM_CLIENT_HOME/cspmclient/lib must");
		System.out.println("  be specified in JVM invocation");
	}
}
