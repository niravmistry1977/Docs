// VC_Sample.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include <afxwin.h>
#include <atlbase.h>
#include <fcntl.h>
#include <io.h>
#include <Strsafe.h>
#include "stdafx.h"


#import "c:\cspm\cloakware\cspmclient\lib\cspmclientc.tlb"

#define ERROR_CODE_SUCCESS	400
#define ERROR_CODE_BADPARAM	407

int doTheWork(int argc, char* argv[])
{
	USES_CONVERSION;
		
	_bstr_t targetAlias = _bstr_t("sample");
	_bstr_t bypassFlg = _bstr_t("false");
	_bstr_t bstrUserId, bstrPassword, bstrXMLData, bstrMessage;	
	_bstr_t cliOpt = _bstr_t("");
	TCHAR* userId;
	TCHAR* password;
	TCHAR* xmlData;
	TCHAR* message;
	TCHAR *szTmp;
	BOOL isXMLOutput = FALSE;
	HRESULT hr;
	CLSID cls;


    using namespace Cspmclientc;


    if(argc>1) 
	{
  		targetAlias = _bstr_t(argv[1]);		
		
		for (int pos = 2; pos < argc; pos++){ 
			if(pos == 2 && argv[pos][0] != '-'){
					bypassFlg = _bstr_t(argv[pos]);
			}else{							
				if(!strcmp(argv[pos],"-x"))
					isXMLOutput = TRUE;
				cliOpt = cliOpt+ " "+_bstr_t(argv[pos]);
			}
		}		
		
		// Intializing the com component
		
		hr = CLSIDFromProgID(OLESTR("cspmclientc.ccspmclientc"), &cls);
		
		Iccspmclientc *t;
		
		hr = CoCreateInstance(cls,NULL,CLSCTX_INPROC_SERVER, __uuidof(Iccspmclientc),(LPVOID *) &t);
     
	//	printf("Retrieving credentials for %s\n",(char* )targetAlias);	
		int retVal = -1;
		retVal = t->retrieveCredentials(targetAlias,bypassFlg,cliOpt); //call method
	
		if(isXMLOutput){
			bstrXMLData = t->getUtf16XML();//getXMLData();
			xmlData = OLE2T(bstrXMLData);

			if( strcmp("-m", argv[argc-1]) == 0)
				MessageBoxW( NULL, (LPCWSTR)xmlData, (LPCWSTR)L"XML_DATA", MB_OK );
			wprintf(L"Block data: %s\n", xmlData);
			SysFreeString(bstrXMLData);

		}else if(retVal==ERROR_CODE_SUCCESS){
			unsigned char cTitle[256];
			unsigned char cOut[1024];

			bstrUserId = t->getUtf16UserId();//getUserId();
			bstrPassword = t->getPassword();
			userId = OLE2T(bstrUserId);
			password= OLE2T(bstrPassword);
			
			memset( cOut, 0, sizeof(cOut) );
			StringCbPrintfW( (STRSAFE_LPWSTR)cOut, sizeof(cOut),
				             (STRSAFE_LPWSTR)L"ErrorCode: %d\nUserId: %s\nPassword: %s\n",
							 retVal, userId, password );
			
			memset( cTitle, 0, sizeof(cTitle) );
			StringCbPrintfW( (STRSAFE_LPWSTR)cTitle, sizeof(cTitle), (STRSAFE_LPWSTR)L"PA User: %s", userId );
			
			if( strcmp("-m", argv[argc-1]) == 0)
				MessageBoxW( NULL, (LPCWSTR)cOut, (LPCWSTR)cTitle, MB_OK );
			
			wprintf(L"%s\n", cOut );

			SysFreeString(bstrUserId);
			SysFreeString(bstrPassword);

		}else{
		  
		  bstrMessage = t->getMessage();
		  message = OLE2T(bstrMessage);
		  wprintf(L"ErrorCode: %d\n",retVal);
  		  wprintf(L"UserID: %s\n", L"null");
		  wprintf(L"Password: %s\n", L"null");
		  SysFreeString(bstrMessage);
		}

		t->Release(); 
		  
	}else{
		wprintf(L"ErrorCode: %d\n",ERROR_CODE_BADPARAM);
  		wprintf(L"UserID: %s\n", L"null");
		wprintf(L"Password: %s\n", L"null");
    }
	return 0;
}

int main(int argc, char* argv[])
{
	if( argc == 1 )
	{
		wprintf( L"Usage:	VC_Sample <alias> <true> <-x>\n" );
		return -1;
	}

	_setmode(_fileno(stdout), _O_U16TEXT);

	CoInitialize(NULL);

	doTheWork( argc,  argv );

	CoUninitialize();
	return 0;
}

