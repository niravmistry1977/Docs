/*
    This example is valid for both C and C++ integration.
    
    The path to the binary client depends on the CSPM_CLIENT_HOME being set
    and is: "CSPM_CLIENT_HOME/cspmclient/bin/cspmclient"
    
    - argv[1] is mandatory - provides the Target Alias name
    
    - argv[2] is optional  - provides the Bypass Cache Flag which can be "true"
      or "false"; defaults to "false".
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define CSPM_CLIENT_BINARY "/cspmclient/bin/cspmclient"
#define BUF_SIZE 256

int main (int argc, char **argv) 
{
    FILE *results_file;
    
    /* Declarations, Allocations & Initializations */
    
    int error = 0;
    
    char *cspm_client_home, *return_code, *userid, *password;

    char a_buffer[BUF_SIZE];    
    char command[BUF_SIZE];
    char bypass_cache_flag[BUF_SIZE];

    memset(a_buffer,'\0',BUF_SIZE);
    memset(command,'\0',BUF_SIZE);
    memset(bypass_cache_flag,'\0',BUF_SIZE);    

    /* Validate Command Line Arguments */

    if ( argv[1] == NULL ) {
        printf("\nERROR: arg[1] cannot be NULL\n\n");
        exit(1);
    }
        
    if ( argv[2] == NULL ) {
        printf("\nNo Bypass Cache Flag provided - will use the default\n");
        sprintf(bypass_cache_flag, "%s", "false");   
    } else {
        sprintf(bypass_cache_flag, "%s", argv[2]);    
    }

    /* Get the CSPM_CLIENT_HOME */
    
    
    /* Set environment variables if not set  */
    setenv("CSPM_CLIENT_HOME", "THE_CLIENT_HOME", 0);
    setenv("LD_LIBRARY_PATH", "THE_CLIENT_HOME/cspmclient/lib", 0);
    
    cspm_client_home=getenv("CSPM_CLIENT_HOME");
    
    if ( cspm_client_home == NULL ) {
        printf("\nGlobal Environment Variable CSPM_CLIENT_HOME is not set\n");
        exit(1);
    }
     
    /*
    Command Line Creation    
    NOTE: No space in the format string for the first 2 list elements - %s%s
    */

    sprintf(command, BUF_SIZE,
            "%s%s %s %s",
            cspm_client_home,
            CSPM_CLIENT_BINARY,           
            argv[1],
            bypass_cache_flag
            );

    /* We will be using a popen call to execute but also to retrieve
    the standard output returned by the client execution */
    
    results_file = popen(command, "r");

    while ( fgets(a_buffer,BUF_SIZE,results_file) != NULL ) {

        /* Parse the output to retrive the fields we are interested in */
        
        if( (return_code = (char *) strtok(a_buffer," ")) != NULL ) {
            if ( (userid = (char *) strtok(NULL," ")) != NULL ) {
                if ( (password = (char *) strtok(NULL," ")) == NULL )
                    error = 1;
                }
            else
                error = 1;
        }
        else
            error = 1;           
    }
    
    pclose(results_file);    

    /* Print results */
    
    if ( error ) {
        printf("\nFailed to retrieve the credentials\n");
        exit(99);
    } else {
        printf("\nreturn_code:\t%s\n",return_code);
        printf("userid:\t\t%s\n",userid);        
        printf("password:\t%s\n",password);
    }

}
