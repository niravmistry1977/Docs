###########################################################################################
# ADImport - Import Centrify Data into AD
#
#
# Author       : Fabrice Viguier
# Contact      : fabrice.viguier AT centrify.com
# First release: 17/09/2012 
#
###########################################################################################

 DISCLAIMER:
 -----------

 Note that this script is used by Centrify Professional Services to help customers migrate from Unix to Active Directory by importing Centrify data in AD.
 This script is NOT supported by Centrify Support, but when delivered during an engagement is supported by Professional Services themselves for up to 60 days after end of the engagement (as stated in Statement of Work).
 This script SHOULD NOT be used in production environment to fulfil Centrify data management on a day-to-day basis. Instead this steps should be be covered by using directly the Centrify.DirectControl.PowerShell Cmdlets, in specifically written scripts, or called by external means (e.g. IAM solutions or Web Portal). 


 HOW TO USE:
 -----------
 
 Information about usage of the script can be found by running help command, the script is provided with SYNOPSIS details.
 
	PS D:\PSScripts\ADImport> man .\ADimport.ps1

	or
	
	PS D:\PSScripts\ADImport> Get-Help .\ADimport.ps1

	or
	
	PS D:\PSScripts\ADImport> .\ADimport.ps1 -Help
	
 
 To have a look on changes history just edit the script with your preferred script or text editor.