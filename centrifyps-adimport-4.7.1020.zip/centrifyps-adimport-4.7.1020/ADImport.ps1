###############################################################################################################
# ADImport - Import Centrify Data into AD
#
# DISCLAIMER   : Note that this script is used by Centrify Professionnal Services to help customers migrate 
#                from Unix to Active Directory by importing Centrify data in AD. This script is NOT supported 
#                by Centrify Support, but when delivered during an engagement is supported by Professional 
#                Services themselves for up to 60 days after end of the engagement (as stated in Statement of 
#                Work). This script SHOULD NOT be used in production environment to fulfill Centrify data 
#                management on a day-to-day basis. Instead this steps should be be covered by using directly 
#                the Centrify.DirectControl.PowerShell Cmdlets, in specifically written scripts, or called by 
#                external means (e.g. IAM solutions or Web Portal). 
#
# Author       : Fabrice Viguier
# Contact      : fabrice.viguier AT centrify.com
# Release      : 17/09/2012
# Version      : Git repository https://bitbucket.org/centrifyps/adimport
###############################################################################################################

<#
.SYNOPSIS
Import Centrify Data in Centrify Zones into target Active Directory from a collection of CSV files.

.DESCRIPTION
This script is intend to import Centrify data in Centrify Zones. The script take a list of UNIX data from CSV formated files.
The CSV files are provide in a given structures that this script analyze and present as a menu. You can import data by chosing which kind of UNIX data to import by giving the appropriate parameter.
By default operations are done with current logon account on the current system joined Active Directory domain.
It's possible to specify AD account user name to connect to AD with alternative credential (e.g. NTDOMAIN\Administrator). It's also possible to specify a target AD domain by giving FQDN path of the domain (e.g. company.com).

DISCLAIMER:
Note that this script is used by Centrify Professionnal Services to help customers migrate from Unix to Active Directory by importing Centrify data in AD.
This script is NOT supported by Centrify Support, but when delivered during an engagement is supported by Professional Services themselves for up to 60 days after end of the engagement (as stated in Statement of Work).
This script SHOULD NOT be used in production environment to fulfill Centrify data management on a day-to-day basis. Instead this steps should be be covered by using directly the Centrify.DirectControl.PowerShell Cmdlets, in specifically written scripts, or called by external means (e.g. IAM solutions or Web Portal). 

.PARAMETER Domain
Specify the AD Domain name where perform actions in FQDN format (e.g. company.com). 

.PARAMETER Credential
Specify the PSCredential of an AD User to perform actions on AD (e.g. (Get-Credential NTDOMAIN\Administrator)).

.PARAMETER Zones
 Specify the CSV File to import Zones.
 The CSV File format should be as below:

 Name,Container,Description,IsOU,Parent

 Name          Name of the zone.
 Container     Container in which to create the zone. This can be ignored if Parent Zone is specified and the Child Zone should be created under his Parent Zone.
 Description   Description of the new zone.
 IsOU          If you specify this parameter, the zone is created as an organizational unit (OU). Otherwise, it is created as a container object.  
 Parent        The parent zone of the new zone, if any. Specify an empty string if there is no parent zone. 

.PARAMETER Computers
 Specify the CSV File to import and prepare Computers into Zones.
 The CSV File format should be as below:

 Hostname,Zone,Container

 Hostname     The name of the computer.
 Zone         The zone to which the computer is added. You can specify either the Zone name or a distinguished name for this parameter.
 Container    The Active Directory container in which the AD computer is to be created. Specify this parameter only if you are creating a new Active Directory computer.

.PARAMETER Users
 Specify the CSV File to import Unix User profiles into Zones and/or as Computer overrides.
 The CSV File format should be as below:

 Zone,User,UnixName,UID,GID,Gecos,Home,Shell

 Zone       The zone for which to create the UNIX profile. You can specify either the Zone name or a distinguished name for this parameter.
            Alternatively you can specify a managed computer for which to create the UNIX profile. You can specify either a CdmManagedComputer object or any of the following values for the Active Directory computer:
               - distinguishedName
               - SID
               - samAccountName
 User      The Active Directory user for which you are adding a UNIX user profile. You may specify any of the following values for this parameter:
               - distinguishedName
               - SID
               - samAccountName
               - <samAccountName>@<domain>
 UnixName   The UNIX login name for the user associated with the profile.
 UID        The UID of the user associated with the UNIX profile.
 GID        The group ID (GID) of the primary group of the user associated with the UNIX profile.
 Gecos      The GECOS field of the user UNIX profile.  Use this parameter for hierarchical zones only.
 Home       Default home directory of the user associated with the UNIX profile.
 Shell      The default shell of the user associated with the UNIX profile.

.PARAMETER Groups
 Specify the CSV File to import Unix Group profiles into Zones and/or as Computer overrides.
 The CSV File format should be as below:

 Zone,Group,UnixName,GID,Members

 Zone       The zone for which to create the UNIX profile. You can specify either the Zone name or a distinguished name for this parameter.
            Alternatively you can specify a managed computer for which to create the UNIX profile. You can specify either a CdmManagedComputer object or any of the following values for the Active Directory computer:
               - distinguishedName
               - SID
               - samAccountName
 Group      The Active Directory group for which you are adding a UNIX group profile. You may specify any of the following values for this parameter:
               - distinguishedName
               - SID
               - samAccountName
               - <samAccountName>@<domain>
 Container  The AD Container where to create the Active Directory group to associate to the UNIX group profile.
 UnixName   Name of the UNIX group profile.
 GID        The GID of the group UNIX profile.
 Members    List of Unix Names members of the Unix secondary group (as members are comma separeted this vallue MUST be enclosed with "" (double quotes))

.PARAMETER RolesAndRights
 Specify the CSV File to import Roles and Rights into Zones.
 The CSV File format should be as below:

 Zone,RoleName,RoleAuditLevel,RoleDescription,UnixSysRights,RoleHasRescueRight,RoleAllowLocalUser,PamName,PamDescription,PamApplication,CommandName,CommandDescription,CommandPattern,CommandPatternType,CommandMatchPath,CommandPriority,CommandDzshRunAs,CommandDzdoRunAsUser,CommandDzdoRunAsGroup,CommandKeepVar,CommandDeleteVar,CommandAddVar,CommandAuthentication

 Zone                    The zone in which to create the role. You can specify either the Zone name or a distinguished name for this parameter.
 RoleName                The name of the role.
 RoleDescription         Description of the role. 
 RoleAuditLevel          Audit setting for this role.  You may specify any one of the following values:
                            - no            Audit not requested/required
                            - possible      Audit if possible
                            - required      Audit required
 UnixSysRights           UNIX system rights granted to the role.  You can specify any combination of the following rights:
                            - login         Password login and non-password (SSO) login are allowed
                            - ssologin      Non-password (SSO) login is allowed
                            - disableacc    Account disabled in Active Directory can be used by sudo, cron, etc.
                            - nondzsh       Login with non-restricted shell
                         separate values with comma to specify more than one values, e.g. for default "UNIX Login" Role: "login,ssologin,nondzsh"
 RoleHasRescueRight      Determines whether this role has the rescue system right. If true, this role can operate without being audited in case of audit system failure.
 RoleAllowLocalUser      Determines whether local users can be assigned this role. If true, local users can be assigned this role.
 PamName                 The name of the PAM access right.
 PamDescription          Description of the PAM access right.
 PamApplication          The PAM application.
 CommandName             The name of the command right.
 CommandDescription      Description of the command right.
 CommandPattern          The pattern to match when looking for the command.
 CommandPatternType      The type of the command-matching pattern.  You may specify one of the following values:
                            - glob      Glob expression
                            - regexp    Regular expression
 CommandMatchPath        The path to use when matching the command.  You can specify one of the following values:
                            - "USERPATH"     		Standard user path
                            - "SYSTEMPATH"   		Standard system path
                            - "SYSTEMSEARCHPATH"	System search path
                            - Other strings		Custom specific path
 CommandPriority         The priority of the command.
 CommandDzshRunAs        The user this command runs under when using dzsh. You can specify one of the following values:
                            - "$"            run as current user
                            - ""             this command cannot be run in dzsh
                            - Other string   a specific user
 CommandDzdoRunAsUser    Users allowed to run this command using dzdo. Specify a comma-separated list, or specify one of the following values:
                            - "*"  can run as any user enabled for the zone
                            -  ""   cannot run as any user
                         Note: If you specify empty strings for both parameters DzdoRunAsUser and DzdoRunAsGroup, then this command cannot be run using dzdo.
 CommandDzdoRunAsGroup   Groups allowed to run this command using dzdo. Specify a comma-separated list, or specify one of the following values:
                            - "*"  can run as any group enabled for the zone
                            - ""   cannot run as any group
                         Note: If you specify empty strings for both parameters DzdoRunAsUser and DzdoRunAsGroup, then this command cannot be run using dzdo.
 CommandKeepVar          Environment variables to keep when dzdo is run. The dzdo.env_keep configuration parameter in the centrifydc.conf file defines a default set of environment variables to retain from the current user's environment when the dzdo command is run. This parameter lists environment variables to keep in addition to the default set.
                         Specify a comma-separated list of variables; or you can specify an empty string to indicate there are no variables to keep other than the default set. Use the DeleteVar parameter to remove variables from the default set.
                         You cannot specify both the KeepVar and DeleteVar parameters.
 CommandDeleteVar        Environment variables to delete when dzdo is run. The dzdo.env_keep configuration parameter in the centrifydc.conf file defines a default set of environment variables to retain from the current user's environment when the dzdo command is run. This parameter lists environment variables to remove from the default set.
                         Specify a comma-separated list of variables; or you can specify an empty string to indicate there are no variables to delete from the default set. Use the KeepVar parameter to add variables to the default set.
                         You cannot specify both the KeepVar and DeleteVar parameters.
 CommandAddVar           Environment variable name-value pairs to add to the final set of environment variables resulting from the keep or delete sets described in the KeepVar and DeleteVar parameters.
                         Specify a comma-separated list of name-value pairs specified as "name=value"; or you can specify an empty string to indicate there are no variables to add.
 CommandAuthentication   type of authentication needed to run the command. You can specify one of the following values:
                            - none          no authentication is required
                            - user          authentication is required with current user's password
                            - runastarget   authentication is required with run-as target user's password

.PARAMETER ComputerRoles
 Specify the CSV File to import Centrify Computer Roles into Zones.
 The CSV File format should be as below:

 Zone,Name,Description,Group,Container,Members

 Zone          The zone of the computer role. You can specify either the Zone name or a distinguished name for this parameter.
 Name          Name of the computer role.
 Description   Description of the computer role.
 Group         The computer group to associate with this computer role. You may specify any of the following values for this parameter:
                  - distinguishedName
                  - SID
				  - samAccountName
                  - <samAccountName>@<domain>
 Container     The Active Directory container in which the AD group is to be created. This can be ignored if the AD Group already exists.
 Members       List of Computer hostnames and/or AD groups members of the Computer Role (can be ignored)

.PARAMETER RoleAssignments
 Specify the CSV File to import Centrify Role Assignments into Zones/ComputerRoles/Computers.
 The CSV File format should be as below:

 TargetType,TargetName,Role,ADTrustee,TrusteeType,LocalTrustee,StartTime,EndTime

 TargetType    Indicate on which type of object create the Role Assignment. You may specify any of the following values for this parameter:
                  - Zone
				  - ComputerRole
				  - Computer
 TargetName    The Zone/Computer/Computer Role for which to create the role assignment. You may specify any of the following values for this parameter:
                  - Name
				  - distinguishedName
				  - samAccountName (for Computer only)
 Role          The role to assign to the zone, computer, or computer role. By default the Role is picked from the nearest Zone but target Zone can be specified using the format <Role Name>/<Zone Name>.
 ADTrustee     The Active Directory account to be used as the trustee. You can use this parameter only if the trustee is a specific AD user or group. In that case, do not use the "TrusteeType" parameter. You may specify any of the following values for this parameter:
                  - distinguishedName
                  - SID
				  - samAccountName
                  - <samAccountName>@<domain>
 TrusteeType   is the type of trustee. Do not use this parameter if the trustee is a specific Active Directory user or group.  If the trustee is local, you must use both this parameter and the LocalTrustee parameter. You must assign one of the following values:
                  - LocalUnixUser   local UNIX user
                  - LocalUnixUid    local UNIX UID
                  - LocalUnixGroup  local UNIX group
                  - LocalWinUser    local Windows user
                  - LocalWinGroup   local Windows group
                  - AllAD           all AD accounts
                  - AllLocalUnix    all local UNIX accounts
                  - AllLocalWin     all local Windows accounts
 LocalTrustee  The local account to use as the trustee. You can use this parameter only if the trustee is local, not Active Directory.
               For a user or a group, specify the name; for example, "userName". For a UID, specify the UID number; for example, "12345".
 StartTime     The date and time when the role assignment becomes effective.
 EndTime       The date and time when the role assignment expires.

.PARAMETER Progress
Show progress bars.

.PARAMETER Banner
Show banner, don't clear Host (usefull if you want to wrapp ADImport commands into a custom script and keep message on screen).

.PARAMETER Version
Show version of this script.

.PARAMETER Help
Show usage for this script.

.INPUTS
None. You can't redirect or pipe input to this script.

.OUTPUTS
None. This script only writes statistics on output.

.EXAMPLE
C:\PS> .\ADImport.ps1 -Computers .\ComputersList.csv
Create and prepare Computers listed in the given CSV File.

.EXAMPLE
C:\PS> .\ADImport.ps1 -Users .\sample\Users.txt -Progress
Import Unix User profiles listed in the given CSV File, a progress bar will be shown during the import (by default no progress is shown to improve performance).

.EXAMPLE
C:\PS> .\ADImport.ps1 -z .\Zones -Banner; .\ADImport.ps1 -c .\Computers.csv; .\ADImport.ps1 -u .\Users.csv; .\ADImport.ps1 -g .\Groups.csv
Import Zones, Computers, User and Group profiles in a single sequence. Show the banner only for the first import will prevent the screeen to be cleared between each steps and so by end of import a complete log of import will be available.
#>

##########################
#region ### PARAMETERS ###
##########################
param
(
	[Parameter(Mandatory = $false, HelpMessage = "Specify the AD Domain name where perform actions in FQDN format (e.g. company.com).")]
	[Alias("d")]
	[System.String]$Domain = [DirectoryServices.ActiveDirectory.Domain]::GetComputerDomain().Name,

	[Parameter(Mandatory = $false, HelpMessage = "Specify the PSCredential of an AD User to perform actions on AD (e.g. (Get-Credential NTDOMAIN\Administrator)).")]
	[Management.Automation.PSCredential]$Credential, 

	[Parameter(Mandatory = $false, HelpMessage = "Specify Domain Controller name to connect.")]
	[Alias("s")]
	[System.String]$Server,

	[Parameter(Mandatory = $false, HelpMessage = "Specify the CSV File to import Centify Zones.")]
	[Alias("z")]
	[System.String]$Zones,

	[Parameter(Mandatory = $false, HelpMessage = "Specify the CSV File to import and prepare Computers into Zones.")]
	[Alias("c")]
	[System.String]$Computers,

	[Parameter(Mandatory = $false, HelpMessage = "Specify the CSV File to import Unix User profiles into  Zones.")]
	[Alias("u")]
	[System.String]$Users,

	[Parameter(Mandatory = $false, HelpMessage = "Specify the CSV File to import Unix Group profiles into Zones.")]
	[Alias("g")]
	[System.String]$Groups,

	[Parameter(Mandatory = $false, HelpMessage = "Specify the CSV File to import Computer Roles into Zones.")]
	[Alias("cr")]
	[System.String]$ComputerRoles,

	[Parameter(Mandatory = $false, HelpMessage = "Specify the CSV File to import Role Assignments into Zones.")]
	[Alias("ra")]
	[System.String]$RoleAssignments,

	[Parameter(Mandatory = $false, HelpMessage = "Specify the CSV File to import Roles into  Zones.")]
	[Alias("r")]
	[System.String]$Roles,

	[Parameter(Mandatory = $false, HelpMessage = "Specify the CSV File to import Unix Rights into  Zones.")]
	[Alias("ur")]
	[System.String]$UnixRights,

	[Parameter(Mandatory = $false, HelpMessage = "Specify the CSV File to import Windows Rights into  Zones.")]
	[Alias("wr")]
	[System.String]$WindowsRights,

	[Parameter(Mandatory = $false, HelpMessage = "Show progress bars.")]
	[Switch]$Progress,

	[Parameter(Mandatory = $false, HelpMessage = "Show banner, don't clear Host (usefull if you want to wrapp ADImport commands into a custom script and keep message on screen).")]
	[Switch]$Banner,

	[Parameter(Mandatory = $false, HelpMessage = "Show version of this script.")]
	[Alias("v")]
	[Switch]$Version,

	[Parameter(Mandatory = $false, HelpMessage = "Show usage for this script.")]
	[Alias("h")]
	[Switch]$Help
)
##########################
#endregion
##########################

#######################################
#region ### VERSION NUMBER and HELP ###
#######################################

[System.String]$VersionNumber = "4.7.1020"

if ($Version.IsPresent)
{
	# Return version as a variable
	return ("ADImport.ps1 ({0})" -f $VersionNumber)
}

if ($Help.IsPresent)
{
	Get-Help .\ADImport.ps1 -Full
	Exit
}

# Debug preference
if ($PSCmdlet.MyInvocation.BoundParameters["Debug"].IsPresent) 
{
	# Debug continue without waiting for confirmation
	$DebugPreference = "Continue"
}
else 
{
	# Debug message are turned off
	$DebugPreference = "SilentlyContinue"
}

# Server preference
if ([System.String]::IsNullOrEmpty($Server))
{
	# Get Preferred Server from current session
	$Server = (Get-CdmPreferredServer | Where-Object { $_.Domain -eq $Domain }).Server
}
else 
{
	# Set Preferred Server
	Set-CdmPreferredServer -Domain $Domain -Server $Server
}
#######################################
#endregion
#######################################

#################################
#region ### UTILITY FUNCTIONS ###
#################################

###########################################################################################
# ADImport - Get-ADsPath
#
# Return ADsPath in LDAP syntax for a given Path completing with the defaultNamingContext if needed 
########
function Get-ADsPath
{
    param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "Specify the DN of the object for which to return LDAP Path.")]
		[Alias("dn")]
		[System.String]$DistinguishedName
	)
	
	try
	{
		# Check if defaultNamingContext is given in the distinguishedName
		if ($DistinguishedName -match ".*,DC=.*,DC=.*")
		{
			# Add LDAP:// to DN
			[System.String]$strADsPath = ("LDAP://{0}" -f $DistinguishedName)
		}
		else
		{
			# Get defaultNamingContext from Domain
			[DirectoryServices.DirectoryEntry]$dseRootDSE = [ADSI]("LDAP://{0}/RootDSE" -f $Domain)
			[System.String]$strDefaultNamingContext = $dseRootDSE.defaultNamingContext
			# Add LDAP:// and defaultNamingContext to DN
			[System.String]$strADsPath = ("LDAP://{0},{1}" -f $DistinguishedName, $strDefaultNamingContext)
		}
    }
	catch
	{
		Throw $_.Exception
	}
	# Return ADsPath (LDAP Path)
	return $strADsPath
}

###########################################################################################
# ADImport - Get-ADComputerByHostname
#
# Search for AD Computer account by hostname and return the DirectoryEntry object path 
########
function Get-ADComputerByHostname
{
	#######################################################################################
	param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "Hostname of the AD Computer.")]
		[Alias("c")]
		[System.String]$Hostname
	)
	#######################################################################################
	# Connect AD
	[System.String]$strPath = ("LDAP://{0}" -f $Domain)
	if ($Credential -eq [Void]$null)
	{
		[DirectoryServices.DirectoryEntry]$dseDirectoryEntry = New-Object System.DirectoryServices.DirectoryEntry($strPath)
	}
	else
	{
		[DirectoryServices.DirectoryEntry]$dseDirectoryEntry = New-Object System.DirectoryServices.DirectoryEntry($strPath, $Credential.GetNetworkCredential().UserName, $Credential.GetNetworkCredential().Password, "Secure")
	}
	# Build search query
	[DirectoryServices.DirectorySearcher]$dssDirectorySearcher = New-Object System.DirectoryServices.DirectorySearcher
	$dssDirectorySearcher.SearchRoot	= $dseDirectoryEntry
	$dssDirectorySearcher.PageSize 		= 1000
	$dssDirectorySearcher.Filter 		= ("(&(objectClass=computer)(|(cn={0})(samAccountName={0}`$)))" -f $Hostname)
	$dssDirectorySearcher.SearchScope 	= "subtree"
	# Execute search query
	[DirectoryServices.SearchResult]$dsrSearchResult = $dssDirectorySearcher.FindOne()
	if ($dsrSearchResult -ne [Void]$null)
	{
		# Return AD Computer ADsPath
		return $dsrSearchResult.Path
	}
	else
	{
		Write-Error ("Can't find AD Computer {0} in Active Directory." -f $Hostname)
	}
	# Return Null
	return [Void]$null
}

###########################################################################################
# ADImport - New-ADSecurityGroup
#
# Create AD Security Group in the given Container and return the DirectoryEntry object Path 
########
function New-ADSecurityGroup
{
	#######################################################################################
    param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "Specify the Name of the security group to create.")]
		[Alias("n")]
		[System.String]$Name,
		
		[Parameter(Position = 1, Mandatory = $true, HelpMessage = "Specify the Container where create the security group.")]
		[Alias("c")]
		[System.String]$Container,

		[Parameter(Position = 2, Mandatory = $true, HelpMessage = "Specify the group type of the security group (default value is DomainLocal).")]
		[Alias("t")]
		[System.String]$groupType = "DomainLocal"
	)
	#######################################################################################
	try
	{
		# Connect to Container into AD
		[System.String]$strContainerPath = Get-ADsPath $Container
		# Create Security Group
		[Microsoft.ActiveDirectory.Management.ADGroup]$adGroup = New-ADGroup -GroupCategory "Security" -GroupScope $groupType -Path $strContainerPath -Name $Name
	}
	catch [System.Management.Automation.MethodInvocationException]
	{
		if ($_.Exception.Message -match "^*`"The object already exists`.`"*")
		{
			# Group already exist
			Write-Warning ("Group named {0} already exists. Skip creation." -f $Name)
			# Return existing group Path
			[Microsoft.ActiveDirectory.Management.ADGroup]$adGroup = Get-ADGroup -Filter { Name -eq $Name }
			return $adGroup.DistinguishedName
		}
		else
		{
			# unknown exception
			Throw $_.Exception
		}
	}
	catch
	{
		Throw $_.Exception
	}

	# Return Group Path
	return $adGroup.DistinguishedName
}

###########################################################################################
# ADImport - Get-CentrifyZone
#
# Search for Centrify Zone by Name or DN and return the CdmZone object 
########
function Get-CentrifyZone
{
	#######################################################################################
	param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "Zone Name or DN.")]
		[Alias("n")]
		[System.String]$Name
	)
	#######################################################################################
	# Get Centrify Zone by Name or DN
	try
	{
		if ($Name -match "^(CN=|OU=).*,DC=.*,DC=.*$")
		{
			# Get Parent Zone by DN
			[Centrify.DirectControl.PowerShell.Types.CdmZone]$CdmZone = Get-CdmZone -Dn $Name
		}
		else
		{
			# Get Parent Zone by Name
			[Centrify.DirectControl.PowerShell.Types.CdmZone]$CdmZone = Get-CdmZone -Name $Name -Domain $Domain
		}
	}
	catch
	{
		if ($_.Exception.Message -match "Cannot process argument transformation on parameter 'Zone'/. Invalid argument System/.Object/[/]")
		{
			# Get Zone by Name return more than one Zone
			Throw "More than one Zone were found with given parameter 'Zone'. Consider search Zone by distinguishedName instead of Name."
		}
		elseif ($_.Exception.Message -match "Cannot convert the .*System/.Object/[/].* to type .*Centrify/.DirectControl/.PowerShell/.Types/.CdmZone.*")
		{
			# Get Zone by Name received an incorrect or no argument
			Throw "Parameter 'Zone' is missing or incorrect. Consider revise the CSV data file."
		}
		else
		{
			# Unhandled Exception
			Throw $_.Exception
		}
		else
		{
			# Unhandled Exception
			Throw $_.Exception
		}
	}

	# Return Centrify.DirectControl.PowerShell.Types.CdmZone object
	return $CdmZone
}

###########################################################################################
# ADImport - Get-CentrifyRole
#
# Search for Centrify Role by {RoleName}/{ZoneName} and return the CdmRole object
########
function Get-CentrifyRole
{
	#######################################################################################
	param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "CdmZone object.")]
		[Alias("z")]
		[Centrify.DirectControl.PowerShell.Types.CdmZone]$Zone,
		
		[Parameter(Position = 1, Mandatory = $true, HelpMessage = "Role name.")]
		[Alias("n")]
		[System.String]$Name
	)
	#######################################################################################
	# Get Centrify Role
	try
	{
		# Get Role
		[System.String]$strRoleName = $objRoleAssignment.Role.Split("/")[0]
		[System.String]$strRoleZoneName = $objRoleAssignment.Role.Split("/")[1]
		# Validate format of the querry
		if ([System.String]::IsNullOrEmpty($strRoleZoneName))
		{
			# Get Role from Computer Role Zone
			[Centrify.DirectControl.PowerShell.Types.CdmRole]$CdmRole = Get-CdmRole -Zone $Zone -Name $strRoleName
		}
		else
		{
			# Get Role from specific Zone
			[Centrify.DirectControl.PowerShell.Types.CdmZone]$Zone = Get-CentrifyZone $strRoleZoneName
			[Centrify.DirectControl.PowerShell.Types.CdmRole]$CdmRole = Get-CdmRole -Zone $Zone -Name $strRoleName
		}
	}
	catch
	{
		# Unhandled Exception
		Throw $_.Exception
	}

	# Return Centrify.DirectControl.PowerShell.Types.CdmRole object
	return $CdmRole
}

#################################
#endregion
#################################

################################
#region ### IMPORT FUNCTIONS ###
################################

###########################################################################################
# ADImport - Import-CentrifyZones
#
# Specify the CSV File to import Zones.
# The CSV File format should be as below:
#
# Name,Container(,Description,IsOU,Parent)
#
# Name          Name of the zone.
# Container     Container in which to create the zone. This can be ignored if Parent Zone is specified and the Child Zone should be created under his Parent Zone.
# Description   Description of the new zone.
# IsOU          If you specify this parameter, the zone is created as an organizational unit (OU). Otherwise, it is created as a container object.  
# Parent        The parent zone of the new zone, if any. Specify an empty string if there is no parent zone. 
#
########
function Import-CentrifyZones
{
	#######################################################################################
	param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "CSV data file to process.")]
		[System.String]$Data
	)
	#######################################################################################
	Write-Output "Starting Centrify Zone import..."
	# Prepare computer and create AD Computer account if set
	[System.Int32]$intNbImportedZones = 0
	[System.Array]$arrZoneList = Import-CSV $Data
	if ($arrZoneList -eq [Void]$null)
	{
		Throw "Input file is in unattended format. Consider checking End Of Line characters that must be [CR][LF] on Windows system."
	}
	# Process Zone List
	[System.Int32]$i = 1
	[System.Int32]$intNbZones = $arrZoneList.Count
	foreach ($objZone in $arrZoneList)
	{
		if ($Progress.IsPresent)
		{
			# Show progress for Zone import
			[System.String]$ProgressActivity	= ("Import Zones [{0}/{1}]" -f $i, $intNbZones)
			[System.String]$ProgressStatus		= "Percent processed: "
			$ProgressComplete	= (($i++ / $intNbZones)*100)
			Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 1
		}
		try
		{
			# Get Parent Zone if specified
			if (-not [System.String]::IsNullOrEmpty($objZone.Parent))
			{
				# Get Parent Zone by DN
				[Centrify.DirectControl.PowerShell.Types.CdmZone]$CdmParentZone = Get-CentrifyZone -Name $objZone.Parent
				if ([System.String]::IsNullOrEmpty($objZone.Container))
				{
					# Get Parent Zone DN as Container
					$objZone.Container = $CdmParentZone.DistinguishedName
				}
			}
			else
			{
				# Parent Zone is not given, the current Zone will be created without Parent Zone
				[System.String]$CdmParentZone = ""
			}
			# Detect if Zone should be created as an OU
			if ($objZone.IsOU -eq "true")
			{
				# Data to Import: Name,Container,IsOU(,Parent)
				$CdmZone = New-CdmZone 	-Name $objZone.Name `
										-Container $objZone.Container `
										-Description $objZone.Description `
										-Parent $CdmParentZone -IsOU
			}
			else
			{
				# Data to Import: Name,Container(,IsOU,Parent)
				$CdmZone = New-CdmZone 	-Name $objZone.Name `
										-Container $objZone.Container `
										-Description $objZone.Description `
										-Parent $CdmParentZone
			}
			# Count Zones created
			if ($CdmZone -ne [Void]$null)
			{
				$intNbImportedZones++
			}
		}
		catch [System.ApplicationException]
		{
			if ($_.Exception.Message -match "The zone already existed")
			{
				Write-Warning ("Zone '{0}' already exist." -f $objZone.Name)
			}
			else
			{
				# Unhandled Exception
				Throw $_.Exception
			}
		}
		catch
		{
			# Unhandled Exception
			Throw $_.Exception
		}
	}
	
	# Print result
	Write-Output ("Zones created`t: {0}`nDone.`n" -f $intNbImportedZones)
	Sleep 1
	if ($Progress.IsPresent)
	{
		# Close progress bars
		Write-Progress -Activity "Zones done" -Status "Hidden" -Id 1 -Completed
	}
	# Done.
}

###########################################################################################
# ADImport - Import-CentrifyComputers
#
# Specify the CSV File to import and prepare Computers into Zones.
# The CSV File format should be as below:
#
# Hostname,Zone(,Container)
#
# Hostname     The name of the computer.
# Zone         The zone to which the computer is added. You can specify either the Zone name or a distinguished name for this parameter.
# Container    The Active Directory container in which the AD computer is to be created. Specify this parameter only if you are creating a new Active Directory computer.
#  
########
function Import-CentrifyComputers
{
	#######################################################################################
	param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "CSV data file to process.")]
		[System.String]$Data
	)
	#######################################################################################
	Write-Output ("Starting UNIX Computers preparation using {0} file..." -f $Data)
	# Prepare computer and create AD Computer account if set
	[System.Int32]$intNbImportedComputers = 0
	[System.Array]$arrComputerList = Import-CSV $Data
	if ($arrComputerList -eq [Void]$null)
	{
		Throw "Input file is in unattended format. Consider checking End Of Line characters that must be [CR][LF] on Windows system."
	}
	# Get list of Zones from Computer List
	[System.Array]$arrZoneList = $arrComputerList | Select-Object -Property Zone -Unique

	# Process Zone List
	[System.Int32]$z = 1
	[System.Int32]$intNbZones = $arrZoneList.Count
	[System.Int32]$all = 1
	[System.Int32]$intNbComputers = $arrComputerList.Count
	# Show progress for overall Computer import
	if ($Progress.IsPresent)
	{
		$OverallProgressActivity	= ("Prepare UNIX Computers [{0}/{1}]" -f $all, $intNbComputers)
		$OverallProgressStatus		= "Percent processed: "
		$OverallProgressComplete	= (($all / $intNbComputers)*100)
		Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
	}
	foreach ($objZone in $arrZoneList)
	{
		[System.String]$strZoneName = $objZone.Zone
		# Get Centrify Zone where to prepare Computer
		[Centrify.DirectControl.PowerShell.Types.CdmZone]$CdmZone = Get-CentrifyZone -Name $strZoneName
		# Validate that the Zone exist
		if ($CdmZone -ne [Void]$null)
		{
			if ($Progress.IsPresent)
			{
				# Show progress for Zone processing
				$ProgressActivity	= ("Centrify Zone '{0}' [{1}/{2}]" -f $CdmZone.Name, $z, $intNbZones)
				$ProgressStatus		= "Percent processed: "
				$ProgressComplete	= (($z++ / $intNbZones)*100)
				Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 2
			}
			# Process Computer List for the current Zone
			[System.Array]$arrComputerListInCurrentZone = $arrComputerList | Where-Object { $_.Zone -eq $objZone.Zone }
			[System.Int32]$i = 1
			[System.Int32]$intNbComputersInCurrentZone = $arrComputerListInCurrentZone.Count
			foreach ($objComputer in $arrComputerListInCurrentZone)
			{
				if ($Progress.IsPresent)
				{
					# Show progress for overall Computer import
					$OverallProgressActivity	= ("Prepare UNIX Computers [{0}/{1}]" -f $all, $intNbComputers)
					$OverallProgressStatus		= "Percent processed: "
					$OverallProgressComplete	= (($all++ / $intNbComputers)*100)
					Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
					# Show progress for Computer import
					$ProgressActivity	= ("UNIX Computer '{0}' [{1}/{2}]" -f $objComputer.Hostname, $i, $intNbComputersInCurrentZone)
					$ProgressStatus		= "Percent processed: "
					$ProgressComplete	= (($i++ / $intNbComputersInCurrentZone)*100)
					Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 3 -ParentId 2
				}
				# Set values for Hostname and DnsHostName (i.e. FQDN)
				[System.String]$strHostname = $objComputer.Hostname.Split(".")[0]
				[System.String]$strDnsHostName = $objComputer.Hostname
				if ($strDnsHostName -eq $strHostname)
				{
					# Hostname value is not FQDN, add current domain name to short Hostname
					$strDnsHostName = ("{0}.{1}" -f $strDnsHostName, $Domain)
				}
				# Check if Computer Profile already exists
				[Centrify.DirectControl.PowerShell.Types.CdmManagedComputer]$CdmManagedComputer = Get-CdmManagedComputer -Name $strHostname -ZoneDomain $Domain
				if ($CdmManagedComputer -eq [Void]$null)
				{
					try
					{
						
						# Data to Import: Hostname,Zone,Container
						# Check if AD Computer already exists
						[Microsoft.ActiveDirectory.Management.ADComputer]$ADComputer = Get-ADComputer -Filter { Name -eq $strHostname } -Server $Server
						if ($ADComputer -eq [Void]$null)
						{
							if (-not [System.String]::IsNullOrEmpty($objComputer.Container))
							{
								# Create the AD Computer account and his profile
								$CdmManagedComputer = New-CdmManagedComputer 	-Zone $CdmZone `
																				-Name $strHostname `
																				-DnsName $strDnsHostName `
																				-Container $objComputer.Container
							}
							else
							{
								# Computer does not exists, Container value need to be specified
								Throw ("Computer '{0}' does not exists in Domain {1}. A Container value need to be specified for the Computer object creation." -f $strHostname, $Domain)
							}
						}
						else
						{
							# Create the profile
							$CdmManagedComputer = New-CdmManagedComputer -Zone $CdmZone -Computer $ADComputer.DistinguishedName
						}
					}
					catch
					{
						# Unhandled Exception
						Throw $_.Exception
					}
					# Add fix from Engineering to remove RODC support in order to not prevent Self-Service join with adclient prior to version 5.1.3
					if ($CdmManagedComputer -ne [Void]$null)
					{
						try
						{
							# Get Computer Profile ADSI object (the Centrify.DirectControl.PowerShell.Types.CdmManagedComputer interface does not give access to unix_enabled parameter)
							[DirectoryServices.DirectoryEntry]$SCP = [ADSI]($CdmManagedComputer.ScpPath)
							[System.Array]$keywords = $SCP.Properties["keywords"].Value
							if ($keywords -contains "unix_enabled:True")
							{
								# Remove unix_enabled value
								$SCP.Properties["keywords"].Remove("unix_enabled:True")
								$SCP.CommitChanges()
							}
						}
						catch
						{
							# Unhandled Exception
							Throw $_.Exception
						}
					}
					# Count imported Computers
					if ($CdmManagedComputer -ne [Void]$null)
					{
						$intNbImportedComputers++
					}
				}
				else
				{
					if ($CdmManagedComputer.IsJoinedToZone)
					{
						# Computer is already Zoned
						Write-Warning ("Computer {0} is already Zoned." -f $CdmManagedComputer.Computer)
					}
					else
					{
						# Computer exists but is not Zoned
						Write-Error ("Computer {0} has already a profile but is not Zoned." -f $CdmManagedComputer.Computer)
					}
				}
			}
		}
		else
		{
			# Zone not found
			Write-Error ("Can't find Zone {0} in Active Directory." -f $objZone.Zone)
		}
	}
	# Print result
	Write-Output ("Computers prepared`t: {0}`nDone.`n" -f $intNbImportedComputers)
	Sleep 1
	if ($Progress.IsPresent)
	{
		# Close progress bars
		Write-Progress -Activity "All Computers done" -Status "Hidden" -Id 1 -Completed
		Write-Progress -Activity "Zones done" -Status "Hidden" -Id 2 -Completed
		Write-Progress -Activity "Computers done" -Status "Hidden" -Id 3 -Completed
	}
	# Done.
}

###########################################################################################
# ADImport - Import-CentrifyUsers
#
# Specify the CSV File to import Unix User profiles into Zones and/or as Computer overrides.
# The CSV File format should be as below:
#
# Zone,User,UnixName,UID,GID,Gecos,Home,Shell
#
# Zone       The zone for which to create the UNIX profile. You can specify either the Zone name or a distinguished name for this parameter.
#            Alternatively you can specify a managed computer for which to create the UNIX profile. You can specify either a CdmManagedComputer object or any of the following values for the Active Directory computer:
#               - distinguishedName
#               - SID
#               - samAccountName
# User      The Active Directory user for which you are adding a UNIX user profile. You may specify any of the following values for this parameter:
#               - distinguishedName
#               - SID
#               - samAccountName
#               - <samAccountName>@<domain>
# UnixName   The UNIX login name for the user associated with the profile.
# UID        The UID of the user associated with the UNIX profile.
# GID        The group ID (GID) of the primary group of the user associated with the UNIX profile.
# Gecos      The GECOS field of the user UNIX profile.  Use this parameter for hierarchical zones only.
# Home       Default home directory of the user associated with the UNIX profile.
# Shell      The default shell of the user associated with the UNIX profile.
#  
########
function Import-CentrifyUsers
{
	#######################################################################################
	param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "CSV data file to process.")]
		[System.String]$Data
	)
	#######################################################################################
	Write-Output ("Starting UNIX Users import using {0} file..." -f $Data)
	# Import Unix Users
	[System.Int32]$intNbImportedUsers = 0
	[System.Array]$arrUserList = Import-CSV $Data
	if ($arrUserList -eq [Void]$null)
	{
		Throw "Input file is in unattended format. Consider checking End Of Line characters that must be [CR][LF] on Windows system."
	}
	# Get list of Zones from User List
	[System.Array]$arrZoneList = $arrUserList | Select-Object -Property Zone -Unique

	# Process Zone List
	[System.Int32]$z = 1
	[System.Int32]$intNbZones = $arrZoneList.Count
	[System.Int32]$all = 1
	[System.Int32]$intNbUsers = $arrUserList.Count
	# Show progress for overall User import
	if ($Progress.IsPresent)
	{
		$OverallProgressActivity	= ("Import UNIX Users [{0}/{1}]" -f $all, $intNbUsers)
		$OverallProgressStatus		= "Percent processed: "
		$OverallProgressComplete	= (($all / $intNbUsers)*100)
		Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
	}
	foreach ($objZone in $arrZoneList)
	{
		[System.String]$strZoneName = $objZone.Zone
		# Get Centrify Zone where to import Unix Profile
		[Centrify.DirectControl.PowerShell.Types.CdmZone]$CdmZone = Get-CentrifyZone $strZoneName
		# Validate that the Zone exist
		if ($CdmZone -ne [Void]$null)
		{
			if ($Progress.IsPresent)
			{
				# Show progress for Zone processing
				$ProgressActivity	= ("Centrify Zone '{0}' [{1}/{2}]" -f $CdmZone.Name, $z, $intNbZones)
				$ProgressStatus		= "Percent processed: "
				$ProgressComplete	= (($z++ / $intNbZones)*100)
				Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 2
			}
			# Process User List for the current Zone
			[System.Array]$arrUserListInCurrentZone = $arrUserList | Where-Object { $_.Zone -eq $objZone.Zone }
			[System.Int32]$i = 1
			[System.Int32]$intNbUsersInCurrentZone = $arrUserListInCurrentZone.Count
			foreach ($objUser in $arrUserListInCurrentZone)
			{
				if ($Progress.IsPresent)
				{
					# Show progress for overall Computer import
					$OverallProgressActivity	= ("Import UNIX Users [{0}/{1}]" -f $all, $intNbUsers)
					$OverallProgressStatus		= "Percent processed: "
					$OverallProgressComplete	= (($all++ / $intNbUsers)*100)
					Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
					# Show progress for Computer import
					$ProgressActivity	= ("UNIX User '{0}' [{1}/{2}]" -f $objUser.UnixName, $i, $intNbUsersInCurrentZone)
					$ProgressStatus		= "Percent processed: "
					$ProgressComplete	= (($i++ / $intNbUsersInCurrentZone)*100)
					Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 3 -ParentId 2
				}
				try
				{
					# Format User to {samAccountName}@{Domain} if needed
					if ($objUser.User -notmatch "^.*@.*$")
					{
						$objUser.User = ("{0}@{1}" -f $objUser.User, $Domain)
					}
					# Data to Import: Zone,User,UnixName,UID,GID,Gecos,Home,Shell
					$CdmUserProfile = New-CdmUserProfile 	-Zone $CdmZone `
															-User $objUser.User `
															-Login $objUser.UnixName `
															-Gecos $objUser.Gecos `
															-HomeDir $objUser.Home `
															-Shell $objUser.Shell
					if (-not [System.String]::IsNullOrEmpty($objUser.UID))
					{
						# Import User profile UID
						$CdmUserProfile = $CdmUserProfile | Set-CdmUserProfile -Uid $objUser.UID
					}
					if (-not [System.String]::IsNullOrEmpty($objUser.GID))
					{
						# Import User profile GID
						$CdmUserProfile = $CdmUserProfile | Set-CdmUserProfile -PrimaryGroup $objUser.GID
					}
					# Count User created
					if ($CdmUserProfile -ne [Void]$null)
					{
						$intNbImportedUsers++
					}
				}
				catch [System.ArgumentException]
				{
					if ($_.Exception.Message -match "Failed to get object .*")
					{
						Write-Error $_.Exception.Message
					}
					elseif ($_.Exception.Message -match "Invalid argument .*")
					{
						Write-Error $_.Exception.Message
					}
					elseif ($_.Exception.Message -match "Secondary profile should be complete.")
					{
						Write-Warning ("Duplicated username '{0}' in zone '{1}'. {2}" -f $objUser.UnixName, $CdmZone.Name, $_.Exception.Message)
					}
					else
					{
						# Unhandled Exception
						Throw $_.Exception
					}
				}
				catch [System.ApplicationException]
				{
					if ($_.Exception.Message -match "Duplicated username")
					{
						Write-Warning $_.Exception.Message
					}
					else
					{
						# Unhandled Exception
						Throw $_.Exception
					}
				}
				catch
				{
					# Unhandled Exception
					Throw $_.Exception
				}
			}
		}
		else
		{
			# Zone do not exists, search for a Managed Computer instead
			[Centrify.DirectControl.PowerShell.Types.CdmManagedComputer]$CdmManagedComputer = Get-CdmManagedComputer -Name $strZoneName -ZoneDomain $Domain
			# Validate that the Managed Computer exist
			if ($CdmManagedComputer -ne [Void]$null)
			{
				if ($Progress.IsPresent)
				{
					# Show progress for Zone processing
					$ProgressActivity	= ("Centrify Managed Computer '{0}' [{1}/{2}]" -f $CdmManagedComputer.Name, $z, $intNbZones)
					$ProgressStatus		= "Percent processed: "
					$ProgressComplete	= (($z++ / $intNbZones)*100)
					Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 2
				}
				# Process User List for the current Zone
				[System.Array]$arrUserListInCurrentZone = $arrUserList | Where-Object { $_.Zone -eq $objZone.Zone }
				[System.Int32]$i = 1
				[System.Int32]$intNbUsersInCurrentZone = $arrUserListInCurrentZone.Count
				foreach ($objUser in $arrUserListInCurrentZone)
				{
					if ($Progress.IsPresent)
					{
						# Show progress for overall Computer import
						$OverallProgressActivity	= ("Import UNIX Users [{0}/{1}]" -f $all, $intNbUsers)
						$OverallProgressStatus		= "Percent processed: "
						$OverallProgressComplete	= (($all++ / $intNbUsers)*100)
						Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
						# Show progress for Computer import
						$ProgressActivity	= ("UNIX User '{0}' [{1}/{2}]" -f $objUser.UnixName, $i, $intNbUsersInCurrentZone)
						$ProgressStatus		= "Percent processed: "
						$ProgressComplete	= (($i++ / $intNbUsersInCurrentZone)*100)
						Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 3 -ParentId 2
					}
					try
					{
						# Format User to {samAccountName}@{Domain} if needed
						if ($objUser.User -notmatch "^.*@.*$")
						{
							$objUser.User = ("{0}@{1}" -f $objUser.User, $Domain)
						}
						# Data to Import: Hostname,User,UnixName,UID,GID,Gecos,Home,Shell
						$CdmUserProfile = New-CdmUserProfile 	-Computer $CdmManagedComputer `
																-User $objUser.User `
																-Login $objUser.UnixName `
																-Gecos $objUser.Gecos `
																-HomeDir $objUser.Home `
																-Shell $objUser.Shell
						if (-not [System.String]::IsNullOrEmpty($objUser.UID))
						{
							# Import User profile UID
							$CdmUserProfile = $CdmUserProfile | Set-CdmUserProfile -Uid $objUser.UID
						}
						if (-not [System.String]::IsNullOrEmpty($objUser.GID))
						{
							# Import User profile GID
							$CdmUserProfile = $CdmUserProfile | Set-CdmUserProfile -PrimaryGroup $objUser.GID
						}
						# Count User created
						if ($CdmUserProfile -ne [Void]$null)
						{
							$intNbImportedUsers++
						}
					}
					catch [System.ArgumentException]
					{
						if ($_.Exception.Message -match "Failed to get object .*")
						{
							Write-Error $_.Exception.Message
						}
						elseif ($_.Exception.Message -match "Invalid argument .*")
						{
							Write-Error $_.Exception.Message
						}
						elseif ($_.Exception.Message -match "Secondary profile should be complete.")
						{
							Write-Warning ("Duplicated username '{0}' in computer '{1}'. {2}" -f $objUser.UnixName, $CdmManagedComputer.Name, $_.Exception.Message)
						}
						else
						{
							# Unhandled Exception
							Throw $_.Exception
						}
					}
					catch [System.ApplicationException]
					{
						if ($_.Exception.Message -match "Duplicated username")
						{
							Write-Warning ("Duplicated username '{0}' in computer '{1}'." -f $objUser.UnixName, $CdmManagedComputer.Name)
						}
						else
						{
							# Unhandled Exception
							Throw $_.Exception
						}
					}
					catch
					{
						# Unhandled Exception
						Throw $_.Exception
					}
				}
			}
			else
			{
				# Zone/Computer not found
				Write-Error ("Can't find any Zone or Managed Computer named {0} in Active Directory." -f $objZone.Zone)
			}
		}
	}			
	
	# Print result
	Write-Host ("UNIX Users imported`t: {0}`nDone.`n" -f $intNbImportedUsers)
	Sleep 1
	if ($Progress.IsPresent)
	{
		# Close progress bars
		Write-Progress -Activity "All Users done" -Status "Hidden" -Id 1 -Completed
		Write-Progress -Activity "Zones done" -Status "Hidden" -Id 2 -Completed
		Write-Progress -Activity "Users done" -Status "Hidden" -Id 3 -Completed
	}
	# Done.
}

###########################################################################################
# ADImport - Import-CentrifyGroups
#
# Specify the CSV File to import Unix Group profiles into Zones and/or as Computer overrides.
# The CSV File format should be as below:
#
# Zone,Group,Container,UnixName,GID,Members
#
# Zone       The zone for which to create the UNIX profile. You can specify either the Zone name or a distinguished name for this parameter.
#            Alternatively you can specify a managed computer for which to create the UNIX profile. You can specify either a CdmManagedComputer object or any of the following values for the Active Directory computer:
#               - distinguishedName
#               - SID
#               - samAccountName
# Group      The Active Directory group for which you are adding a UNIX group profile. You may specify any of the following values for this parameter:
#               - distinguishedName
#               - SID
#               - samAccountName
#               - <samAccountName>@<domain>
# Container  The AD Container where to create the Active Directory group to associate to the UNIX group profile.
# UnixName   Name of the UNIX group profile.
# GID        The GID of the group UNIX profile.
# Members    List of Unix Names members of the Unix secondary group (as members are comma separeted this vallue MUST be enclosed with "" (double quotes))
#  
########
function Import-CentrifyGroups
{
	#######################################################################################
	param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "CSV data file to process.")]
		[System.String]$Data
	)
	#######################################################################################
	Write-Output ("Starting UNIX Groups import using {0} file..." -f $Data)
	# Import Unix Groups
	[System.Int32]$intNbImportedGroups = 0
	[System.Array]$arrGroupList = Import-CSV $Data
	if ($arrGroupList -eq [Void]$null)
	{
		Throw "Input file is in unattended format. Consider checking End Of Line characters that must be [CR][LF] on Windows system."
	}
	# Get list of Zones from Group List
	[System.Array]$arrZoneList = $arrGroupList | Select-Object -Property Zone -Unique

	# Process Zone List
	[System.Int32]$z = 1
	[System.Int32]$intNbZones = $arrZoneList.Count
	[System.Int32]$all = 1
	[System.Int32]$intNbGroups = $arrGroupList.Count
	# Show progress for overall Group import
	if ($Progress.IsPresent)
	{
		$OverallProgressActivity	= ("Import UNIX Groups [{0}/{1}]" -f $all, $intNbGroups)
		$OverallProgressStatus		= "Percent processed: "
		$OverallProgressComplete	= (($all / $intNbGroups)*100)
		Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
	}
	foreach ($objZone in $arrZoneList)
	{
		[System.String]$strZoneName = $objZone.Zone
		# Get Centrify Zone where to import Unix Profile
		[Centrify.DirectControl.PowerShell.Types.CdmZone]$CdmZone = Get-CentrifyZone -Name $strZoneName
		# Validate that the Zone exist
		if ($CdmZone -ne [Void]$null)
		{
			if ($Progress.IsPresent)
			{
				# Show progress for Zone processing
				$ProgressActivity	= ("Centrify Zone '{0}' [{1}/{2}]" -f $CdmZone.Name, $z, $intNbZones)
				$ProgressStatus		= "Percent processed: "
				$ProgressComplete	= (($z++ / $intNbZones)*100)
				Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 2
			}
			# Process Group List for the current Zone
			[System.Array]$arrGroupListInCurrentZone = $arrGroupList | Where-Object { $_.Zone -eq $objZone.Zone }
			[System.Int32]$i = 1
			[System.Int32]$intNbGroupsInCurrentZone = $arrGroupListInCurrentZone.Count
			foreach ($objGroup in $arrGroupListInCurrentZone)
			{
				if ($Progress.IsPresent)
				{
					# Show progress for overall Computer import
					$OverallProgressActivity	= ("Import UNIX Groups [{0}/{1}]" -f $all, $intNbGroups)
					$OverallProgressStatus		= "Percent processed: "
					$OverallProgressComplete	= (($all++ / $intNbGroups)*100)
					Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
					# Show progress for Computer import
					$ProgressActivity	= ("UNIX Group '{0}' [{1}/{2}]" -f $objGroup.UnixName, $i, $intNbGroupsInCurrentZone)
					$ProgressStatus		= "Percent processed: "
					$ProgressComplete	= (($i++ / $intNbGroupsInCurrentZone)*100)
					Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 3 -ParentId 2
				}
				try
				{
					# Format Group to {samAccountName}@{Domain} if needed
					if ($objGroup.Group -notmatch "^.*@.*$")
					{
						$objGroup.Group = ("{0}@{1}" -f $objGroup.Group, $Domain)
					}
					# Data to Import: Zone,Group,UnixName,GID,Members
					[Centrify.DirectControl.PowerShell.Types.CdmGroupProfile]$CdmGroupProfile = New-CdmGroupProfile 	-Zone $CdmZone `
																														-Group $objGroup.Group `
																														-Name $objGroup.UnixName
					if (-not [System.String]::IsNullOrEmpty($objGroup.GID))
					{
						# Impport Group profile GID
						$CdmGroupProfile = $CdmGroupProfile | Set-CdmGroupProfile -GID $objGroup.GID
					}
					# Count Group created
					if ($CdmGroupProfile -ne [Void]$null)
					{
						$intNbImportedGroups++
					}
				}
				catch [System.ArgumentException]
				{
					if ($_.Exception.Message -match "Failed to get object .*")
					{
						# AD Group not found in AD, create it under given Container
						if (-not [System.String]::IsNullOrEmpty($objGroup.Container))
						{
							# Create AD Security Group
							[System.String]$strGroupName = $objGroup.Group.Split("@")[0]
							[System.String]$strADGroupDN = New-ADSecurityGroup -Name $strGroupName -Container $objGroup.Container
							# Create the Computer Role using the created AD Group
							[Centrify.DirectControl.PowerShell.Types.CdmGroupProfile]$CdmGroupProfile = New-CdmGroupProfile 	-Zone $CdmZone `
																																-Group $objGroup.Group `
																																-Name $objGroup.UnixName
							if (-not [System.String]::IsNullOrEmpty($objGroup.GID))
							{
								# Import Group profile GID
								$CdmGroupProfile = $CdmGroupProfile | Set-CdmGroupProfile -GID $objGroup.GID
							}
							# Count Computer Role created
							if ($CdmGroupProfile -ne [Void]$null)
							{
								$intNbImportedGroups++
							}
						}
						else
						{
							# AD Group not found and Container wasn't specified
							Write-Error ("{0}, you must specify a Container where to create the missing AD Group." -f $_.Exception.Message)
						}
					}
					elseif ($_.Exception.Message -match "Invalid argument .*")
					{
						Write-Error $_.Exception.Message
					}
					else
					{
						# Unhandled Exception
						Throw $_.Exception
					}
				}
				catch [System.ApplicationException]
				{
					if ($_.Exception.Message -match "Duplicate group name")
					{
						Write-Warning $_.Exception.Message
						# Get Group Profile for members management
						[Centrify.DirectControl.PowerShell.Types.CdmGroupProfile]$CdmGroupProfile = Get-CdmGroupProfile -Zone $CdmZone -Group $objGroup.Group
					}
					else
					{
						# Unhandled Exception
						Throw $_.Exception
					}
				}
				catch
				{
					# Unhandled Exception
					Throw $_.Exception
				}
				# Import Group members
				if (-not [System.String]::IsNullOrEmpty($objGroup.members))
				{
					[System.String[]]$strMembers = $objGroup.members.Split(',')
					Import-CentrifyGroupMembers -Group $CdmGroupProfile -Members $strMembers
				}
			}
		}
		else
		{
			# Zone do not exists, search for a Managed Computer instead
			[Centrify.DirectControl.PowerShell.Types.CdmManagedComputer]$CdmManagedComputer = Get-CdmManagedComputer -Name $strZoneName
			# Validate that the Managed Computer exist
			if ($CdmManagedComputer -ne [Void]$null)
			{
				if ($Progress.IsPresent)
				{
					# Show progress for Zone processing
					$ProgressActivity	= ("Centrify Managed Computer '{0}' [{1}/{2}]" -f $CdmManagedComputer.Name, $z, $intNbZones)
					$ProgressStatus		= "Percent processed: "
					$ProgressComplete	= (($z++ / $intNbZones)*100)
					Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 2
				}
				# Process Group List for the current Zone
				[System.Array]$arrGroupListInCurrentZone = $arrGroupList | Where-Object { $_.Zone -eq $objZone.Zone }
				[System.Int32]$i = 1
				[System.Int32]$intNbGroupsInCurrentZone = $arrGroupListInCurrentZone.Count
				foreach ($objGroup in $arrGroupListInCurrentZone)
				{
					if ($Progress.IsPresent)
					{
						# Show progress for overall Computer import
						$OverallProgressActivity	= ("Import UNIX Groups [{0}/{1}]" -f $all, $intNbGroups)
						$OverallProgressStatus		= "Percent processed: "
						$OverallProgressComplete	= (($all++ / $intNbGroups)*100)
						Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
						# Show progress for Computer import
						$ProgressActivity	= ("UNIX Group '{0}' [{1}/{2}]" -f $objGroup.UnixName, $i, $intNbGroupsInCurrentZone)
						$ProgressStatus		= "Percent processed: "
						$ProgressComplete	= (($i++ / $intNbGroupsInCurrentZone)*100)
						Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 3 -ParentId 2
					}
					try
					{
						# Format Group to {samAccountName}@{Domain} if needed
						if ($objGroup.Group -notmatch "^.*@.*$")
						{
							$objGroup.Group = ("{0}@{1}" -f $objGroup.Group, $Domain)
						}
						# Data to Import: Hostname,Group,UnixName,GID(,Members)
						[Centrify.DirectControl.PowerShell.Types.CdmGroupProfile]$CdmGroupProfile = New-CdmGroupProfile 	-Computer $CdmManagedComputer `
																															-Group $objGroup.Group `
																															-Name $objGroup.UnixName `
																															-GID $objGroup.GID
						if (-not [System.String]::IsNullOrEmpty($objGroup.GID))
						{
							# Impport Group profile GID
							$CdmGroupProfile = $CdmGroupProfile | Set-CdmGroupProfile -GID $objGroup.GID
						}
						# Count Group created
						if ($CdmGroupProfile -ne [Void]$null)
						{
							$intNbImportedGroups++
						}
					}
					catch [System.ArgumentException]
					{
						if ($_.Exception.Message -match "Failed to get object .*")
						{
							# AD Group not found in AD, create it under given Container
							if (-not [System.String]::IsNullOrEmpty($objGroup.Container))
							{
								# Create AD Security Group
								[System.String]$strGroupName = $objGroup.Group.Split("@")[0]
								[System.String]$strADGroupDN = New-ADSecurityGroup -Name $strGroupName -Container $objGroup.Container
								# Create the Computer Role using the created AD Group
								[Centrify.DirectControl.PowerShell.Types.CdmGroupProfile]$CdmGroupProfile = New-CdmGroupProfile 	-Zone $CdmZone `
																																	-Group $objGroup.Group `
																																	-Name $objGroup.UnixName `
																																	-GID $objGroup.GID
								if (-not [System.String]::IsNullOrEmpty($objGroup.GID))
								{
									# Impport Group profile GID
									$CdmGroupProfile = $CdmGroupProfile | Set-CdmGroupProfile -GID $objGroup.GID
								}
								# Count Computer Role created
								if ($CdmGroupProfile -ne [Void]$null)
								{
									$intNbImportedGroups++
								}
							}
							else
							{
								# AD Group not found and Container wasn't specified
								Write-Error ("{0}, you must specify a Container if you want to create the Unix Group's AD Group." -f $_.Exception.Message)
							}
						}
						elseif ($_.Exception.Message -match "Invalid argument .*")
						{
							Write-Error $_.Exception.Message
						}
						else
						{
							# Unhandled Exception
							Throw $_.Exception
						}
					}
					catch [System.ApplicationException]
					{
						if ($_.Exception.Message -match "Duplicate group name .*")
						{
							Write-Warning $_.Exception.Message
							# Get Group Profile for members management
							[Centrify.DirectControl.PowerShell.Types.CdmGroupProfile]$CdmGroupProfile = Get-CdmGroupProfile -Computer $CdmManagedComputer -Group $objGroup.Group
						}
						else
						{
							# Unhandled Exception
							Throw $_.Exception
						}
					}
					catch
					{
						# Unhandled Exception
						Throw $_.Exception
					}
					# Import Group members
					if (-not [System.String]::IsNullOrEmpty($objGroup.members))
					{
						$arrMembers = $objGroup.members.Split(',')
						Import-CentrifyGroupMembers -Group $CdmGroupProfile -Members $arrMembers
					}
				}
			}
			else
			{
				# Zone/Computer not found
				Write-Error ("Can't find any Zone or Managed Computer named {0} in Active Directory." -f $objZone.Zone)
			}
		}
	}			

	# Print result
	Write-Host ("UNIX Groups imported`t: {0}`nDone.`n" -f $intNbImportedGroups)
	Sleep 1
	if ($Progress.IsPresent)
	{
		# Close progress bars
		Write-Progress -Activity "All Groups done" -Status "Hidden" -Id 1 -Completed
		Write-Progress -Activity "Zones done" -Status "Hidden" -Id 2 -Completed
		Write-Progress -Activity "Groups done" -Status "Hidden" -Id 3 -Completed
	}
	# Done.
}

###########################################################################################
# ADImport - Import-CentrifyGroupMembers
#
# Specify the Unix Group profile and list of Members to add.
# This function is called by Import-CentrifyGroups to add members each time a Group profile is processed
#  
########
function Import-CentrifyGroupMembers
{
	#######################################################################################
	param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "Unix Group Profile where to add members.")]
		[Centrify.DirectControl.PowerShell.Types.CdmGroupProfile]$Group,
		
		[Parameter(Position = 1, Mandatory = $true, HelpMessage = "List of members to add to the Unix Group.")]
		[System.String[]]$Members
	)
	#######################################################################################
	# Import Unix Group members
	[System.Int32]$intNbImportedGroupMembers = 0
	[Centrify.DirectControl.PowerShell.Types.CdmZone]$CdmZone = $Group.Zone
	[Centrify.DirectControl.PowerShell.Types.CdmManagedComputer]$CdmManagedComputer = $Group.Computer
	# Process Members List for the current Group
	[System.Int32]$i = 1
	[System.Int32]$intNbMembers = $Members.Count
	foreach ($strMember in $Members)
	{
		if ($Progress.IsPresent)
		{
			# Show progress for overall Computer import
			$OverallProgressActivity	= ("Import UNIX Group members [{0}/{1}]" -f $i, $intNbMembers)
			$OverallProgressStatus		= "Percent processed: "
			$OverallProgressComplete	= (($i++ / $intNbMembers)*100)
			Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 4 -ParentId 2
		}
		try
		{
			# Get User Profile
			if ($CdmZone -ne [Void]$null)
			{
				# Get User Profile from the Zone where the Group exists
				[Centrify.DirectControl.PowerShell.Types.CdmEffectiveUserProfile]$CdmUserProfile = Get-CdmEffectiveUserProfile -Zone $CdmZone -Login $strMember
			}
			else
			{
				# Get User Profile from the Computer where the Group exists
				[Centrify.DirectControl.PowerShell.Types.CdmEffectiveUserProfile]$CdmUserProfile = Get-CdmEffectiveUserProfile -Computer $CdmManagedComputer -Login $strMember
			}
			# Get AD User from User Profile
			if ($CdmUserProfile -ne [Void]$null)
			{
				# Get DN values for AD User and AD Group
				[System.String]$GroupADsPath = Get-ADsPath $Group.Group.distinguishedName
				[System.String]$UserDN = $CdmUserProfile.User.distinguishedName
				# Add User to Group
				if (Add-ADGroupMember -Identity $GroupADsPath -Members $UserDN)
				{
					$intNbImportedGroupMembers++
				}
			}
			else
			{
				Write-Warning ("No effective User Profile found for '{0}'. Membership addition skipped." -f $strMember)
			}
		}
		catch
		{
			# Unhandled Exception
			Throw $_.Exception
		}
	}

	# Print result
	Write-Host ("UNIX Group members imported`t: {0}`n" -f $intNbImportedGroupMembers)
	Sleep 1
	if ($Progress.IsPresent)
	{
		# Close progress bars
		Write-Progress -Activity "Group's members done" -Status "Hidden" -Id 4 -Completed
	}
	# Done.
}

###########################################################################################
# ADImport - Import-CentrifyRoles
#
# Specify the CSV File to import Roles into Zones and associate Rights to it.
# The CSV File format should be as below:
#
# Zone,Name(,AuditLevel,Description,UnixSysRights,HasRescueRight,AllowLocalUser)
#
# Zone                    The zone in which to create the role. You can specify either the Zone name or a distinguished name for this parameter.
# RoleName                The name of the role.
# RoleDescription         Description of the role. 
# RoleAuditLevel          Audit setting for this role.  You may specify any one of the following values:
#                            - no            Audit not requested/required
#                            - possible      Audit if possible
#                            - required      Audit required
# UnixSysRights           UNIX system rights granted to the role.  You can specify any combination of the following rights:
#                            - login         Password login and non-password (SSO) login are allowed
#                            - ssologin      Non-password (SSO) login is allowed
#                            - disableacc    Account disabled in Active Directory can be used by sudo, cron, etc.
#                            - nondzsh       Login with non-restricted shell
#                         separate values with comma to specify more than one values, e.g. for default "UNIX Login" Role: "login,ssologin,nondzsh"
# RoleHasRescueRight      Determines whether this role has the rescue system right. If true, this role can operate without being audited in case of audit system failure.
# RoleAllowLocalUser      Determines whether local users can be assigned this role. If true, local users can be assigned this role.
########
function Import-CentrifyRoles
{
	#######################################################################################
	param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "CSV data file to process.")]
		[System.String]$Data
	)
	#######################################################################################
	Write-Output ("Starting Roles import using {0} file..." -f $Data)
	# Import Unix Roles
	[System.Int32]$intNbImportedRoles = 0
	[System.Array]$arrRoleList = Import-CSV $Data
	if ($arrRoleList -eq [Void]$null)
	{
		Throw "Input file is in unattended format. Consider checking End Of Line characters that must be [CR][LF] on Windows system."
	}
	# Get list of Zones from Roles List
	[System.Array]$arrZoneList = $arrRoleList | Select-Object -Property Zone -Unique

	# Process Zone List
	[System.Int32]$z = 1
	[System.Int32]$intNbZones = $arrZoneList.Count
	[System.Int32]$all = 1
	[System.Int32]$intNbRoles = ($arrRoleList.Count)
	# Show progress for overall Roles import
	if ($Progress.IsPresent)
	{
		$OverallProgressActivity	= ("Import Roles [{0}/{1}]" -f $all, $intNbRoles)
		$OverallProgressStatus		= "Percent processed: "
		$OverallProgressComplete	= (($all / $intNbRoles)*100)
		Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
	}
	foreach ($objZone in $arrZoneList)
	{
		[System.String]$strZoneName = $objZone.Zone
		# Get Centrify Zone where to import Roles
		[Centrify.DirectControl.PowerShell.Types.CdmZone]$CdmZone = Get-CentrifyZone $strZoneName		
		# Validate that the Zone exist
		if ($CdmZone -ne [Void]$null)
		{
			if ($Progress.IsPresent)
			{
				# Show progress for Zone processing
				$ProgressActivity	= ("Centrify Zone '{0}' [{1}/{2}]" -f $CdmZone.Name, $z, $intNbZones)
				$ProgressStatus		= "Percent processed: "
				$ProgressComplete	= (($z++ / $intNbZones)*100)
				Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 2
			}
			# Get list of Roles from Roles List for the Current Zone
			[System.Array]$arrRoleListInCurrentZone = $arrRoleList | Where-Object { $_.Zone -eq $objZone.Zone } | Select-Object -Property Name -Unique
			# Process Roles List for the current Zone
			[System.Int32]$i = 1
			[System.Int32]$intNbRolesInCurrentZone = $arrRoleListInCurrentZone.Count
			foreach ($strRole in $arrRoleListInCurrentZone)
			{
				# Get Roles from Role and Rights List for the Current Zone
				[System.Array]$arrRoles = $arrRoleList | Where-Object { ($_.Zone -eq $objZone.Zone) -and ($_.Name -eq $strRole.Name) }
				# Ignore multiple entries to create Role
				$objRole = $arrRoles[0]
				if ($Progress.IsPresent)
				{
					# Show progress for overall Roles import
					$ProgressActivity	= ("Centrify Role '{0}' [{1}/{2}]" -f $objRole.Name, $i, $intNbRolesInCurrentZone)
					$ProgressStatus		= "Percent processed: "
					$ProgressComplete	= (($i++ / $intNbRolesInCurrentZone)*100)
					Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 3 -ParentId 2
				}
				##############################
				# Roles import
				##########
				try
				{
					# Set boolean values
					if ($objRole.HasRescueRight -eq "true")
					{
						[Boolean]$boolHasRescueRight = $true
					}
					else
					{
						[Boolean]$boolHasRescueRight = $false
					}
					if ($objRole.AllowLocalUser -eq "true")
					{
						[Boolean]$boolAllowLocalUser = $true
					}
					else
					{
						[Boolean]$boolAllowLocalUser = $false
					}
					# Data to Import: Zone,RoleName,RoleDescription,UnixSysRights,RoleAuditLevel,RoleHasRescueRight,RoleAllowLocalUser
					if ([System.String]::IsNullOrEmpty($objRole.UnixSysRights))
					{
						# Create Role without UnixSysRights (i.e. default value, all box unchecked)
						$CdmRole = New-CdmRole 	-Zone $CdmZone `
												-Name $objRole.Name `
												-Description $objRole.Description `
												-AuditLevel $objRole.AuditLevel `
												-HasRescueRight $boolHasRescueRight `
												-AllowLocalUser $boolAllowLocalUser
					}
					else
					{
						# Transform UnixSysRights in String[]
						[String[]]$arrUnixSysRights = $objRole.UnixSysRights.Split(',')
						# Create Role with UnixSysRights as defined in CSV file
						$CdmRole = New-CdmRole 	-Zone $CdmZone `
												-Name $objRole.Name `
												-Description $objRole.Description `
												-UnixSysRights $arrUnixSysRights `
												-AuditLevel $objRole.AuditLevel `
												-HasRescueRight $boolHasRescueRight `
												-AllowLocalUser $boolAllowLocalUser
					}
					# Count Role created
					if ($CdmRole -ne [Void]$null)
					{
						$intNbImportedRoles++
					}						
				}
				catch [System.ApplicationException]
				{
					if ($_.Exception.Message -match "Failed to commit the role. Reason: The object already exists.")
					{
						Write-Warning ("Duplicated role '{0}' in zone '{1}'." -f $objRole.Name, $CdmZone.Name)
						# Get the Role for next steps
						$CdmRole = Get-CdmRole -Zone $CdmZone -Name $objRole.Name
					}
					else
					{
						# Unhandled Exception
						Throw $_.Exception
					}
				}
				catch
				{
					# Unhandled Exception
					Throw $_.Exception
				}
			}
		}
		else
		{
			# Zone not found
			Write-Error ("Can't find any Zone named {0} in Active Directory." -f $objZone.Zone)
		}
	}			

	# Print result
	Write-Host ("Centrify Roles imported`t`t: {0}" -f $intNbImportedRoles)
	Write-Host "Done.`n"
	Sleep 1
	if ($Progress.IsPresent)
	{
		# Close progress bars
		Write-Progress -Activity "All Roles done" -Status "Hidden" -Id 1 -Completed
		Write-Progress -Activity "Zones done" -Status "Hidden" -Id 2 -Completed
		Write-Progress -Activity "Roles done" -Status "Hidden" -Id 3 -Completed
	}
	# Done.
}

###########################################################################################
# ADImport - Import-CentrifyUnixRights
#
# Specify the CSV File to import Roles and Rights into Zones.
# The CSV File format should be as below:
#
# Zone,Role,(RightType,Name,Description,Application,Pattern,PatternType,MatchPath,Priority,DzshRunAs,DzdoRunAsUser,DzdoRunAsGroup,KeepVar,DeleteVar,AddVar,Authentication,AllowNested,Umask)
#
# Zone                    The zone in which to create the role. You can specify either the Zone name or a distinguished name for this parameter.
# RoleName                The name of the role.
# RoleDescription         Description of the role. 
# RoleAuditLevel          Audit setting for this role.  You may specify any one of the following values:
#                            - no            Audit not requested/required
#                            - possible      Audit if possible
#                            - required      Audit required
# UnixSysRights           UNIX system rights granted to the role.  You can specify any combination of the following rights:
#                            - login         Password login and non-password (SSO) login are allowed
#                            - ssologin      Non-password (SSO) login is allowed
#                            - disableacc    Account disabled in Active Directory can be used by sudo, cron, etc.
#                            - nondzsh       Login with non-restricted shell
#                            - visible       User is visible with or without login rights
#                         This set of rights replaces any previously-assigned rights. For example, if you update UnixSysRights with the "login","ssologin" rights,
#                         only those rights will be set for the role. Any other rights previously defined will be removed. Specify an empty array ("@()") if you want
#                         to clear all UNIX system rights.
# RoleHasRescueRight      Determines whether this role has the rescue system right. If true, this role can operate without being audited in case of audit system failure.
# RoleAllowLocalUser      Determines whether local users can be assigned this role. If true, local users can be assigned this role.
# PamName                 The name of the PAM access right.
# PamDescription          Description of the PAM access right.
# PamApplication          The PAM application.
# CommandName             The name of the command right.
# CommandDescription      Description of the command right.
# CommandPattern          The pattern to match when looking for the command.
# CommandPatternType      The type of the command-matching pattern.  You may specify one of the following values:
#                            - glob      Glob expression
#                            - regexp    Regular expression
# CommandMatchPath        The path to use when matching the command.  You can specify one of the following values:
#                            - "USERPATH"     		Standard user path
#                            - "SYSTEMPATH"   		Standard system path
#                            - "SYSTEMSEARCHPATH"	System search path
#                            - Other strings		Custom specific path
# CommandPriority         The priority of the command.
# CommandDzshRunAs        The user this command runs under when using dzsh. You can specify one of the following values:
#                            - "$"            run as current user
#                            - ""             this command cannot be run in dzsh
#                            - Other string   a specific user
# CommandDzdoRunAsUser    Users allowed to run this command using dzdo. Specify a comma-separated list, or specify one of the following values:
#                            - "*"  can run as any user enabled for the zone
#                            -  ""   cannot run as any user
#                         Note: If you specify empty strings for both parameters DzdoRunAsUser and DzdoRunAsGroup, then this command cannot be run using dzdo.
# CommandDzdoRunAsGroup   Groups allowed to run this command using dzdo. Specify a comma-separated list, or specify one of the following values:
#                            - "*"  can run as any group enabled for the zone
#                            - ""   cannot run as any group
#                         Note: If you specify empty strings for both parameters DzdoRunAsUser and DzdoRunAsGroup, then this command cannot be run using dzdo.
# CommandKeepVar          Environment variables to keep when dzdo is run. The dzdo.env_keep configuration parameter in the centrifydc.conf file defines a default set of environment variables to retain from the current user's environment when the dzdo command is run. This parameter lists environment variables to keep in addition to the default set.
#                         Specify a comma-separated list of variables; or you can specify an empty string to indicate there are no variables to keep other than the default set. Use the DeleteVar parameter to remove variables from the default set.
#                         You cannot specify both the KeepVar and DeleteVar parameters.
# CommandDeleteVar        Environment variables to delete when dzdo is run. The dzdo.env_keep configuration parameter in the centrifydc.conf file defines a default set of environment variables to retain from the current user's environment when the dzdo command is run. This parameter lists environment variables to remove from the default set.
#                         Specify a comma-separated list of variables; or you can specify an empty string to indicate there are no variables to delete from the default set. Use the KeepVar parameter to add variables to the default set.
#                         You cannot specify both the KeepVar and DeleteVar parameters.
# CommandAddVar           Environment variable name-value pairs to add to the final set of environment variables resulting from the keep or delete sets described in the KeepVar and DeleteVar parameters.
#                         Specify a comma-separated list of name-value pairs specified as "name=value"; or you can specify an empty string to indicate there are no variables to add.
# CommandAuthentication   type of authentication needed to run the command. You can specify one of the following values:
#                            - none          no authentication is required
#                            - user          authentication is required with current user's password
#                            - runastarget   authentication is required with run-as target user's password
#  
########
function Import-CentrifyUnixRights
{
	#######################################################################################
	param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "CSV data file to process.")]
		[System.String]$Data
	)
	#######################################################################################
	Write-Output ("Starting Unix Rights import using {0} file..." -f $Data)
	# Import Unix Roles
	[System.Int32]$intNbImportedPamRights = 0
	[System.Int32]$intNbImportedCommandRights = 0
	[System.Array]$arrUnixRightsList = Import-CSV $Data
	if ($arrUnixRightsList -eq [Void]$null)
	{
		Throw "Input file is in unattended format. Consider checking End Of Line characters that must be [CR][LF] on Windows system."
	}
	# Get list of Zones from Unix Rights List
	[System.Array]$arrZoneList = $arrUnixRightsList | Select-Object -Property Zone -Unique

	# Process Zone List
	[System.Int32]$z = 1
	[System.Int32]$intNbZones = $arrZoneList.Count
	[System.Int32]$all = 1
	[System.Int32]$intNbUnixRights = ($arrUnixRightsList.Count)
	# Show progress for overall Roles and Rights import
	if ($Progress.IsPresent)
	{
		$OverallProgressActivity	= ("Import Unix Rights [{0}/{1}]" -f $all, $intNbUnixRights)
		$OverallProgressStatus		= "Percent processed: "
		$OverallProgressComplete	= (($all / $intNbUnixRights)*100)
		Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
	}
	foreach ($objZone in $arrZoneList)
	{
		[System.String]$strZoneName = $objZone.Zone
		# Get Centrify Zone where to import Unix Rights
		[Centrify.DirectControl.PowerShell.Types.CdmZone]$CdmZone = Get-CentrifyZone $strZoneName
		# Validate that the Zone exist
		if ($CdmZone -ne [Void]$null)
		{
			if ($Progress.IsPresent)
			{
				# Show progress for Zone processing
				$ProgressActivity	= ("Centrify Zone '{0}' [{1}/{2}]" -f $CdmZone.Name, $z, $intNbZones)
				$ProgressStatus		= "Percent processed: "
				$ProgressComplete	= (($z++ / $intNbZones)*100)
				Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 2
			}
			# Get Roles from Unix Rights List for the Current Zone
			[System.Array]$arrRoleListInCurrentZone = $arrUnixRightsList | Where-Object { $_.Zone -eq $objZone.Zone } | Select-Object -Property Role -Unique
			# Process Unix Rights List for each Role in the Current Zone
			foreach ($strRole in $arrRoleListInCurrentZone)
			{
				$CdmRole = Get-CdmRole -Zone $CdmZone -Name $strRole.Role
				if ($CdmRole -eq [Void]$null)
				{
					Throw ("Unable to find Role '{0}' in Zone named '{1}'." -f $strRole.Role, $CdmZone.Name)
				}
				# Show progress for Role processing
				if ($Progress.IsPresent)
				{
					# Show progress for overall Role and Rights import
					$ProgressActivity	= ("Centrify Role '{0}' [{1}/{2}]" -f $CdmRole.Name, $i, $intNbRolesInCurrentZone)
					$ProgressStatus		= "Percent processed: "
					$ProgressComplete	= (($i++ / $intNbRolesInCurrentZone)*100)
					Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 3 -ParentId 2
				}
				[System.Array]$arrCommandRightsList = $arrUnixRightsList | Where-Object { $_.Zone -eq $objZone.Zone -and $_.Role -eq $CdmRole.Name -and $_.RightType -eq "Command" }
				# Process Command Rights List for the current Role
				[System.Int32]$j = 1
				[System.Int32]$intNbCommandsInCurrentRole = $arrCommandRightsList.Count
				foreach ($objCommand in $arrCommandRightsList)
				{
					##############################
					# Command Rights import
					##########
					try
					{
						if ($Progress.IsPresent)
						{
							# Show progress for Unix Rights import for this Role
							$OverallProgressActivity	= ("Import Command Rights [{0}/{1}]" -f $arrCommandRightsList, $intNbUnixRights)
							$OverallProgressStatus		= "Percent processed: "
							$OverallProgressComplete	= (($all++ / $intNbUnixRights)*100)
							Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1						# Show progress for Computer import
						}
						# Data to Import: Name,Description,Application,Pattern,PatternType,MatchPath,Priority,DzshRunAs,DzdoRunAsUser,DzdoRunAsGroup,KeepVar,DeleteVar,AddVar,Authentication,AllowNested,Umask
						# Create the Command Right
						$CdmCommandRight = New-CdmCommandRight 	-Zone $CdmZone `
																-Name $objCommand.Name `
																-Description $objCommand.Description `
																-Pattern $objCommand.Pattern `
																-PatternType $objCommand.PatternType `
																-MatchPath $objCommand.MatchPath `
																-Priority $objCommand.Priority `
																-DzshRunas $objCommand.DzshRunAs `
																-DzdoRunAsUser $objCommand.DzdoRunAsUser `
																-DzdoRunAsGroup $objRole.DzdoRunAsGroup `
																-KeepVar $objCommand.KeepVar `
																-DeleteVar $objCommand.DeleteVar `
																-AddVar $objCommand.AddVar `
																-Authentication $objCommand.Authentication
						# Count Commands created
						if ($CdmCommandRight -ne [Void]$null)
						{
							$intNbImportedCommandRights++
						}
					}
					catch [System.ApplicationException]
					{
						if ($_.Exception.Message -match "A command right with the name .* already exists, please use a different name.")
						{
							Write-Warning ("Duplicated command right '{0}' in zone '{1}'." -f $objCommand.Name, $CdmZone.Name)
							# Get the Command Rights for next steps
							$CdmCommandRight = Get-CdmCommandRight -Zone $CdmZone -Name $objCommand.Name
						}
						else
						{
							# Unhandled Exception
							Throw $_.Exception
						}
					}
					catch
					{
						# Unhandled Exception
						Throw $_.Exception
					}
					##############################
					# Assign rights to this Role
					##########
					try
					{
						# Get Command Rights from the Role
						$AssignedCdmCommandRight = Get-CdmCommandRight -Role $CdmRole -Name $objCommand.Name
						if ($AssignedCdmCommandRight -eq [Void]$null)
						{
							# Add Command rights to this Role except if exist
							if ($CdmCommandRight -ne [Void]$null)
							{
								[Void](Add-CdmCommandRight -Role $CdmRole -Right $CdmCommandRight)
							}
						}
						else
						{
							Write-Warning ("Command right '{0}' is already added to role '{1}'." -f $objCommand.Name, $CdmRole.Name)
						}
					}
					catch
					{
						# Unhandled Exception
						Throw $_.Exception
					}
				}
				
				[System.Array]$arrPamRightsList = $arrUnixRightsList | Where-Object { $_.Zone -eq $objZone.Zone -and $_.Role -eq $CdmRole.Name -and $_.RightType -eq "PamAccess" }
				# Process PAM Access Rights List for the current Role
				[System.Int32]$j = 1
				[System.Int32]$intNbPamAccessInCurrentRole = $arrPamRightsList.Count
				foreach ($objPamAccess in $arrPamRightsList)
				{
					##############################
					# PAM Rights import
					##########
					try
					{
						if ($Progress.IsPresent)
						{
							# Show progress for Unix Rights import for this Role
							$OverallProgressActivity	= ("Import PAM Access Rights [{0}/{1}]" -f $arrPamRightsList, $intNbUnixRights)
							$OverallProgressStatus		= "Percent processed: "
							$OverallProgressComplete	= (($all++ / $intNbUnixRights)*100)
							Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1						# Show progress for Computer import
						}
						# Data to Import: Name,Description,Application,Pattern,PatternType,MatchPath,Priority,DzshRunAs,DzdoRunAsUser,DzdoRunAsGroup,KeepVar,DeleteVar,AddVar,Authentication,AllowNested,Umask
						# Create the PAM Access Right
						$CdmPamRight = New-CdmPamRight 	-Zone $CdmZone `
														-Name $objPamAccess.Name `
														-Description $objPamAccess.Description `
														-Application $objPamAccess.Application
						# Count Commands created
						if ($CdmPamRight -ne [Void]$null)
						{
							$intNbImportedPamRights++
						}
					}
					catch [System.ApplicationException]
					{
						if ($_.Exception.Message -match "A PAM access right with the name .* already exists, please use a different name.")
						{
							Write-Warning ("Duplicated PAM Access right '{0}' in zone '{1}'." -f $objPamAccess.Name, $CdmZone.Name)
							# Get the Pam Access Rights for next steps
							$CdmPamRight = Get-CdmPamRight -Zone $CdmZone -Name $objPamAccess.Name
						}
						else
						{
							# Unhandled Exception
							Throw $_.Exception
						}
					}
					catch
					{
						# Unhandled Exception
						Throw $_.Exception
					}
					##############################
					# Assign rights to this Role
					##########
					try
					{
						# Get Pam Rights from the Role
						$AssignedCdmPamRight = Get-CdmPamRight -Role $CdmRole -Name $objPamAccess.Name
						if ($AssignedCdmPamRight -eq [Void]$null)
						{
							# Add Pam rights to this Role except if exist
							if ($CdmPamRight -ne [Void]$null)
							{
								[Void](Add-CdmPamRight -Role $CdmRole -Right $CdmPamRight)
							}
						}
						else
						{
							Write-Warning ("Command right '{0}' is already added to role '{1}'." -f $objPamAccess.Name, $CdmRole.Name)
						}
					}
					catch
					{
						# Unhandled Exception
						Throw $_.Exception
					}
				}
			}
		}
		else
		{
			# Zone not found
			Write-Error ("Can't find any Zone named {0} in Active Directory." -f $objZone.Zone)
		}
	}			

	# Print result
	Write-Host ("PAM Access rights imported`t: {0}" -f $intNbImportedPamRights)
	Write-Host ("Commands rights imported`t: {0}" -f $intNbImportedCommandRights)
	Write-Host "Done.`n"
	Sleep 1
	if ($Progress.IsPresent)
	{
		# Close progress bars
		Write-Progress -Activity "All Unix Rights done" -Status "Hidden" -Id 1 -Completed
		Write-Progress -Activity "Zones done" -Status "Hidden" -Id 2 -Completed
		Write-Progress -Activity "Pam Access rights done" -Status "Hidden" -Id 7 -Completed
		Write-Progress -Activity "Command rights done" -Status "Hidden" -Id 8 -Completed
	}
	# Done.
}

<#
###########################################################################################
# ADImport - Import-CentrifyRolesAndRights
#
# Specify the CSV File to import Roles and Rights into Zones.
# The CSV File format should be as below:
#
# Zone,RoleName,RoleAuditLevel(,RoleDescription,UnixSysRights,RoleHasRescueRight,RoleAllowLocalUser,PamName,PamDescription,PamApplication,CommandName,CommandDescription,CommandPattern,CommandPatternType,CommandMatchPath,CommandPriority,CommandDzshRunAs,CommandDzdoRunAsUser,CommandDzdoRunAsGroup,CommandKeepVar,CommandDeleteVar,CommandAddVar,CommandAuthentication)
#
# Zone                    The zone in which to create the role. You can specify either the Zone name or a distinguished name for this parameter.
# RoleName                The name of the role.
# RoleDescription         Description of the role. 
# RoleAuditLevel          Audit setting for this role.  You may specify any one of the following values:
#                            - no            Audit not requested/required
#                            - possible      Audit if possible
#                            - required      Audit required
# UnixSysRights           UNIX system rights granted to the role.  You can specify any combination of the following rights:
#                            - login         Password login and non-password (SSO) login are allowed
#                            - ssologin      Non-password (SSO) login is allowed
#                            - disableacc    Account disabled in Active Directory can be used by sudo, cron, etc.
#                            - nondzsh       Login with non-restricted shell
#                         separate values with comma to specify more than one values, e.g. for default "UNIX Login" Role: "login,ssologin,nondzsh"
# RoleHasRescueRight      Determines whether this role has the rescue system right. If true, this role can operate without being audited in case of audit system failure.
# RoleAllowLocalUser      Determines whether local users can be assigned this role. If true, local users can be assigned this role.
# PamName                 The name of the PAM access right.
# PamDescription          Description of the PAM access right.
# PamApplication          The PAM application.
# CommandName             The name of the command right.
# CommandDescription      Description of the command right.
# CommandPattern          The pattern to match when looking for the command.
# CommandPatternType      The type of the command-matching pattern.  You may specify one of the following values:
#                            - glob      Glob expression
#                            - regexp    Regular expression
# CommandMatchPath        The path to use when matching the command.  You can specify one of the following values:
#                            - "USERPATH"     		Standard user path
#                            - "SYSTEMPATH"   		Standard system path
#                            - "SYSTEMSEARCHPATH"	System search path
#                            - Other strings		Custom specific path
# CommandPriority         The priority of the command.
# CommandDzshRunAs        The user this command runs under when using dzsh. You can specify one of the following values:
#                            - "$"            run as current user
#                            - ""             this command cannot be run in dzsh
#                            - Other string   a specific user
# CommandDzdoRunAsUser    Users allowed to run this command using dzdo. Specify a comma-separated list, or specify one of the following values:
#                            - "*"  can run as any user enabled for the zone
#                            -  ""   cannot run as any user
#                         Note: If you specify empty strings for both parameters DzdoRunAsUser and DzdoRunAsGroup, then this command cannot be run using dzdo.
# CommandDzdoRunAsGroup   Groups allowed to run this command using dzdo. Specify a comma-separated list, or specify one of the following values:
#                            - "*"  can run as any group enabled for the zone
#                            - ""   cannot run as any group
#                         Note: If you specify empty strings for both parameters DzdoRunAsUser and DzdoRunAsGroup, then this command cannot be run using dzdo.
# CommandKeepVar          Environment variables to keep when dzdo is run. The dzdo.env_keep configuration parameter in the centrifydc.conf file defines a default set of environment variables to retain from the current user's environment when the dzdo command is run. This parameter lists environment variables to keep in addition to the default set.
#                         Specify a comma-separated list of variables; or you can specify an empty string to indicate there are no variables to keep other than the default set. Use the DeleteVar parameter to remove variables from the default set.
#                         You cannot specify both the KeepVar and DeleteVar parameters.
# CommandDeleteVar        Environment variables to delete when dzdo is run. The dzdo.env_keep configuration parameter in the centrifydc.conf file defines a default set of environment variables to retain from the current user's environment when the dzdo command is run. This parameter lists environment variables to remove from the default set.
#                         Specify a comma-separated list of variables; or you can specify an empty string to indicate there are no variables to delete from the default set. Use the KeepVar parameter to add variables to the default set.
#                         You cannot specify both the KeepVar and DeleteVar parameters.
# CommandAddVar           Environment variable name-value pairs to add to the final set of environment variables resulting from the keep or delete sets described in the KeepVar and DeleteVar parameters.
#                         Specify a comma-separated list of name-value pairs specified as "name=value"; or you can specify an empty string to indicate there are no variables to add.
# CommandAuthentication   type of authentication needed to run the command. You can specify one of the following values:
#                            - none          no authentication is required
#                            - user          authentication is required with current user's password
#                            - runastarget   authentication is required with run-as target user's password
#  
########
function Import-CentrifyRolesAndRights
{
	#######################################################################################
	param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "CSV data file to process.")]
		[System.String]$Data
	)
	#######################################################################################
	Write-Output ("Starting Roles and Rights import using {0} file..." -f $Data)
	# Import Unix Roles
	[System.Int32]$intNbImportedRoles = 0
	[System.Int32]$intNbImportedDesktopRights = 0
	[System.Int32]$intNbImportedApplicationRights = 0
	[System.Int32]$intNbImportedNetworkAccessRights = 0
	[System.Int32]$intNbImportedPamRights = 0
	[System.Int32]$intNbImportedCommandRights = 0
	[System.Array]$arrRoleAndRightsList = Import-CSV $Data
	if ($arrRoleAndRightsList -eq [Void]$null)
	{
		Throw "Input file is in unattended format. Consider checking End Of Line characters that must be [CR][LF] on Windows system."
	}
	# Get list of Zones from Role And Rights List
	[System.Array]$arrZoneList = $arrRoleAndRightsList | Select-Object -Property Zone -Unique

	# Process Zone List
	[System.Int32]$z = 1
	[System.Int32]$intNbZones = $arrZoneList.Count
	[System.Int32]$all = 1
	[System.Int32]$intNbRolesAndRights = ($arrRoleAndRightsList.Count)
	# Show progress for overall Roles and Rights import
	if ($Progress.IsPresent)
	{
		$OverallProgressActivity	= ("Import Roles and Rights [{0}/{1}]" -f $all, $intNbRolesAndRights)
		$OverallProgressStatus		= "Percent processed: "
		$OverallProgressComplete	= (($all / $intNbRolesAndRights)*100)
		Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
	}
	foreach ($objZone in $arrZoneList)
	{
		[System.String]$strZoneName = $objZone.Zone
		# Get Centrify Zone where to import Roles and Rights
		[Centrify.DirectControl.PowerShell.Types.CdmZone]$CdmZone = Get-CentrifyZone $strZoneName
		# Validate that the Zone exist
		if ($CdmZone -ne [Void]$null)
		{
			if ($Progress.IsPresent)
			{
				# Show progress for Zone processing
				$ProgressActivity	= ("Centrify Zone '{0}' [{1}/{2}]" -f $CdmZone.Name, $z, $intNbZones)
				$ProgressStatus		= "Percent processed: "
				$ProgressComplete	= (($z++ / $intNbZones)*100)
				Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 2
			}
			# Get list of Roles from Role and Rights List for the Current Zone
			[System.Array]$arrRoleListInCurrentZone = $arrRoleAndRightsList | Where-Object { $_.Zone -eq $objZone.Zone } | Select-Object -Property RoleName -Unique
			# Process Roles List for the current Zone
			[System.Int32]$i = 1
			[System.Int32]$intNbRolesInCurrentZone = $arrRoleListInCurrentZone.Count
			foreach ($strRole in $arrRoleListInCurrentZone)
			{
				# Get Roles from Role and Rights List for the Current Zone
				[System.Array]$arrRoles = $arrRoleAndRightsList | Where-Object { ($_.Zone -eq $objZone.Zone) -and ($_.RoleName -eq $strRole.RoleName) }
				# Ignore multiple entries to create Role
				$objRole = $arrRoles[0]
				if ($Progress.IsPresent)
				{
					# Show progress for overall Role and Rights import
#					$OverallProgressActivity	= ("Import Roles and Rights [{0}/{1}]" -f $all, $intNbRolesAndRights)
#					$OverallProgressStatus		= "Percent processed: "
#					$OverallProgressComplete	= (($all++ / $intNbRolesAndRights)*100)
#					Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1						# Show progress for Computer import
					$ProgressActivity	= ("Centrify Role '{0}' [{1}/{2}]" -f $objRole.RoleName, $i, $intNbRolesInCurrentZone)
					$ProgressStatus		= "Percent processed: "
					$ProgressComplete	= (($i++ / $intNbRolesInCurrentZone)*100)
					Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 3 -ParentId 2
				}
				##############################
				# Roles import
				##########
				try
				{
					# Set boolean values
					if ($objRole.RoleHasRescueRight -eq "true")
					{
						[Boolean]$boolHasRescueRight = $true
					}
					else
					{
						[Boolean]$boolHasRescueRight = $false
					}
					if ($objRole.RoleAllowLocalUser -eq "true")
					{
						[Boolean]$boolAllowLocalUser = $true
					}
					else
					{
						[Boolean]$boolAllowLocalUser = $false
					}
					# Data to Import: Zone,RoleName,RoleDescription,UnixSysRights,RoleAuditLevel,RoleHasRescueRight,RoleAllowLocalUser
					if ([System.String]::IsNullOrEmpty($objRole.UnixSysRights))
					{
						# Create Role without UnixSysRights (i.e. default value, all box unchecked)
						$CdmRole = New-CdmRole -Zone $CdmZone -Name $objRole.RoleName -Description $objRole.RoleDescription -AuditLevel $objRole.RoleAuditLevel -HasRescueRight $boolHasRescueRight -AllowLocalUser $boolAllowLocalUser
					}
					else
					{
						# Transform UnixSysRights in String[]
						[String[]]$arrUnixSysRights = $objRole.UnixSysRights.Split(',')
						# Create Role with UnixSysRights as defined in CSV file
						$CdmRole = New-CdmRole -Zone $CdmZone -Name $objRole.RoleName -Description $objRole.RoleDescription -UnixSysRights $arrUnixSysRights -AuditLevel $objRole.RoleAuditLevel -HasRescueRight $boolHasRescueRight -AllowLocalUser $boolAllowLocalUser
					}
					# Count Role created
					if ($CdmRole -ne [Void]$null)
					{
						$intNbImportedRoles++
					}						
				}
				catch [System.ApplicationException]
				{
					if ($_.Exception.Message -match "Failed to commit the role. Reason: The object already exists.")
					{
						Write-Warning ("Duplicated role '{0}' in zone '{1}'." -f $objRole.RoleName, $CdmZone.Name)
						# Get the Role for next steps
						$CdmRole = Get-CdmRole -Zone $CdmZone -Name $objRole.RoleName
					}
					else
					{
						# Unhandled Exception
						Throw $_.Exception
					}
				}
				catch
				{
					# Unhandled Exception
					Throw $_.Exception
				}
				# Get Command rights for this Role
				[System.Array]$arrCommandRightsList = $arrRoles | Where-Object { ($_.CommandName -ne [Void]$null) }
				# Process Command Rights List for the current Role
				[System.Int32]$j = 1
				[System.Int32]$intNbCommandsInCurrentRole = $arrCommandRightsList.Count
				foreach ($objCommand in $arrCommandRightsList)
				{
					##############################
					# Command Rights import
					##########
					try
					{
						if ($Progress.IsPresent)
						{
							# Show progress for overall Role and Rights import
							$OverallProgressActivity	= ("Import Roles and Rights [{0}/{1}]" -f $all, $intNbRolesAndRights)
							$OverallProgressStatus		= "Percent processed: "
							$OverallProgressComplete	= (($all++ / $intNbRolesAndRights)*100)
							Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1						# Show progress for Computer import
							$ProgressActivity	= ("Command Rights [{0}/{1}]" -f $j, $intNbCommandsInCurrentRole)
							$ProgressStatus		= "Percent processed: "
							$ProgressComplete	= (($j++ / $intNbCommandsInCurrentRole)*100)
							Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 8 -ParentId 3
						}
						# Data to Import: CommandName,CommandDescription,CommandPattern,CommandPatternType,CommandMatchPath,CommandPriority,CommandDzshRunAs,CommandDzdoRunAsUser,CommandDzdoRunAsGroup,CommandKeepVar,CommandDeleteVar,CommandAddVar,CommandAuthentication
						if (-not [System.String]::IsNullOrEmpty($objRole.CommandPattern))
						{
							# Create the Command Right
							$CdmCommandRight = New-CdmCommandRight -Zone $CdmZone -Name $objCommand.CommandName -Description $objCommand.CommandDescription -Pattern $objCommand.CommandPattern -PatternType $objCommand.CommandPatternType -MatchPath $objCommand.CommandMatchPath -Priority $objCommand.CommandPriority -DzshRunas $objCommand.CommandDzshRunAs -DzdoRunAsUser $objCommand.CommandDzdoRunAsUser -DzdoRunAsGroup $objRole.CommandDzdoRunAsGroup -KeepVar $objCommand.CommandKeepVar -DeleteVar $objCommand.CommandDeleteVar -AddVar $objCommand.CommandAddVar -Authentication $objCommand.CommandAuthentication
							# Count Commands created
							if ($CdmCommandRight -ne [Void]$null)
							{
								$intNbImportedCommandRights++
							}
						}
						else
						{
							# Validate the Command Right already exists and that Pattern was let blank on purpose
							if ((Get-CdmCommandRight -Zone $CdmZone -Name $objCommand.CommandName) -eq [Void]$null)
							{
								# Command Right don't exists and should have been created. Missing mandatory parameter Pattern.
								#Write-Error "Pattern value is needed to create a command right."
							}
						}
					}
					catch [System.ApplicationException]
					{
						if ($_.Exception.Message -match "A command right with the name .* already exists, please use a different name.")
						{
							Write-Warning ("Duplicated command right '{0}' in zone '{1}'." -f $objRole.CommandName, $CdmZone.Name)
							# Get the Command Rights for next steps
							$CdmCommandRight = Get-CdmCommandRight -Zone $CdmZone -Name $objCommand.CommandName
						}
						else
						{
							# Unhandled Exception
							Throw $_.Exception
						}
					}
					catch
					{
						# Unhandled Exception
						Throw $_.Exception
					}
					##############################
					# Assign rights to this Role
					##########
					try
					{
						# Get Command Rights from the Role
						$AssignedCdmCommandRight = Get-CdmCommandRight -Role $CdmRole -Name $objCommand.CommandName
						if ($AssignedCdmCommandRight -eq [Void]$null)
						{
							# Add Command rights to this Role except if exist
							if ($CdmCommandRight -ne [Void]$null)
							{
								[Void](Add-CdmCommandRight -Role $CdmRole -Right $CdmCommandRight)
							}
						}
						else
						{
							Write-Warning ("Command right '{0}' is already added to role '{1}'." -f $objCommand.CommandName, $CdmRole.Name)
						}
					}
					catch
					{
						# Unhandled Exception
						Throw $_.Exception
					}
				}
			}
		}
		else
		{
			# Zone not found
			Write-Error ("Can't find any Zone named {0} in Active Directory." -f $objZone.Zone)
		}
	}			

	# Print result
	Write-Host ("Centrify Roles imported`t`t: {0}" -f $intNbImportedRoles)
#	Write-Host ("Desktop rights imported`t`t: {0}" -f $intNbImportedDesktopRights)
#	Write-Host ("Application rights imported`t: {0}" -f $intNbImportedApplicationRights)
#	Write-Host ("Network Access rights imported`t: {0}" -f $intNbImportedNetworkAccessRights)
	Write-Host ("PAM Access rights imported`t: {0}" -f $intNbImportedPamRights)
	Write-Host ("Commands rights imported`t: {0}" -f $intNbImportedCommandRights)
	Write-Host "Done.`n"
	Sleep 1
	if ($Progress.IsPresent)
	{
		# Close progress bars
		Write-Progress -Activity "All Roles and Rights done" -Status "Hidden" -Id 1 -Completed
		Write-Progress -Activity "Zones done" -Status "Hidden" -Id 2 -Completed
		Write-Progress -Activity "Roles done" -Status "Hidden" -Id 3 -Completed
#		Write-Progress -Activity "Desktop rights done" -Status "Hidden" -Id 4 -Completed
#		Write-Progress -Activity "Application done" -Status "Hidden" -Id 5 -Completed
#		Write-Progress -Activity "Network Access rights done" -Status "Hidden" -Id 6 -Completed
		Write-Progress -Activity "Pam Access rights done" -Status "Hidden" -Id 7 -Completed
		Write-Progress -Activity "Command rights done" -Status "Hidden" -Id 8 -Completed
	}
	# Done.
}
#>
###########################################################################################
# ADImport - Import-CentrifyComputerRoles
#
# Specify the CSV File to import Centrify Computer Roles into Zones.
# The CSV File format should be as below:
#
# Zone,Name,Description,Group(,Container,Members)
#
# Zone          The zone of the computer role. You can specify either the Zone name or a distinguished name for this parameter.
# Name          Name of the computer role.
# Description   Description of the computer role.
# Group         The computer group to associate with this computer role. You may specify any of the following values for this parameter:
#                  - distinguishedName
#                  - SID
#				  - samAccountName
#                  - <samAccountName>@<domain>
# Container     The Active Directory container in which the AD group is to be created. This can be ignored if the AD Group already exists.
# Members       List of Computer hostnames and/or AD groups members of the Computer Role (can be ignored)
#  
########
function Import-CentrifyComputerRoles
{
	#######################################################################################
	param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "CSV data file to process.")]
		[System.String]$Data
	)
	#######################################################################################
	Write-Output ("Starting Computer Roles import using {0} file..." -f $Data)
	# Import Unix Groups
	[System.Int32]$intNbImportedComputerRoles = 0
	[System.Array]$arrComputerRoleList = Import-CSV $Data
	if ($arrComputerRoleList -eq [Void]$null)
	{
		Throw "Input file is in unattended format. Consider checking End Of Line characters that must be [CR][LF] on Windows system."
	}
	# Get list of Zones from Computer Role List
	[System.Array]$arrZoneList = $arrComputerRoleList | Select-Object -Property Zone -Unique

	# Process Zone List
	[System.Int32]$z = 1
	[System.Int32]$intNbZones = $arrZoneList.Count
	[System.Int32]$all = 1
	[System.Int32]$intNbComputerRoles = $arrComputerRoleList.Count
	# Show progress for overall Computer Role import
	if ($Progress.IsPresent)
	{
		$OverallProgressActivity	= ("Import UNIX ComputerRoles [{0}/{1}]" -f $all, $intNbComputerRoles)
		$OverallProgressStatus		= "Percent processed: "
		$OverallProgressComplete	= (($all / $intNbComputerRoles)*100)
		Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
	}
	foreach ($objZone in $arrZoneList)
	{
		[System.String]$strZoneName = $objZone.Zone
		# Get Centrify Zone where to import Unix Profile
		[Centrify.DirectControl.PowerShell.Types.CdmZone]$CdmZone = Get-CentrifyZone $strZoneName
		# Validate that the Zone exist
		if ($CdmZone -ne [Void]$null)
		{
			if ($Progress.IsPresent)
			{
				# Show progress for Zone processing
				$ProgressActivity	= ("Centrify Zone '{0}' [{1}/{2}]" -f $CdmZone.Name, $z, $intNbZones)
				$ProgressStatus		= "Percent processed: "
				$ProgressComplete	= (($z++ / $intNbZones)*100)
				Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 2
			}
			# Process Computer Role List for the current Zone
			[System.Array]$arrComputerRoleListInCurrentZone = $arrComputerRoleList | Where-Object { $_.Zone -eq $objZone.Zone }
			[System.Int32]$i = 1
			[System.Int32]$intNbComputerRolesInCurrentZone = $arrComputerRoleListInCurrentZone.Count
			foreach ($objComputerRole in $arrComputerRoleListInCurrentZone)
			{
				if ($Progress.IsPresent)
				{
					# Show progress for overall Computer import
					$OverallProgressActivity	= ("Import Computer Roles [{0}/{1}]" -f $all, $intNbComputerRoles)
					$OverallProgressStatus		= "Percent processed: "
					$OverallProgressComplete	= (($all++ / $intNbComputerRoles)*100)
					Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
					# Show progress for Computer import
					$ProgressActivity	= ("Computer Role '{0}' [{1}/{2}]" -f $objComputerRole.Name, $i, $intNbComputerRolesInCurrentZone)
					$ProgressStatus		= "Percent processed: "
					$ProgressComplete	= (($i++ / $intNbComputerRolesInCurrentZone)*100)
					Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 3 -ParentId 2
				}
				try
				{
					# Format ComputerRole to {samAccountName}@{Domain} if needed
					if ($objComputerRole.Group -notmatch "^.*@.*$")
					{
						$objComputerRole.Group = ("{0}@{1}" -f $objComputerRole.Group, $Domain)
					}
					# Data to Import: Zone,Group,UnixName,GID(,Members)
					[Centrify.DirectControl.PowerShell.Types.CdmComputerRole]$CdmComputerRole = New-CdmComputerRole 	-Zone $CdmZone `
																														-Name $objComputerRole.Name `
																														-Description $objComputerRole.Description `
																														-Group $objComputerRole.Group
					# Count Computer Role created
					if ($CdmComputerRole -ne [Void]$null)
					{
						$intNbImportedComputerRoles++
					}
				}
				catch [System.ApplicationException]
				{
					if ($_.Exception.Message -match "Computer role .* already exists, please use a different name.")
					{
						Write-Warning $_.Exception.Message
						# Get Computer Roles for members management
						[Centrify.DirectControl.PowerShell.Types.CdmComputerRole]$CdmComputerRole = Get-CdmComputerRole -Zone $CdmZone -Name $objComputerRole.Name
					}
					else
					{
						# Unhandled Exception
						Throw $_.Exception
					}
				}
				catch
				{
					if ($_.Exception.Message -match "Failed to get object .*")
					{
						# AD Group not found in AD, create it under given Container
						if (-not [System.String]::IsNullOrEmpty($objComputerRole.Container))
						{
							# Create AD Security Group
							[System.String]$strGroupName = $objComputerRole.Group.Split("@")[0]
							[System.String]$strADGroupDN = New-ADSecurityGroup -Name $strGroupName -Container $objComputerRole.Container
							# Create the Computer Role using the created AD Group
							[Centrify.DirectControl.PowerShell.Types.CdmComputerRole]$CdmComputerRole = New-CdmComputerRole 	-Zone $CdmZone `
																																-Name $objComputerRole.Name `
																																-Description $objComputerRole.Description `
																																-Group $strADGroupDN
							# Count Computer Role created
							if ($CdmComputerRole -ne [Void]$null)
							{
								$intNbImportedComputerRoles++
							}
						}
						else
						{
							# AD Group not found and Container wasn't specified
							Write-Error ("{0}, you must specify a Container if you want to create the Computer Role's AD Group." -f $_.Exception.Message)
						}
					}
					else
					{
						# Unhandled Exception
						Throw $_.Exception
					}
				}
				# Import Computer Role members
				if (-not [System.String]::IsNullOrEmpty($objComputerRole.members))
				{
					[System.String[]]$strMembers = $objComputerRole.members.Split(',')
					Import-CentrifyComputerRoleMembers $CdmComputerRole $strMembers
				}
			}
		}
		else
		{
			# Zone not found
			Write-Error ("Can't find any Zone named {0} in Active Directory." -f $objZone.Zone)
		}
	}			

	# Print result
	Write-Host ("Computer Roles imported`t: {0}`nDone.`n" -f $intNbImportedComputerRoles)
	Sleep 1
	if ($Progress.IsPresent)
	{
		# Close progress bars
		Write-Progress -Activity "All Computer Roles done" -Status "Hidden" -Id 1 -Completed
		Write-Progress -Activity "Zones done" -Status "Hidden" -Id 2 -Completed
		Write-Progress -Activity "Computer Roles done" -Status "Hidden" -Id 3 -Completed
	}
	# Done.
}

###########################################################################################
# ADImport - Import-CentrifyComputerRoleMembers
#
# Specify the Computer Role and list of Members to add.
# This function is called by Import-CentrifyComputerRoles to add members each time a Computer Role is processed
#  
########
function Import-CentrifyComputerRoleMembers
{
	#######################################################################################
	param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "Computer Role where to add members.")]
		[Centrify.DirectControl.PowerShell.Types.CdmComputerRole]$ComputerRole,
		
		[Parameter(Position = 1, Mandatory = $true, HelpMessage = "List of members to add to the Computer Role.")]
		[System.String[]]$Members
	)
	#######################################################################################
	# Import Computer Role members
	[System.Int32]$intNbImportedGroupMembers = 0
	# Process Members List for the current Computer Role
	[System.Int32]$i = 1
	[System.Int32]$intNbMembers = $Members.Count
	foreach ($strMember in $Members)
	{
		if ($Progress.IsPresent)
		{
			# Show progress for overall Computer import
			$OverallProgressActivity	= ("Import Computer Role members [{0}/{1}]" -f $i, $intNbMembers)
			$OverallProgressStatus		= "Percent processed: "
			$OverallProgressComplete	= (($i++ / $intNbMembers)*100)
			Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 4 -ParentId 2
		}
		try
		{
			# Get Computer Profile from any Zone
			[Centrify.DirectControl.PowerShell.Types.CdmManagedComputer]$CdmManagedComputer = Get-CdmManagedComputer -Name $strMember
			# Get AD Computer from Computer Profile
			if ($CdmManagedComputer -ne [Void]$null)
			{
				# Get DN values for AD Computer and AD Group
				[System.String]$GroupADsPath = Get-ADsPath $ComputerRole.Group.distinguishedName
				[System.String]$ComputerDN = $CdmManagedComputer.Computer.distinguishedName
				# Add User to Group
				if (Add-ADGroupMember $GroupADsPath $ComputerDN)
				{
					$intNbImportedGroupMembers++
				}
			}
			else
			{
				Write-Warning ("No Computer Profile found for '{0}'. Membership addition skipped." -f $strMember)
			}
		}
		catch
		{
			# Unhandled Exception
			Throw $_.Exception
		}
	}

	# Print result
	Write-Host ("Computer Role members imported`t: {0}`n" -f $intNbImportedGroupMembers)
	Sleep 1
	if ($Progress.IsPresent)
	{
		# Close progress bars
		Write-Progress -Activity "Group's members done" -Status "Hidden" -Id 4 -Completed
	}
	# Done.
}

###########################################################################################
# ADImport - Import-CentrifyRoleAssignments
#
# Specify the CSV File to import Centrify Role Assignments into Zones/ComputerRoles/Computers.
# The CSV File format should be as below:
#
# TargetType,TargetName,Role,ADTrustee(,TrusteeType,LocalTrustee,StartTime,EndTime)
#
# TargetType    Indicate on which type of object create the Role Assignment. You may specify any of the following values for this parameter:
#                 - Zone
# 				  - ComputerRole
# 				  - Computer
# TargetName    The Zone/Computer/Computer Role for which to create the role assignment. You may specify any of the following values for this parameter:
#                 - Name
#				  - distinguishedName
#				  - samAccountName (for Computer only)
# Role          The role to assign to the zone, computer, or computer role. By default the Role is picked from the nearest Zone but target Zone can be specified using the format <Role Name>/<Zone Name>.
# ADTrustee     The Active Directory account to be used as the trustee. You can use this parameter only if the trustee is a specific AD user or group. In that case, do not use the "TrusteeType" parameter. You may specify any of the following values for this parameter:
#                 - distinguishedName
#                 - SID
#				  - samAccountName
#                 - <samAccountName>@<domain>
# TrusteeType   is the type of trustee. Do not use this parameter if the trustee is a specific Active Directory user or group.  If the trustee is local, you must use both this parameter and the LocalTrustee parameter. You must assign one of the following values:
#                  - LocalUnixUser   local UNIX user
#                  - LocalUnixUid    local UNIX UID
#                  - LocalUnixGroup  local UNIX group
#                  - LocalWinUser    local Windows user
#                  - LocalWinGroup   local Windows group
#                  - AllAD           all AD accounts
#                  - AllLocalUnix    all local UNIX accounts
#                  - AllLocalWin     all local Windows accounts
# LocalTrustee  The local account to use as the trustee. You can use this parameter only if the trustee is local, not Active Directory.
#               For a user or a group, specify the name; for example, "userName". For a UID, specify the UID number; for example, "12345".
# StartTime     The date and time when the role assignment becomes effective.
# EndTime       The date and time when the role assignment expires.
#  
########
function Import-CentrifyRoleAssignments
{
	#######################################################################################
	param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "CSV data file to process.")]
		[System.String]$Data
	)
	#######################################################################################
	Write-Output ("Starting Role Assignments import using {0} file..." -f $Data)
	# Import Unix Groups
	[System.Int32]$intNbImportedRoleAssignments = 0
	[System.Array]$arrRoleAssignmentList = Import-CSV $Data
	if ($arrRoleAssignmentList -eq [Void]$null)
	{
		Throw "Input file is in unattended format. Consider checking End Of Line characters that must be [CR][LF] on Windows system."
	}
	# Get list of Targets from Role Assignment List
	[System.Array]$arrTargetList = $arrRoleAssignmentList | Select-Object -Property TargetType , TargetName -Unique

	# Process Target List
	[System.Int32]$z = 1
	[System.Int32]$intNbTargets = $arrTargetList.Count
	[System.Int32]$all = 1
	[System.Int32]$intNbRoleAssignments = $arrRoleAssignmentList.Count
	# Show progress for overall Role Assignment import
	if ($Progress.IsPresent)
	{
		$OverallProgressActivity	= ("Import UNIX RoleAssignments [{0}/{1}]" -f $all, $intNbRoleAssignments)
		$OverallProgressStatus		= "Percent processed: "
		$OverallProgressComplete	= (($all / $intNbRoleAssignments)*100)
		Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
	}
	foreach ($objTarget in $arrTargetList)
	{
		# Get Target where to import Role Assignment
		if ($objTarget.TargetType -eq "Zone")
		{
			# Target is a Zone
			[System.String]$strZoneName = $objTarget.TargetName
			[Centrify.DirectControl.PowerShell.Types.CdmZone]$CdmZone = Get-CentrifyZone $strZoneName
			# Validate that the Zone exist
			if ($CdmZone -ne [Void]$null)
			{
				if ($Progress.IsPresent)
				{
					# Show progress for Target processing
					$ProgressActivity	= ("Centrify Zone '{0}' [{1}/{2}]" -f $CdmZone.Name, $z, $intNbTargets)
					$ProgressStatus		= "Percent processed: "
					$ProgressComplete	= (($z++ / $intNbTargets)*100)
					Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 2
				}
				# Process Role Assignment List for the current Zone
				[System.Array]$arrRoleAssignmentListInCurrentTarget = $arrRoleAssignmentList | Where-Object { ($_.TargetType -eq $objTarget.TargetType) -and ($_.TargetName -eq $objTarget.TargetName) }
				[System.Int32]$i = 1
				[System.Int32]$intNbRoleAssignmentsInCurrentTarget = $arrRoleAssignmentListInCurrentTarget.Count
				foreach ($objRoleAssignment in $arrRoleAssignmentListInCurrentTarget)
				{
					if ($Progress.IsPresent)
					{
						# Show progress for overall Computer import
						$OverallProgressActivity	= ("Import Role Assignments [{0}/{1}]" -f $all, $intNbRoleAssignments)
						$OverallProgressStatus		= "Percent processed: "
						$OverallProgressComplete	= (($all++ / $intNbRoleAssignments)*100)
						Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
						# Show progress for Computer import
						$ProgressActivity	= ("Role Assignment [{0}/{1}]" -f $i, $intNbRoleAssignmentsInCurrentTarget)
						$ProgressStatus		= "Percent processed: "
						$ProgressComplete	= (($i++ / $intNbRoleAssignmentsInCurrentTarget)*100)
						Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 3 -ParentId 2
					}
					try
					{
						# Format ADTrustee to {samAccountName}@{Domain} if needed
						if ($objRoleAssignment.ADTrustee -notmatch "^.*@.*$")
						{
							$objRoleAssignment.ADTrustee = ("{0}@{1}" -f $objRoleAssignment.ADTrustee, $Domain)
						}
						# Data to Import: Role,ADTrustee,TrusteeType,LocalTrustee,StartTime,EndTime
						$CdmRole = Get-CentrifyRole $CdmZone $objRoleAssignment.Role
						$CdmRoleAssignment = New-CdmRoleAssignment 	-Zone $CdmZone `
																	-Role $CdmRole `
																	-ADTrustee $objRoleAssignment.ADTrustee
						# Apply StartTime and EndTime if needed
						if (-not [System.String]::IsNullOrEmpty($objRoleAssignment.StartTime))
						{
							[Void]($CdmRoleAssignment | Set-CdmRoleAssignment -StartTime $objRoleAssignment.StartTime)
						}
						if (-not [System.String]::IsNullOrEmpty($objRoleAssignment.EndTime))
						{
							[Void]($CdmRoleAssignment | Set-CdmRoleAssignment -EndTime $objRoleAssignment.EndTime)
						}
						# Count Role Assignment created
						if ($CdmRoleAssignment -ne [Void]$null)
						{
							$intNbImportedRoleAssignments++
						}
					}
					catch [System.ApplicationException]
					{
						if ($_.Exception.Message -match "Role assignment already exists")
						{
							Write-Warning ("{0} in zone '{1}'." -f $_.Exception.Message, $CdmZone.Name)
						}
						else
						{
							# Unhandled Exception
							Throw $_.Exception
						}
					}
					catch
					{
						# Unhandled Exception
						Throw $_.Exception
					}
				}
			}
			else
			{
				# Zone not found
				Write-Error ("Can't find any Zone named {0} in Active Directory." -f $objZone.Zone)
			}
		}
		elseif ($objTarget.TargetType -eq "Computer")
		{
			# Target is a Computer
			[Centrify.DirectControl.PowerShell.Types.CdmManagedComputer]$CdmManagedComputer = Get-CdmManagedComputer -Name $objTarget.TargetName
			# Validate that the Managed Computer exist
			if ($CdmManagedComputer -ne [Void]$null)
			{
				if ($Progress.IsPresent)
				{
					# Show progress for Target processing
					$ProgressActivity	= ("Centrify Computer '{0}' [{1}/{2}]" -f $CdmManagedComputer.Name, $z, $intNbTargets)
					$ProgressStatus		= "Percent processed: "
					$ProgressComplete	= (($z++ / $intNbTargets)*100)
					Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 2
				}
				# Process Role Assignment List for the current Managed Computer
				[System.Array]$arrRoleAssignmentListInCurrentTarget = $arrRoleAssignmentList | Where-Object { ($_.TargetType -eq $objTarget.TargetType) -and ($_.TargetName -eq $objTarget.TargetName) }
				[System.Int32]$i = 1
				[System.Int32]$intNbRoleAssignmentsInCurrentTarget = $arrRoleAssignmentListInCurrentTarget.Count
				foreach ($objRoleAssignment in $arrRoleAssignmentListInCurrentTarget)
				{
					if ($Progress.IsPresent)
					{
						# Show progress for overall Computer import
						$OverallProgressActivity	= ("Import Role Assignments [{0}/{1}]" -f $all, $intNbRoleAssignments)
						$OverallProgressStatus		= "Percent processed: "
						$OverallProgressComplete	= (($all++ / $intNbRoleAssignments)*100)
						Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
						# Show progress for Computer import
						$ProgressActivity	= ("Role Assignment [{0}/{1}]" -f $i, $intNbRoleAssignmentsInCurrentTarget)
						$ProgressStatus		= "Percent processed: "
						$ProgressComplete	= (($i++ / $intNbRoleAssignmentsInCurrentTarget)*100)
						Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 3 -ParentId 2
					}
					try
					{
						# Format ADTrustee to {samAccountName}@{Domain} if needed
						if ($objRoleAssignment.ADTrustee -notmatch "^.*@.*$")
						{
							$objRoleAssignment.ADTrustee = ("{0}@{1}" -f $objRoleAssignment.ADTrustee, $Domain)
						}
						# Data to Import: Role,ADTrustee,TrusteeType,LocalTrustee,StartTime,EndTime
						$CdmRole = Get-CentrifyRole $CdmZone $objRoleAssignment.Role
						$CdmRoleAssignment = New-CdmRoleAssignment	-Computer $CdmManagedComputer `
																	-Role $CdmRole `
																	-ADTrustee $objRoleAssignment.ADTrustee
						# Apply StartTime and EndTime if needed
						if (-not [System.String]::IsNullOrEmpty($objRoleAssignment.StartTime))
						{
							[Void]($CdmRoleAssignment | Set-CdmRoleAssignment -StartTime $objRoleAssignment.StartTime)
						}
						if (-not [System.String]::IsNullOrEmpty($objRoleAssignment.EndTime))
						{
							[Void]($CdmRoleAssignment | Set-CdmRoleAssignment -EndTime $objRoleAssignment.EndTime)
						}
						# Count Role Assignment created
						if ($CdmRoleAssignment -ne [Void]$null)
						{
							$intNbImportedRoleAssignments++
						}
					}
					catch [System.ApplicationException]
					{
						if ($_.Exception.Message -match "Role assignment already exists")
						{
							Write-Warning ("{0} in Computer '{1}'." -f $_.Exception.Message, $CdmManagedComputer.Name)
						}
						else
						{
							# Unhandled Exception
							Throw $_.Exception
						}
					}
					catch
					{
						# Unhandled Exception
						Throw $_.Exception
					}
				}
			}
			else
			{
				# Zone not found
				Write-Error ("Can't find any Computer named {0} in Active Directory." -f $objTarget.TargetName)
			}
		}
		elseif ($objTarget.TargetType -eq "ComputerRole")
		{
			# Target is a Computer Role
			[System.String]$strComputerRoleName = $objTarget.TargetName.Split("@")[0]
			[System.String]$strZoneName = $objTarget.TargetName.Split("@")[1]
			# Get Computer Role's Zone
			[Centrify.DirectControl.PowerShell.Types.CdmZone]$CdmZone = Get-CentrifyZone $strZoneName
			# Get Computer Role
			[Centrify.DirectControl.PowerShell.Types.CdmComputerRole]$CdmComputerRole = Get-CdmComputerRole -Zone $CdmZone -Name $strComputerRoleName
			# Validate that the Computer Role exist
			if ($CdmComputerRole -ne [Void]$null)
			{
				if ($Progress.IsPresent)
				{
					# Show progress for Target processing
					$ProgressActivity	= ("Computer Role '{0}' [{1}/{2}]" -f $CdmZone.Name, $z, $intNbTargets)
					$ProgressStatus		= "Percent processed: "
					$ProgressComplete	= (($z++ / $intNbTargets)*100)
					Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 2
				}
				# Process Role Assignment List for the current Zone
				[System.Array]$arrRoleAssignmentListInCurrentTarget = $arrRoleAssignmentList | Where-Object { ($_.TargetType -eq $objTarget.TargetType) -and ($_.TargetName -eq $objTarget.TargetName) }
				[System.Int32]$i = 1
				[System.Int32]$intNbRoleAssignmentsInCurrentTarget = $arrRoleAssignmentListInCurrentTarget.Count
				foreach ($objRoleAssignment in $arrRoleAssignmentListInCurrentTarget)
				{
					if ($Progress.IsPresent)
					{
						# Show progress for overall Computer import
						$OverallProgressActivity	= ("Import Role Assignments [{0}/{1}]" -f $all, $intNbRoleAssignments)
						$OverallProgressStatus		= "Percent processed: "
						$OverallProgressComplete	= (($all++ / $intNbRoleAssignments)*100)
						Write-Progress -Activity $OverallProgressActivity -Status $OverallProgressStatus -PercentComplete $OverallProgressComplete -Id 1
						# Show progress for Computer import
						$ProgressActivity	= ("Role Assignment [{0}/{1}]" -f $i, $intNbRoleAssignmentsInCurrentTarget)
						$ProgressStatus		= "Percent processed: "
						$ProgressComplete	= (($i++ / $intNbRoleAssignmentsInCurrentTarget)*100)
						Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 3 -ParentId 2
					}
					try
					{
						# Format ADTrustee to {samAccountName}@{Domain} if needed
						if ($objRoleAssignment.ADTrustee -notmatch "^.*@.*$")
						{
							$objRoleAssignment.ADTrustee = ("{0}@{1}" -f $objRoleAssignment.ADTrustee, $Domain)
						}
						# Data to Import: Role,ADTrustee,TrusteeType,LocalTrustee,StartTime,EndTime
						$CdmRole = Get-CentrifyRole $CdmZone $objRoleAssignment.Role
						$CdmRoleAssignment = New-CdmRoleAssignment 	-ComputerRole $CdmComputerRole `
																	-Role $CdmRole `
																	-ADTrustee $objRoleAssignment.ADTrustee
						# Apply StartTime and EndTime if needed
						if (-not [System.String]::IsNullOrEmpty($objRoleAssignment.StartTime))
						{
							[Void]($CdmRoleAssignment | Set-CdmRoleAssignment -StartTime $objRoleAssignment.StartTime)
						}
						if (-not [System.String]::IsNullOrEmpty($objRoleAssignment.EndTime))
						{
							[Void]($CdmRoleAssignment | Set-CdmRoleAssignment -EndTime $objRoleAssignment.EndTime)
						}
						# Count Role Assignment created
						if ($CdmRoleAssignment -ne [Void]$null)
						{
							$intNbImportedRoleAssignments++
						}
					}
					catch [System.ApplicationException]
					{
						if ($_.Exception.Message -match "Role assignment already exists")
						{
							Write-Warning ("{0} in Computer Role '{1}'." -f $_.Exception.Message, $strComputerRoleName)
						}
						else
						{
							# Unhandled Exception
							Throw $_.Exception
						}
					}
					catch
					{
						# Unhandled Exception
						Throw $_.Exception
					}
				}
			}
			else
			{
				# Zone not found
				Write-Error ("Can't find any Computer Role named {0} in Active Directory." -f $strComputerRoleName)
			}
		}
		else
		{
			# Invalid target type
			Write-Error ("Invalid target type '{0}' for Role Assignment. Targets must be 'Zone', 'ComputerRole' or 'Computer'." -f $objTarget.TargetType)
		}
	}			

	# Print result
	Write-Host ("Role Assignments imported`t: {0}`nDone.`n" -f $intNbImportedRoleAssignments)
	Sleep 1
	if ($Progress.IsPresent)
	{
		# Close progress bars
		Write-Progress -Activity "All Role Assignments done" -Status "Hidden" -Id 1 -Completed
		Write-Progress -Activity "Targets done" -Status "Hidden" -Id 2 -Completed
		Write-Progress -Activity "Role Assignments done" -Status "Hidden" -Id 3 -Completed
	}
	# Done.
}

################################
#endregion
################################

##########################################
#region ### CENTRIFY POWERSHELL MODULE ###
##########################################

# Add PowerShell Module to session if not already loaded
[System.String]$ModuleName = "Centrify.DirectControl.PowerShell"
# Load PowerShell Module if not already loaded
if (@(Get-Module | Where-Object {$_.Name -eq $ModuleName}).count -eq 0)
{
	Write-Host ("Loading {0} module..." -f $ModuleName)
	Import-Module $ModuleName
	if (@(Get-Module | Where-Object {$_.Name -eq $ModuleName}).count -ne 0)
	{
		Write-Host ("{0} module loaded." -f $ModuleName)
	}
	else
	{
		Throw "Unable to load PowerShell module."
	}
}
##########################################
#endregion
##########################################

##########################
#region ### MAIN LOGIC ###
##########################

# Print banner
if ($Banner.IsPresent)
{
	Clear-Host
	Write-Host "### ADImport - Import Centrify Data into Active Directory ###`n"
}

# Initiate AD Connection and keep track of runtime
[System.String]$strTarget
[System.DateTime]$StartingTime = [System.DateTime]::Now
# Set preferred Domain Controller
if (-not [System.String]::IsNullOrEmpty($Server))
{
	Set-CdmPreferredServer -Domain $Domain -Server $Server
}
# Set PSCredential for Domain connection
if ($Credential -ne [Void]$null)
{
	Set-CdmCredential -Domain $Domain -Credential $Credential
}

#########################
# Check import mode
#########################

foreach ($Parameter in $PSBoundParameters.GetEnumerator())
{
	# Centrify Zones import
	if ($Parameter.Key -eq "Zones")
	{
		if (Test-Path -Path $Zones)
		{
			Import-CentrifyZones $Zones
		}
		else
		{
			Throw "Can't find specified file to import."
		}
	}
	
	# Centrify Computers import and preparation
	elseif ($Parameter.Key -eq "Computers")
	{
		if (Test-Path -Path $Computers)
		{
			Import-CentrifyComputers $Computers
		}
		else
		{
			Throw "Can't find specified file to import."
		}
	}
	
	# Centrify Unix User profiles import
	elseif ($Parameter.Key -eq "Users")
	{
		if (Test-Path -Path $Users)
		{
			Import-CentrifyUsers $Users
		}
		else
		{
			Throw "Can't find specified file to import."
		}
	}
	
	# Centrify Unix Group profiles import
	elseif ($Parameter.Key -eq "Groups")
	{
		if (Test-Path -Path $Groups)
		{
			Import-CentrifyGroups $Groups
		}
		else
		{
			Throw "Can't find specified file to import."
		}
	}
	
	# Centrify Roles import
	elseif ($Parameter.Key -eq "Roles")
	{
		if (Test-Path -Path $Roles)
		{
			Import-CentrifyRoles $Roles
		}
		else
		{
			Throw "Can't find specified file to import."
		}
	}
	
	# Centrify Unix Rights import
	elseif ($Parameter.Key -eq "UnixRights")
	{
		if (Test-Path -Path $UnixRights)
		{
			Import-CentrifyUnixRights $UnixRights
		}
		else
		{
			Throw "Can't find specified file to import."
		}
	}
	
	# Centrify Windows Rights import
	elseif ($Parameter.Key -eq "WindowsRights")
	{
		if (Test-Path -Path $WindowsRights)
		{
			Import-CentrifyWindowsRights $WindowsRights
		}
		else
		{
			Throw "Can't find specified file to import."
		}
	}
	
	# Centrify Computer Roles import
	elseif ($Parameter.Key -eq "ComputerRoles")
	{
		if (Test-Path -Path $ComputerRoles)
		{
			Import-CentrifyComputerRoles $ComputerRoles
		}
		else
		{
			Throw "Can't find specified file to import."
		}
	}
	
	# Centrify Role Assignments import
	elseif ($Parameter.Key -eq "RoleAssignments")
	{
		if (Test-Path -Path $RoleAssignments)
		{
			Import-CentrifyRoleAssignments $RoleAssignments
		}
		else
		{
			Throw "Can't find specified file to import."
		}
	}

	# ADImport need argument
	else
	{
		Write-Error "Missing type of data to import.`n"
		# Print Help
		Get-Help .\ADImport.ps1
		Exit
		# Done.
	}
}

# Print Elapsed time
[System.TimeSpan]$ElapsedTime = [DateTime]::Now - $StartingTime
Write-Host ("Runtime: {0:D2}h{1:D2}m{2:D2}s.`n" -f $ElapsedTime.Hours, $ElapsedTime.Minutes, $ElapsedTime.Seconds)
# All Done.

##########################
#endregion
##########################
# SIG # Begin signature block
# MIIEKgYJKoZIhvcNAQcCoIIEGzCCBBcCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUEtTNjT5qr0Qujm1mlHNuAovX
# nDKgggI3MIICMzCCAaCgAwIBAgIQxH+aGsBVZbxNZjfCW1OLZDAJBgUrDgMCHQUA
# MCkxJzAlBgNVBAMTHkNlbnRyaWZ5IFByb2Zlc3Npb25hbCBTZXJ2aWNlczAeFw0x
# NDA2MTEwODAwMTlaFw0zOTEyMzEyMzU5NTlaMBoxGDAWBgNVBAMTD0ZhYnJpY2Ug
# VmlndWllcjCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAxfURIpF7SU3RmrXd
# /Vww7ud2J0kZL+Sc//kJqxDmjxngCsBjpOqIKLgxsi5DxjZio0gk/aav6Ifk7ej4
# Mtp2IYY1L5EiAitYlRfFCGapnAolrbQ9r1fInmhpAJXiwxD+pedVA3pjQue1xhB7
# dvKZxfwxZqdNHVLPQr8vgCZzscsCAwEAAaNzMHEwEwYDVR0lBAwwCgYIKwYBBQUH
# AwMwWgYDVR0BBFMwUYAQj6wqZRzzWAIFIMGJqC9WlqErMCkxJzAlBgNVBAMTHkNl
# bnRyaWZ5IFByb2Zlc3Npb25hbCBTZXJ2aWNlc4IQ3lgycgf2r6dK3jpN2H3n5DAJ
# BgUrDgMCHQUAA4GBAGl0+syZ3Q+39hBNUyzigpjbswckp3gZc6PVO53a+bd+PFEG
# gi/96JeLpq3PDWZq1n12Kp9ZHsxiuzb0mWdbumw2p5laQWMlO40JQUJOoP64DPLL
# Ou7szPH6o89dHGJ2UDWYlU02Iiysa4hCv9sJaLesnetxlcY4Cdfdlo41LhvfMYIB
# XTCCAVkCAQEwPTApMScwJQYDVQQDEx5DZW50cmlmeSBQcm9mZXNzaW9uYWwgU2Vy
# dmljZXMCEMR/mhrAVWW8TWY3wltTi2QwCQYFKw4DAhoFAKB4MBgGCisGAQQBgjcC
# AQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYB
# BAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFKAd4mH0ShSb
# JN2jZBxTlCE7yTRzMA0GCSqGSIb3DQEBAQUABIGAur65aOf0BJYrTAKfKN6NRteV
# w13jvgA+vI1n/b8/gpbcQLHRrmeTTYcSfCyiZJWeMKEJAM8dax4TGrUNx87fEWWG
# tfDrZL09ar71w5rRii3qSSCx4ew/n233Gtkm2mN3b1VEEJl9AKSrVfm28Wgsmjkp
# LK0ztHyhJR8jbYJeprc=
# SIG # End signature block
