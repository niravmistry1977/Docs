###########################################################################################
# CREATE CSV DATA FILE from a passwd file and a User mapping File
#
# Author : Fabrice Viguier
# Contact: fabrice.viguier AT centrify.com
# Release: 03/08/2012
# Version: 1.0.924   First release, Generate UNIXData files for using with ADImport
###########################################################################################

Param
(
	[Parameter(Position = 0, Mandatory = $true, HelpMessage = "Specify the Passwd file to use as input data to generate the CSV file.")]
	[Alias("p")]
	[System.String]$PasswdFile,
	
	[Parameter(Position = 1, Mandatory = $true, HelpMessage = "Specify the User Mapping file to use to match UnixName to SamAccountName.")]
	[Alias("m")]
	[System.String]$MappingFile,

	[Parameter(Position = 2, Mandatory = $false, HelpMessage = "Specify the name of the output file (by default UserProfiles.csv).")]
	[Alias("f")]
	[System.String]$File = "UserProfiles.csv",

	[Parameter(Mandatory = $false, HelpMessage = "Specify the Target name for the profiles (by default the `"Global`" Zone).")]
	[Alias("t")]
	[System.String]$Target = "Global"
)

# If mapping file is present, build the mapping data
[System.Collections.Hashtable]$MappingTable = @{}
if (-not [System.String]::IsNullOrEmpty($MappingFile))
{
	if (Test-Path -Path $MappingFile)
	{
		$Data = Import-Csv $MappingFile
		if ($Data -ne [Void]$null)
		{
			foreach ($Entry in $Data)
			{
				if (-not $MappingTable.ContainsKey($Entry.UnixName))
				{
					# Add entry to Hashtable
					$MappingTable.Add($Entry.UnixName, $Entry.SamAccountName)
				}
				else
				{
					# Oops UnixName should be unique
					Throw ("Duplicate UnixName '{0}' found in Mapping file." -f $Entry.UnixName)
				}
			}
		}
		else
		{
			Throw "Mapping file data invalid or file empty."
		}
	}
	else
	{
		Throw ("Can't open file {0}" -f $MappingFile)
	}
}
# Read passwd file
[System.Array]$UnixProfiles = @()
if (Test-Path -Path $PasswdFile)
{
	$Data = Import-Csv $PasswdFile -Delimiter : -Header UnixName, Hash, UID, GID, Gecos, Home, Shell
	if ($Data -ne [Void]$null)
	{
		foreach ($Entry in $Data)
		{
			if ($MappingTable.ContainsKey($Entry.UnixName))
			{
				# User is in the mapping file
				Write-Host ("Username '{0}' found in the mapping file. User added." -f $Entry.UnixName)
				# Build UserProfile
				$UserProfile = New-Object System.Object
				$UserProfile | Add-Member -MemberType NoteProperty -Name	"Zone"		-Value $Target
				$UserProfile | Add-Member -MemberType NoteProperty -Name	"User"		-Value $MappingTable.Get_Item($Entry.UnixName);
				$UserProfile | Add-Member -MemberType NoteProperty -Name	"UnixName"	-Value $Entry.UnixName;
				$UserProfile | Add-Member -MemberType NoteProperty -Name	"UID"		-Value $Entry.UID;
				$UserProfile | Add-Member -MemberType NoteProperty -Name	"GID"		-Value $Entry.GID;
				$UserProfile | Add-Member -MemberType NoteProperty -Name	"Gecos"		-Value $Entry.Gecos;
				$UserProfile | Add-Member -MemberType NoteProperty -Name	"Home"		-Value $Entry.Home;
				$UserProfile | Add-Member -MemberType NoteProperty -Name	"Shell"		-Value $Entry.Shell;
				# Add Profile to list
				$UnixProfiles += $UserProfile
			}
			else
			{
				# User is NOT in the mapping file
				Write-Warning ("Username '{0}' not found in the mapping file. User ignored." -f $Entry.UnixName)
			}
		}
	}
	else
	{
		Throw "Mapping file data invalid or file empty."
	}
}
else
{
	Throw ("Can't open file {0}" -f $PasswdFile)
}
# Dump CSV file
$UnixProfiles | Export-Csv -NoTypeInformation $File