###########################################################################################
# RUN USER ANALYSIS
# Analyse UnixName and UID collisions and generate User Data files to be imported into AD
#
# Author : Fabrice Viguier
# Contact: fabrice.viguier AT centrify.com
# Release: 03/08/2012
# Version: 1.1.0.0803   First release, Generate UNIXData files for using with ADImport
#          1.1.1.0806   Script optimized to process User data files
#          1.3.1.1001   Fix bug in analysis mechanism and UID collision detection
#          2.0.0.0312   Improv log ouput, fix bugs, add to the new set of tools
#          3.7.1206     Fix tools scripts to match new CSV file format and data structure.
#          4.5.930      Complete re-writing of the Analysis logic to embrace PS "best practices" philosophy
#          4.6.326      Improvement of the User Analysis tools
###########################################################################################

#######################################################################################
# PARAMETERS                                                                          #
#######################################################################################
Param
(
	[Parameter(Mandatory = $false, HelpMessage = "Use the matching file located under ./data folder. Matching file associate UnixName to SamAccountName.")]
	[Switch]$UseMatchingFile,
	
	[Parameter(Mandatory = $false, HelpMessage = "Use the ignore file located under ./data folder. Ignore file list the UnixName to skip during analysis.")]
	[Switch]$UseIgnoreFile,

	[Parameter(Mandatory = $false, HelpMessage = "Do not skip System UID (i.e. 0-100), by default these UID are ignored either you use or not the Ignore File.")]
	[Switch]$IncludeSystemUID,
	
	[Parameter(Mandatory = $false, HelpMessage = "Choose Target for Master Profiles (by default `"Global`" Zone).")]
	[System.String]$Target = "Global"
)

#######################################################################################
# FUNCTIONS                                                                           #
#######################################################################################
function Dump-Log
{
	Param
	(
		[Parameter(Mandatory = $true)]
		[System.String]$Name,
		
		[Parameter(Mandatory = $true)]
		[System.String]$LogFile,
	
		[Parameter(Mandatory = $true)]
		[System.Collections.Hashtable]$Table		
	)
	################################
	[System.Int64]$nbCollisions = 0
	[System.String]$log = ("### {0} analysis log ###`nLast run: {1}" -f $Name, [System.DateTime]::Now)
	foreach ($Entry in $Table.GetEnumerator() | Sort-Object -Property Name)
	{
		# Add entry to log
		$log += ("`n`n{0}" -f $Entry.Key)
		if ($Entry.Value.Collision)
		{
			$log += " [COLLISIONS]"
			$nbCollisions++
		}
		foreach ($Value in $Entry.Value.Profiles)
		{
			$log += ("`n{0}@{1}, {2}" -f $Value.User, $Value.Hostname, $Value.Profile)

		}
	}
	$log | Set-Content $LogFile
	return $nbCollisions
}

#######################################################################################
# MAIN LOGIC                                                                          #
#######################################################################################
[System.DateTime]$StartingTime = [System.DateTime]::Now
#####
# GET USER DATA
# Get Passwd files from ./import folder
#####

$Path = "..\import"
if (Test-Path -Path $Path)
{
	$DataFileList = Get-ChildItem -Path $Path -Filter "*_Users.txt"
	if ($DataFileList -ne [Void]$null)
	{
		Write-Host ("`nStarting analysis of {0} passwd files..." -f $DataFileList.Count)
		# Declare Hashtables
		[System.Collections.Hashtable]$UsersByName	= @{}
		[System.Collections.Hashtable]$UsersByUID	= @{}
		[System.Collections.Hashtable]$UsersByGID	= @{}
		[System.Collections.Hashtable]$UserProfiles	= @{}
		[System.Collections.Hashtable]$UserMatching	= @{}
		[System.Collections.Hashtable]$UserNotFound	= @{}
		[System.Collections.Hashtable]$UserIgnore	= @{}
		# Load UserMatching data in Hashtable
		if ($UseMatchingFile.IsPresent)
		{
			[System.String]$File = "../data/UserMatching.csv"
			if (Test-Path -Path $File)
			{
				$MatchingData = Import-Csv $File
				if ($MatchingData -ne [Void]$null)
				{
					$DuplicateEntries = $False
					foreach ($Entry in $MatchingData)
					{
						[System.String]$UserName = ("{0}@{1}" -f $Entry.UnixName, $Entry.ComputerName)
						if (-not $UserMatching.ContainsKey($UserName))
						{
							$UserMatching.Add($UserName, $Entry.SamAccountName)
						}
						else
						{
							Write-Warning ("Duplicated User entry '{0}' found." -f $Entry)
							$DuplicateEntries = $True
						}
					}
					if ($DuplicateEntries)
					{
						Throw "Multiple entries detected in UserMatching.csv file."
					}
				}
				else
				{
					Throw "UserMatching.csv is empty or incorrectly formated."
				}
			}
			else
			{
				Throw "UserMatching.csv file is missing from ./data folder. Create the file or try to run this script without -UseMatchingFile argument."
			}
		}
		# Load UserIgnore data in Hashtable
		if ($UseIgnoreFile.IsPresent)
		{
			[System.String]$File = "../data/user.ignore"
			if (Test-Path -Path $File)
			{
				$IgnoreData = Import-Csv $File -Header "UnixName"
				if ($IgnoreData -ne [Void]$null)
				{
					foreach ($Entry in $IgnoreData)
					{
						if (-not $UserMatching.ContainsKey($Entry.UnixName))
						{
							$UserIgnore.Add($Entry.UnixName, $Entry.UnixName) 
						}
						else
						{
							Throw "Multiple entries detected in user.ignore file."
						}
					}
				}
				else
				{
					Throw "user.ignore is empty or incorrectly formated."
				}
			}
			else
			{
				Throw "user.ignore file is missing from ./data folder. Create the file or try to run this script without -UseIgnoreFile argument."
			}
		}
		# Distribute data in Hashtables
		foreach ($DataFile in $DataFileList)
		{
			# Get DataFile content
			$Data = Import-Csv $DataFile.FullName -Delimiter : -Header UnixName, Hash, UID, GID, Gecos, Home, Shell
			if ($Data -eq [Void]$null)
			{
				Throw ("Unable to load data from file {0}. Verify file format before to run this script again." -f $DataFile)
			}
			# Data extraction
			[System.String]$Hostname = $DataFile.ToString().Split('_')[0].Split('.')[0]
			foreach ($Entry in $Data)
			{
				# Check if user should be ignore
				if (([System.Int64]$Entry.UID -le 100 -and -not $IncludeSystemUID.IsPresent) `
					-or `
					($UseIgnoreFile.IsPresent -and $UserIgnore.ContainsKey($Entry.UnixName)))
				{
					# Ignore User entry
					Write-Verbose ("User '{0}' is in user.ignore file or use a System UID (0-100). User skipped.")
				}
				else
				{
					# Check if user should be matched with an AD User
					if ($UseMatchingFile.IsPresent)
					{
						$UserNameGeneric = ("{0}@*" -f $Entry.UnixName)
						$UserNameByHost = ("{0}@{1}" -f $Entry.UnixName, $Hostname)
						if ($UserMatching.ContainsKey($UserNameGeneric))
						{
							# Get SamAccountName from Matching file where UserName is Generic (use of * in mapping file)
							$SamAccountName = $UserMatching.Get_Item($UserNameGeneric)
						}
						elseif ($UserMatching.ContainsKey($UserNameByHost))
						{
							# Get SamAccountName from Matching file where UserName is specific to an Hostname
							$SamAccountName = $UserMatching.Get_Item($UserNameByHost)
						}
						else
						{
							# Can't find matching from file, User is ignored and added to UserNotFound hashtable
							$RawProfile = ("{0}:x:{1}:{2}:{3}:{4}:{5}" -f $Entry.UnixName, $Entry.UID, $Entry.GID, $Entry.Gecos, $Entry.Home, $Entry.Shell)
							$UserNotFound.Add($UserNameByHost, $RawProfile)
							$SamAccountName = $false
						}
					}
					else
					{
						# Get SamAccountName from UnixName (hoping they are matching)
						$SamAccountName = $Entry.UnixName
					}
					# Ignore user if SamAccountName has no value
					if ($SamAccountName)
					{
						# Build the Unix Profile
						$RawProfile = ("{0}:x:{1}:{2}:{3}:{4}:{5}" -f $Entry.UnixName, $Entry.UID, $Entry.GID, $Entry.Gecos, $Entry.Home, $Entry.Shell)
						$UnixProfile =  @{
							"Hostname"	= $Hostname;
							"User"		= $SamAccountName;
							"Profile"	= $RawProfile;
						}
						# Sort by UnixName
						if (-not $UsersByName.ContainsKey($Entry.UnixName))
						{
							# Add new Entry to list
							$UsersByName[$Entry.UnixName] = @{
								"Profiles"	= @($UnixProfile);
								"User"		= $SamAccountName;
								"Collision"	= $false;
							}
						}
						else
						{						
							# Update Entry by adding another profile
							$UsersByName[$Entry.UnixName].Profiles 	+= $UnixProfile
							# Detect collisions
							if ($UsersByName[$Entry.UnixName].User -ne $SamAccountName)
							{
								$UsersByName[$Entry.UnixName].Collision = $true
							}
						}
						# Sort by UID
						if (-not $UsersByUID.ContainsKey($Entry.UID))
						{
							# Add new Entry to list
							$UsersByUID[$Entry.UID] = @{
								"Profiles"	= @($UnixProfile);
								"User"		= $SamAccountName;
								"Collision"	= $false;
							}
						}
						else
						{						
							# Update Entry by adding another profile
							$UsersByUID[$Entry.UID].Profiles 	+= $UnixProfile
							# Detect collisions
							if ($UsersByUID[$Entry.UID].User -ne $Entry.UnixName)
							{
								$UsersByUID[$Entry.UID].Collision = $true
							}
						}
						# Sort by GID
						if (-not $UsersByGID.ContainsKey($Entry.GID))
						{
							# Add new Entry to list
							$UsersByGID[$Entry.GID] = @{
								"Profiles"	= @($UnixProfile);
								"User"		= $SamAccountName;
								"Collision"	= $false;
							}
							# No collisions detection over GID
						}
						else
						{						
							# Update Entry by adding another profile
							$UsersByGID[$Entry.GID].Profiles 	+= $UnixProfile
						}
						# Feed Master Profiles hashtable
						if (-not $UserProfiles.ContainsKey($SamAccountName))
						{
							# Add new Entry to list
							[System.Collections.Hashtable]$ProfileByHostName = @{}
							$ProfileByHostName.Add($UnixProfile.Hostname, $UnixProfile.Profile)
							$UserProfiles.Add($SamAccountName, $ProfileByHostName)
						}
						else
						{
							# Update Entry by adding another profile
							try
							{
								$UserProfiles[$SamAccountName].Add($UnixProfile.Hostname, $UnixProfile.Profile)
							}
							catch [System.Management.Automation.MethodInvocationException]
							{
								if ($_.Exception.Message -match "Item has already been added. .*")
								{
									Write-Warning ("Duplicate Entry for {0} in {1}:" -f $SamAccountName, $UnixProfile.Hostname)
									Write-Warning ("`t> {0}" -f $UserProfiles[$SamAccountName].Get_Item($UnixProfile.Hostname))
									Write-Warning ("`t> {0}" -f $UnixProfile.Profile)
								}
							}
							catch
							{
								Throw $_.Exception
							}
						}
					}
				}
			}
		}
		# Calculate MasterProfiles
		Write-Host "Calculating Master profiles and Overrides..."
		[System.String]$log = ("### Users analysis log ###`nLast run: {1}`n" -f $Name, [System.DateTime]::Now)
		[System.Array]$MasterProfilesData = @()
		[System.Array]$OverridesData = @()
		foreach ($Entry in $UserProfiles.GetEnumerator() | Sort-Object -Property Name)
		{
			# Enumerate list of Profiles for this User
			[System.Array]$ListOfProfiles = @()
			foreach($Object in $Entry.Value.GetEnumerator())
			{
				$ListOfProfiles += $Object.Value
			}
			$UniqueProfiles = ($ListOfProfiles | Group-Object | Sort-Object -Property Count -Descending).Values
			# Get Master profile (most found value)
			$MasterProfile = $UniqueProfiles[0]
			# Split the Master profile and check for Collisions
			$Values = $MasterProfile.Split(":")
			if ($UsersByName[$Values[0]].Collision -or $UsersByUID[$Values[2]].Collision)
			{
				# Collisions detected
				$log += ("`n[-] Remove master profile because of collision: {0} from {1} {2}:x:{3}:{4}:{5}:{6}:{7}" -f $Entry.Key, $Target, $Values[0], $Values[2], $Values[3], $Values[4], $Values[5], $Values[6])
				# Find all Hostnames using this Master Profile				
				[System.Array]$ListOfComputers = @()
				$ListOfComputers = $Entry.Value.GetEnumerator() | Where-Object { $_.Value -eq $MasterProfile }
				foreach ($Computer in $ListOfComputers)
				{
					# Add non-Master profiles found for each Computer
					$Object = New-Object System.Object
					$Object | Add-Member -MemberType NoteProperty -Name	"Zone"		-Value $Computer.Name
					$Object | Add-Member -MemberType NoteProperty -Name	"User"		-Value $Entry.Key;
					$Object | Add-Member -MemberType NoteProperty -Name	"UnixName"	-Value $Values[0];
					$Object | Add-Member -MemberType NoteProperty -Name	"UID"		-Value $Values[2];
					$Object | Add-Member -MemberType NoteProperty -Name	"GID"		-Value $Values[3];
					$Object | Add-Member -MemberType NoteProperty -Name	"Gecos"		-Value $Values[4];
					$Object | Add-Member -MemberType NoteProperty -Name	"Home"		-Value $Values[5];
					$Object | Add-Member -MemberType NoteProperty -Name	"Shell"		-Value $Values[6];
					$OverridesData += $Object
					$log += ("`n[+] Add non-master profile to Overrides: {0} to {1} {2}:x:{3}:{4}:{5}:{6}:{7}" -f $Object.User, $Object.Zone, $Object.UnixName, $Object.UID, $Object.GID, $Object.Gecos, $Object.Home, $Object.Shell)
				}
			}
			else
			{
				# No collisions, we've got a genuine master profile!
				$Object = New-Object System.Object
				$Object | Add-Member -MemberType NoteProperty -Name	"Zone"		-Value $Target
				$Object | Add-Member -MemberType NoteProperty -Name	"User"		-Value $Entry.Key;
				$Object | Add-Member -MemberType NoteProperty -Name	"UnixName"	-Value $Values[0];
				$Object | Add-Member -MemberType NoteProperty -Name	"UID"		-Value $Values[2];
				$Object | Add-Member -MemberType NoteProperty -Name	"GID"		-Value $Values[3];
				$Object | Add-Member -MemberType NoteProperty -Name	"Gecos"		-Value $Values[4];
				$Object | Add-Member -MemberType NoteProperty -Name	"Home"		-Value $Values[5];
				$Object | Add-Member -MemberType NoteProperty -Name	"Shell"		-Value $Values[6];
				$MasterProfilesData += $Object
				$log += ("`n[+] Add master profile to MasterProfiles: {0} to {1} {2}:x:{3}:{4}:{5}:{6}:{7}" -f $Object.User, $Object.Zone, $Object.UnixName, $Object.UID, $Object.GID, $Object.Gecos, $Object.Home, $Object.Shell)
			}
			# Add all non-Master Profiles to Overrides data
			foreach ($OtherProfile in $UniqueProfiles[1..($UniqueProfiles.Count - 1)])
			{
				# Find all Hostnames using this Other Profile and not the Master Profile (in case the Master Profile is the unique Profile used)			
				[System.Array]$ListOfComputers = @()
				$ListOfComputers = $Entry.Value.GetEnumerator() | Where-Object { $_.Value -eq $OtherProfile -and $_.Value -ne $MasterProfile }
				foreach ($Computer in $ListOfComputers)
				{
					# Build profiles
					$Values = $OtherProfile.Split(":")
					$Object = New-Object System.Object
					$Object | Add-Member -MemberType NoteProperty -Name	"Zone"		-Value $Computer.Name
					$Object | Add-Member -MemberType NoteProperty -Name	"User"		-Value $Entry.Key;
					$Object | Add-Member -MemberType NoteProperty -Name	"UnixName"	-Value $Values[0];
					$Object | Add-Member -MemberType NoteProperty -Name	"UID"		-Value $Values[2];
					$Object | Add-Member -MemberType NoteProperty -Name	"GID"		-Value $Values[3];
					$Object | Add-Member -MemberType NoteProperty -Name	"Gecos"		-Value $Values[4];
					$Object | Add-Member -MemberType NoteProperty -Name	"Home"		-Value $Values[5];
					$Object | Add-Member -MemberType NoteProperty -Name	"Shell"		-Value $Values[6];
					# The Object for a Master Profile is identical except for the Target
					$OverridesData += $Object
					$log += ("`n[+] Add non-master profile to Overrides: {0} to {1} {2}:x:{3}:{4}:{5}:{6}:{7}" -f $Object.User, $Object.Zone, $Object.UnixName, $Object.UID, $Object.GID, $Object.Gecos, $Object.Home, $Object.Shell)
				}
			}
		}
		Write-Host "Writting User Data files.`n"
		$log | Set-Content "../analysis/UserProfiles.log"
		# Dump data
		$MasterProfilesData | Sort-Object -Property UnixName | Export-Csv -NoTypeInformation -Path "../data/UserMasterProfiles.csv"
		$OverridesData | Sort-Object -Property Zone, UnixName | Export-Csv -NoTypeInformation -Path "../data/UserProfilesOverrides.csv"
		# Done.
		Write-Host "Done.`n"
		# Dump analysis logs
		[System.Int64]$nbCollisions = 0
		Write-Host "Dumping log files..."

		if ($UseMatchingFile.IsPresent)
		{
			# Export list of Users not found
			$UsersNotFound = @()
			foreach ($Entry in $UserNotFound.GetEnumerator() | Sort-Object -Property Name)
			{
				# Rebuild list by Hostname,UnixName,Profile
				$Object = New-Object System.Object
				$Object | Add-Member -MemberType NoteProperty -Name Hostname -Value $Entry.Key.Split("@")[1]
				$Object | Add-Member -MemberType NoteProperty -Name UnixName -Value $Entry.Key.Split("@")[0]
				$Object | Add-Member -MemberType NoteProperty -Name Profile -Value $Entry.Value
				$UsersNotFound += $Object
			}
			# Dump Array to Log grouping by Hostnam and Sorting by UnixName
			[System.String]$log = ("### Users not found log ###`nLast run: {1}" -f $Name, [System.DateTime]::Now)
			foreach ($Source in $UsersNotFound | Select-Object -Property Hostname -Unique | Sort-Object -Property HostName)
			{
				# Add source to log
				$log += ("`n`nSource: {0}" -f $Source.Hostname)
				foreach ($Entry in $UsersNotFound | Where-Object { $_.Hostname -eq $Source.Hostname } | Sort-Object -Property UnixName)
				{
					# Add entry to log
					$log += ("`n{0}" -f $Entry.Profile)
				}
			}
			$log | Set-Content "../analysis/UsersNotFound.log"
			Write-Host ("`n{0} entries added to UsersNotFound.log" -f $UsersNotFound.Count)
			Write-Host ("{0} Users not found in AD!" -f ($UsersNotFound | Select-Object -Property UnixName -Unique).Count) -ForegroundColor Yellow
		}
		
		$nbCollisions = Dump-Log -Name "Users by Name" -LogFile "../analysis/UsersByName.log" -Table $UsersByName
		Write-Host ("`n{0} entries added to UsersByName.log" -f $UsersByName.Count)
		if ($nbCollisions)
		{
			Write-Host ("{0} collisions detected!" -f $nbCollisions) -ForegroundColor Yellow
		}
		else
		{
			Write-Host "No collisions detected."
		}
		
		$nbCollisions = Dump-Log -Name "Users by UID" -LogFile "../analysis/UsersByUID.log" -Table $UsersByUID
		Write-Host ("`n{0} entries added to UsersByUID.log" -f $UsersByUID.Count)
		if ($nbCollisions)
		{
			Write-Host ("{0} collisions detected!" -f $nbCollisions) -ForegroundColor Yellow
		}
		else
		{
			Write-Host "No collisions detected."
		}

		$nbCollisions = Dump-Log -Name "Users by GID" -LogFile "../analysis/UsersByGID.log" -Table $UsersByGID
		Write-Host ("`n{0} entries added to UsersByGID.log" -f $UsersByGID.Count)
		if ($nbCollisions)
		{
			Write-Host ("{0} collisions detected!" -f $nbCollisions) -ForegroundColor Yellow
		}
		else
		{
			Write-Host "No collisions detected."
		}

		Write-Host "`nUser analysis logs written under ./analysis folder.`n"
		# Print Elapsed time
		[System.TimeSpan]$ElapsedTime = [System.DateTime]::Now - $StartingTime
		Write-Host ("Runtime: {0:D2}h{1:D2}m{2:D2}s.`n" -f $ElapsedTime.Hours, $ElapsedTime.Minutes, $ElapsedTime.Seconds)
	}
	else
	{
		Throw ("Unable to find any import data file in path {0}. Copy data files in import path before to run this script again " -f $Path)
	}
}
else
{
	Throw ("Unable to find '{0}' for Import data files. Create the path and copy data files in it before to run this script again." -f $Path)
}
# All Done.