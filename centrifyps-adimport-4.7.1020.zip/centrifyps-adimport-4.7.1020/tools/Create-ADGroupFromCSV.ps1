###########################################################################################
# CREATE AD GROUP FROM CSV File
#
# Author : Fabrice Viguier
# Contact: fabrice.viguier AT centrify.com
# Release: 02/10/2014
# Version: 1.0.102   First release, Generate AD Groups from a CSV for using with ADImport (Role Assignments)
###########################################################################################

Param
(
	[Parameter(Mandatory = $false, HelpMessage = "Specify the AD Domain name where perform actions in FQDN format (e.g. company.com).")]
	[Alias("d")]
	[System.String]$Domain = [DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain().Name,

	[Parameter(Mandatory = $false, HelpMessage = "Specify the PSCredential of an AD User to perform actions on AD (e.g. (Get-Credential NTDOMAIN\Administrator)).")]
	[Management.Automation.PSCredential]$Credential, 

	[Parameter(Mandatory = $false, HelpMessage = "Specify Domain Controller name to connect.")]
	[Alias("s")]
	[System.String]$Server,

	[Parameter(Position = 0, Mandatory = $true, HelpMessage = "Specify the CSV File to create AD Groups.")]
	[Alias("g")]
	[System.String]$Groups
)

###########################################################################################
# ADImport - New-ADSecurityGroup
#
# Create AD Security Group in the given Container and return the DirectoryEntry object Path 
########
function New-ADSecurityGroup
{
	#######################################################################################
    param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "Specify the Name of the security group to create.")]
		[Alias("n")]
		[System.String]$Name,
		
		[Parameter(Position = 1, Mandatory = $true, HelpMessage = "Specify the Container where create the security group.")]
		[Alias("c")]
		[System.String]$Container,

		[Parameter(Position = 2, Mandatory = $true, HelpMessage = "Specify the group type of the security group (default value is Global).")]
		[Alias("t")]
		[System.String]$groupType = "Global"
	)
	#######################################################################################
	try
	{
		# Connect to Container into AD
		[System.String]$strContainerPath = Get-ADsPath $Container
		[DirectoryServices.DirectoryEntry]$dseContainer = New-Object System.DirectoryServices.DirectoryEntry($strContainerPath)
		if ($dseContainer.distinguishedName -ne [Void]$null)
		{
			[System.String]$strSecurityGroupCN = ("CN={0}" -f $Name)
			# Create security group object	    
			[DirectoryServices.DirectoryEntry]$dseSecurityGroup = $dseContainer.Create("group", $strSecurityGroupCN)	    
			[Void]$dseSecurityGroup.Put("sAMAccountName", $Name)
			# Set Security Group type
			if ($groupType -eq "Global")
			{
				[Void]$dseSecurityGroup.Put("groupType", 0x80000002)
			}
			elseif ($groupType -eq "DomainLocal")
			{
				[Void]$dseSecurityGroup.Put("groupType", 0x80000004)
			}
			elseif ($groupType -eq "Universal")
			{
				[Void]$dseSecurityGroup.Put("groupType", 0x80000008)
			}
			else
			{
				# Invalid group type value
				Write-Error ("Invalid group type {0}. Possible values are 'Global', 'DomainLocal' or 'Universal'." -f $groupType)
			}
			# Commit object
			[Void]$dseSecurityGroup.SetInfo()
		}
		else
		{
			# Container not found
			Throw ("Container `"{0}`" does not exists in Domain {1}." -f $Container, $Domain)
		}
	}
	catch [System.Management.Automation.MethodInvocationException]
	{
		if ($_.Exception.Message -match "^*`"The object already exists`.`"*")
		{
			# Group already exist
			Write-Warning ("Group named {0} already exists. Skip creation." -f $name)
			# Return existing group Path
			[System.String]$strSecurityGroupPath = Get-ADsPath ("{0},{1}" -f $strSecurityGroupCN, $Container)
			return $strSecurityGroupPath
		}
		else
		{
			# unknown exception
			Throw $_.Exception
		}
	}
	catch
	{
		Throw $_.Exception
	}

	# Return Group Path
	return $dseSecurityGroup.ADsPath
}

# If CSV file is present, load data
if (Test-Path -Path $Groups)
{
	$Data = Import-Csv $Groups
	if ($Data -ne [Void]$null)
	{
		foreach ($Entry in $Data)
		{
			# Create AD Groups
			if ([System.String]::IsNullOrEmpty($Entry.GroupType))
			{
				# GroupType is not defined, create Global Security Group
				New-ADSecurityGroup -Name $Entry.Name -Container $Entry.Container
			}
			else
			{
				# Create Security Group with defined GroupType
				New-ADSecurityGroup -Name $Entry.Name -Container $Entry.Container -GroupType $Entry.GroupType
			}
		}
	}
	else
	{
		Throw "Mapping file data invalid or file empty."
	}
}
else
{
	Throw ("Can't open file {0}" -f $MappingFile)
}
# Done.