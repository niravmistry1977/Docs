###########################################################################################
# RUN GROUP MATCHING                                                                      #
# Search for UNIX Group matching into Active Directory and generate GroupMatching.csv file#
#                                                                                         #
# Author : Fabrice Viguier                                                                #
# Contact: fabrice.viguier AT centrify.com                                                #
# Release: 12/3/2012                                                                      #
# Version: 1.3.1.1001   First release, UserMatching.csv file for using with ADImport      #
#          2.0.0.0312   Fix minor bugs, add to the new set of tools                       #
###########################################################################################

#######################################################################################
# PARAMETERS                                                                          #
#######################################################################################
Param
(
	[Parameter(Mandatory = $false, HelpMessage = "Specify the Path where find Import data files (by default under '\import' folder).")]
	[Alias("p")]
	[String]$Path = "..\import",

	[Parameter(Mandatory = $false, HelpMessage = "Specify the group ignore file to use (by default group.ignore under '\data' folder).")]
	[Alias("u")]
	[String]$GroupIgnoreFile = "..\data\group.ignore",

	[Parameter(Mandatory = $false, HelpMessage = "Force entry into matching file even if no match found in AD (SamAccountName = UnixName).")]
	[Alias("f")]
	[Switch]$Force,

	[Parameter(Mandatory = $false, HelpMessage = "Use this flag when no connection to AD is available. Force entry into matching file.")]
	[Alias("n")]
	[Switch]$NoAD
)

###
# MATCHING RULES
###
$USER_MATCHING_RULES = @(
	"(&(objectClass=group)(|(sAMAccountName=*UNIX-[LOGIN])(gid=*UNIX-[LOGIN])))",	# Group is like adm_{LOGIN}
	"(&(objectClass=group)(|(sAMAccountName=[LOGIN])(gid=[LOGIN])))"				# Group match exactly {LOGIN}
	"(&(objectClass=group)(|(gidnumber=[GID])))"									# RFC2307 attribute is {GID}
)


#######################################################################################
# FUNCTIONS                                                                           #
#######################################################################################
function Get-MatchingGroup
{
	Param
	(
		[Parameter(Mandatory = $true, HelpMessage = "Specify the passwd file entry.")]
		[Object]$UnixProfile
	)
	
	try
	{
		# Get Domain search base
		$SearchBase = ("LDAP://{0}" -f [DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain().Name)
		# Connect to current AD Domain
		$DirectoryEntry = New-Object System.DirectoryServices.DirectoryEntry($SearchBase)
		# Find the User object
		$DirectorySearcher = New-Object System.DirectoryServices.DirectorySearcher
		$DirectorySearcher.SearchRoot = $DirectoryEntry
		$DirectorySearcher.PageSize = 1000
		$DirectorySearcher.SearchScope = "subtree"
		# Execute search query
		foreach ($Rule in $USER_MATCHING_RULES)
		{
			# Build Filter
			if ($Rule -match "\[LOGIN\]") { $Filter = $Rule.Replace("[LOGIN]", $UnixProfile.name) }
			elseif ($Rule -match "\[GID\]") { $Filter = $Rule.Replace("[GID]", $UnixProfile.uid) }
			# Apply filter
			$DirectorySearcher.Filter = $Filter
			$SearchResult = $DirectorySearcher.FindOne()
			if($SearchResult -ne [Void]$null)
			{
				# Match found, return the SamAccountName value
				$Object = New-Object System.DirectoryServices.DirectoryEntry($SearchResult.Path)
				return $Object.Properties["sAMAccountName"].Value
			}
		}
		# No match found, return null
		return [Void]$null
	}
	catch
	{
		Throw
	}
}
#######################################################################################
# MAIN LOGIC                                                                          #
#######################################################################################
Try
{
	Clear-Host
	# Load user.ignore file
	if (Test-Path -Path $GroupIgnoreFile)
	{
		$GroupsToIgnore = Get-Content $GroupIgnoreFile
	}
	else
	{
		Write-Warning "Unable to load group.ignore file. All users will be processed to matching with Active Directory."
	}
	# Get data from files
	$Data = @()
	if (Test-Path -Path $Path)
	{
		$DataFiles = Get-ChildItem -Path $Path -Filter "*_Groups.txt"
		if ($DataFiles -eq [Void]$null)
		{
			Throw "Unable to find Group data file in given path. Process ended."
		}
		else
		{
			# Create the GroupMatching.log file
			$AnalysisFile = "..\data\GroupMatching.log"
			$Content = ("Active Directory User Matching`n-------------------------------`nLast run: {0}`n`n" -f [DateTime]::Now)
			$Content | Set-Content $AnalysisFile
			# Build Group Data by correlating data file
			$i = 1
			foreach ($DataFile in $DataFiles)
			{
				# Get ComputerName from DataFile name
				$ComputerName = $DataFile.Name.Split("_")[0]
				# Show data files processing progress
				if ($DataFiles.Count -eq [Void]$null) { $nbObjects = 1 }
				else { $nbObjects = $DataFiles.Count }
				$ProgressActivity	= ("Processing Computer {0} [{1}/{2}]" -f $ComputerName, $i, $nbObjects)
				$ProgressStatus		= "Percent processed: "
				$ProgressComplete	= (($i++ / $nbObjects)*100)
				Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 0
				# Process passwd file
				$Header = @("name","shadow","gid","members")
				$Content = Import-Csv $DataFile.FullName -Delimiter : -Header $Header
				if ($Content -ne [Void]$null)
				{
					# User not found in AD
					$Message = ("Processing computer '{0}'" -f $ComputerName)
					$Message | Add-Content $AnalysisFile
					# Parse content and ignore group entry in group.ignore file
					$j = 1
					foreach($Entry in $Content)
					{
						# Show groups processing progress
						if ($Content.Count -eq [Void]$null) { $nbEntries = 1 }
						else { $nbEntries = $Content.Count }
						$ProgressActivity	= ("Processing group file entries [{0}/{1}]" -f $j, $nbEntries)
						$ProgressStatus		= "Percent processed: "
						$ProgressComplete	= (($j++ / $nbEntries)*100)
						Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 1 -ParentId 0
						# Check if group exist in group.ignore file
						if ($GroupsToIgnore -notcontains $Entry.name)
						{
							if ($NoAD.IsPresent)
							{
								# No AD connection available
								$Object = New-Object System.Object
								$Object | Add-Member -MemberType NoteProperty -Name ComputerName -Value $ComputerName
								$Object | Add-Member -MemberType NoteProperty -Name UnixName -Value $Entry.name
								$Object | Add-Member -MemberType NoteProperty -Name SamAccountName -Value $Entry.name
								# Add entry to data
								$Data += $Object
								$Message = ("[ENFORCE] No AD connection available, Entry is forced by setting SamAccountName = {0}" -f $Entry.name)
								$Message | Add-Content $AnalysisFile
							}
							else
							{
								# Get User from AD
								$SamAccountName = Get-MatchingGroup -UnixProfile $Entry
								if ($SamAccountName -ne [Void]$null)
								{
									# Build data specifying the computer name
									$Object = New-Object System.Object
									$Object | Add-Member -MemberType NoteProperty -Name ComputerName -Value $ComputerName
									$Object | Add-Member -MemberType NoteProperty -Name UnixName -Value $Entry.name
									$Object | Add-Member -MemberType NoteProperty -Name SamAccountName -Value $SamAccountName
									# Add entry to data
									$Data += $Object
									# Match found in AD
									$Message = ("[SUCCESS] AD Group matching found for Group '{0}'" -f $Entry.name)
									$Message | Add-Content $AnalysisFile
								}
								else
								{
									if ($Force.IsPresent)
									{
										# Force entry into matching file
										$Object = New-Object System.Object
										$Object | Add-Member -MemberType NoteProperty -Name ComputerName -Value $ComputerName
										$Object | Add-Member -MemberType NoteProperty -Name UnixName -Value $Entry.name
										$Object | Add-Member -MemberType NoteProperty -Name SamAccountName -Value $Entry.name
										# Add entry to data
										$Data += $Object
										$Message = ("[ENFORCE] No AD Group matching found for Group '{0}', Entry is forced by setting SamAccountName = UnixName" -f $Entry.name)
										$Message | Add-Content $AnalysisFile
									}
									else
									{
										# Match not found in AD
										$Message = ("[NOMATCH] No AD Group matching found for Group '{0}'" -f $Entry.name)
										$Message | Add-Content $AnalysisFile
									}
								}
							}
						}
						else
						{
							# User exist in user.ignore file
							$Message = ("[IGNORED] Group '{0}' exist in group.ignore file. Skip matching for this entry." -f $Entry.name)
							$Message | Add-Content $AnalysisFile
						}	
					}
				}
			}
		}
	}
	else
	{
		Throw "Given path not exist or not accessible. Process ended."
	}
	# Write the UserMatching.csv file
	$Data | Export-Csv "..\data\GroupMatching.csv" -NoTypeInformation
	# Done.
	Write-Host "Group matching done."
}	
Catch
{
	Throw
}
