###########################################################################################
# RUN COMPUTER ANALYSIS
# Generate Zones folder and copy matching Users and Groups entries into Zones
#
# Author : Fabrice Viguier
# Contact: fabrice.viguier AT centrify.com
# Release: 13/11/2012
# Version: 1.3.0.1311   First release, Generate Zone Data for using with ADImport
#          1.3.1.1001   Fix bugs, add ability to create the entire data structure
#          2.0.0.0312   Fix minor bugs, add to the new set of tools
#          3.7.1206     Fix tools scripts to match new CSF file format and data structure.
###########################################################################################

#######################################################################################
# PARAMETERS                                                                          #
#######################################################################################
Param
(
	[Parameter(Mandatory = $false, HelpMessage = "Specify the Path where find Import data files (by default under '\import' folder).")]
	[Alias("p")]
	[String]$Path = "..\import",

	[Parameter(Mandatory = $false, HelpMessage = "Specify the Computer list file to use (by default ComputerList.csv under '\data' folder).")]
	[Alias("c")]
	[String]$ComputerList = "..\data\Computers.csv",
	
	[Parameter(Mandatory = $false, HelpMessage = "Specify the User Matching file to use (by default UserMatching.csv under '\data' folder).")]
	[Alias("u")]
	[String]$UserMatchingFile = "..\data\UserMatching.csv",

	[Parameter(Mandatory = $false, HelpMessage = "Specify the Group Matching file to use (by default GroupMatching.csv under '\data' folder).")]
	[Alias("g")]
	[String]$GroupMatchingFile = "..\data\GroupMatching.csv"
)

#######################################################################################
# FUNCTIONS                                                                           #
#######################################################################################
function Copy-MatchingEntries
{
	Param
	(
		[Parameter(Position = 0, Mandatory = $true, HelpMessage = "Specify the file to copy.")]
		[String]$File,

		[Parameter(Mandatory = $false, HelpMessage = "Specify the destination file to create.")]
		[String]$Output,
		
		[Parameter(Mandatory = $false, HelpMessage = "Specify the Computer Name.")]
		[String]$Computer,
		
		[Parameter(Mandatory = $false, HelpMessage = "Specify the Filter file to use.")]
		[String]$Filter
	)
	
	$nbMatchs = 0
	$MatchingData = Import-Csv $Filter | Where-Object { ($_.ComputerName -eq $Computer) -or ($_.ComputerName -eq "*") }
	if ($MatchingData -ne [Void]$null)
	{
		$UnixData = @()
		# Extract data from import file
		if ($File -match "^*_Users.txt$")
		{
			# Data are User profiles
			$DataType = "User"
			$Header = @("name","shadow","uid","gid","gecos","home","shell")
			$ID = 3
		}
		else
		{
			# Data are Group profiles
			$DataType = "Group"
			$Header = @("name","shadow","gid","members")
			$ID = 4
		}
		$Data = Import-Csv $File -Delimiter : -Header $Header
#		$i = 0
		foreach ($Entry in $Data)
		{
			if($Data.Count -eq [Void]$null) { $nbEntries = 1 }
			else { $nbEntries = $Data.Count }
#			# Show user profiles processing progress
#			$ProgressActivity	= ("Processing {0} profiles [{1}/{2}]" -f $DataType, $i, $nbEntries)
#			$ProgressStatus		= "Percent processed: "
#			$ProgressComplete	= (($i++ / $nbEntries)*100)
#			Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id $ID -ParentId 2
			# Search for UnixName into Matching Data
			$Match = $MatchingData | Where-Object { $_.UnixName -eq $Entry.name }
			if ($Match -ne [Void]$null)
			{
				if (($Match.GetType()).BaseType -eq [System.Array])
				{
					# Multiple Match found for the same UnixName
					Write-Warning ("Multiple matching profiles found for {0} entry {1} onto computer {2}. Need to be resolved manually." -f $DataType, $Entry.name, $Computer)
				}
				else
				{
					# One Match found, add to output data
					$nbMatchs++
					# Build Output Data
					if ($DataType -eq "User")
					{
						# Build User Data			
						$Object = New-Object System.Object
						$Object | Add-Member -MemberType NoteProperty -Name Zone -Value $Computer
						$Object | Add-Member -MemberType NoteProperty -Name User -Value $Match.SamAccountName
						$Object | Add-Member -MemberType NoteProperty -Name UnixName -Value $Entry.name
						$Object | Add-Member -MemberType NoteProperty -Name UID -Value $Entry.uid
						$Object | Add-Member -MemberType NoteProperty -Name GID -Value $Entry.gid
						$Object | Add-Member -MemberType NoteProperty -Name Gecos -Value $Entry.gecos
						$Object | Add-Member -MemberType NoteProperty -Name Home -Value $Entry.home
						$Object | Add-Member -MemberType NoteProperty -Name Shell -Value $Entry.shell
					}
					else
					{
						# Build Group Data			
						$Object = New-Object System.Object
						$Object | Add-Member -MemberType NoteProperty -Name Zone -Value $Computer
						$Object | Add-Member -MemberType NoteProperty -Name Group -Value $Match.SamAccountName
						$Object | Add-Member -MemberType NoteProperty -Name UnixName -Value $Entry.name
						$Object | Add-Member -MemberType NoteProperty -Name GID -Value $Entry.gid
						$Object | Add-Member -MemberType NoteProperty -Name Members -Value $Entry.members
					}
					if (-not ($UnixData | Where-Object { $_ -eq $Object}))
					{
						# Add entry to UNIX Data
						$UnixData += $Object
					}
				}
			}
		}
		# Commit UNIX Data file
		$UnixData | Export-Csv $Output -NoTypeInformation
	}
	# Return matching data count
	return $nbMatchs
}

#######################################################################################
# MAIN LOGIC                                                                          #
#######################################################################################
Try
{
	Clear-Host
	# Get Zone list
	if (Test-Path -Path $ComputerList)
	{
		$Zones = Import-Csv $ComputerList | Select-Object -Property Zone -Unique
		if ($Zones -eq [Void]$null)
		{
			Throw "Computer file corrupted or empty. Process ended."
		}
	}
	else
	{
		Throw "Unable to find computer list. Process ended."
	}
	# Process list of Zones
	$i = 1
	foreach ($Item in $Zones)
	{
		# Show data files processing progress
		if ($Zones.Count -eq [Void]$null) { $nbZones = 1 }
		else { $nbZones = $Zones.Count }
		$ProgressActivity	= ("Processing Zone {0} [{1}/{2}]" -f $Item.Zone, $i, $nbZones)
		$ProgressStatus		= "Percent processed: "
		$ProgressComplete	= (($i++ / $nbZones)*100)
		Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 1
		# Extract data
		$ZoneName = $Item.Zone
		# Create the Zone Data structure
		if (-not (Test-Path -Path ("..\{0}" -f $Item.Zone)))
		{
			# Zone folder
			[Void](New-Item ("..\{0}" -f $Item.Zone) -ItemType Directory)
		}
		if (-not (Test-Path -Path ("..\{0}\import" -f $Item.Zone)))
		{
			# Import data
			[Void](New-Item ("..\{0}\import" -f $Item.Zone) -ItemType Directory)
		}
		if (-not (Test-Path -Path ("..\{0}\analysis" -f $Item.Zone)))
		{
			# Analysis log
			[Void](New-Item ("..\{0}\analysis" -f $Item.Zone) -ItemType Directory)
		}
		# Write the Computer data analysis
		$AnalysisFile = ("..\{0}\analysis\Computers.log" -f $Item.Zone)
		$Content = ("Computer Data Analysis`n-----------------------`nLast run: {0}`n`n" -f [DateTime]::Now)
		$Content | Set-Content $AnalysisFile
		# Extract list of Computers for this Zone
		$Computers = Import-Csv $ComputerList | Where-Object { $_.Zone -eq $Item.Zone }
		# Process list of Computers
		$j = 1
		foreach ($Computer in $Computers)
		{
			# Show data files processing progress
			if ($Computers.Count -eq [Void]$null) { $nbComputers = 1 }
			else { $nbComputers = $Computers.Count }
			$ProgressActivity	= ("Processing Computer {0} [{1}/{2}]" -f $Computer.Hostname, $j, $nbComputers)
			$ProgressStatus		= "Percent processed: "
			$ProgressComplete	= (($j++ / $nbComputers)*100)
			Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 2 -ParentId 1
			# Write Computer list
			$OutputFile = ("..\{0}\Computers.csv" -f $Item.Zone)
			if (-not (Test-Path -Path $OutputFile))
			{
				# Create file
				"Hostname,Zone,Container" | Set-Content $OutputFile
			}
			if (-not (Import-Csv $OutputFile | Where-Object { $_.Hostname -eq $ComputerName}))
			{
				# Add entry to file
				$Entry = ("`"{0}`",`"{1}`",`"{2}`"" -f $Computer.Hostname, $Item.Zone, $Computer.Container)
				if ((Get-Content $OutputFile) -notcontains $Entry)
				{
					$Entry  | Add-Content $OutputFile
				}
			}
			# Parse Unix User data files
			if (Test-Path -Path $UserMatchingFile)
			{
				$UserFile = ("..\import\{0}_Users.txt" -f $Computer.Hostname)
				if (Test-Path -Path $UserFile)
				{
					$OutputFile = "..\{0}\import\{1}_Users.csv" -f $Item.Zone, $Computer.Hostname
					# Filter User entries using matching values 
					$nbMatchs = Copy-MatchingEntries -File $UserFile -Output $OutputFile -Computer $Computer.Hostname -Filter $UserMatchingFile
					if($nbMatchs -gt 0)
					{
						("{0} matching User(s) found for computer {1}" -f $nbMatchs, $Computer.Hostname) | Add-Content $AnalysisFile
					}
					else
					{
						("No matching Users found for computer {0}" -f $Computer.Hostname) | Add-Content $AnalysisFile
					}
				}
				else
				{
					$message = ("No User data found for computer {0}" -f $Computer.Hostname)
					$message | Add-Content $AnalysisFile
					Write-Warning $message
				}
			}
			else
			{
				Write-Warning "Unable to find User matching file. Skip User data."
			}
			# Parse Unix Group data files
			if (Test-Path -Path $GroupMatchingFile)
			{
				$GroupFile = ("..\import\{0}_Groups.txt" -f $Computer.Hostname)
				if (Test-Path -Path $GroupFile)
				{
					$OutputFile = "..\{0}\import\{1}_Groups.csv" -f $Item.Zone, $Computer.Hostname
					# Filter Group entries using matching values 
					$nbMatchs = Copy-MatchingEntries -File $GroupFile -Output $OutputFile -Computer $Computer.Hostname -Filter $GroupMatchingFile
					if($nbMatchs -gt 0)
					{
						("{0} matching Group(s) found for computer {1}" -f $nbMatchs, $Computer.Hostname) | Add-Content $AnalysisFile
					}
					else
					{
						("No matching Groups found for computer {0}" -f $Computer.Hostname) | Add-Content $AnalysisFile
					}
				}
				else
				{
					$message = ("No Group data found for computer {0}" -f $Computer.Hostname)
					$message | Add-Content $AnalysisFile
					Write-Warning $message
				}
			}
			else
			{
				Write-Warning "Unable to find Group matching file. Skip Group data."
			}
		}
	}
	# Done.
	Write-Host "Computer analysis done."
}	
Catch
{
	Throw
}
