###########################################################################################
# GENERATE USER DATA FILES                                                                #
#                                                                                         #
# Author : Fabrice Viguier                                                                #
# Contact: fabrice.viguier AT centrify.com                                                #
# Release: 03/08/2012                                                                     #
# Version: 1.0.0.0803   First release, Generate UNIXData files for using with ADImport    #
#          1.0.1.0806   Script optimized to process User data files                       #
###########################################################################################

#######################################################################################
# PARAMETERS                                                                          #
#######################################################################################
Param
(
	[Parameter(Mandatory = $true, HelpMessage = "Specify the Path where find data files to rename.")]
	[Alias("i")]
	[Alias("input")]
	[String]$Path,
	
	[Parameter(Mandatory = $false, ValueFromPipelineByPropertyName = $true, HelpMessage = "Specify the Path where put renamed data files.")]
	[Alias("o")]
	[String]$Output = "..\import",
	
	[Parameter(Mandatory = $false, ValueFromPipelineByPropertyName = $true, HelpMessage = "Convert EOL to Windows format.")]
	[Switch]$ConvertEOL
)

#######################################################################################
# INITIATE PIPELINE                                                                   #
#######################################################################################
Begin
{
	Try
	{
		# Load import data
		if(Test-Path -Path $Path)
		{
			$DataFileList = Get-ChildItem -Path $Path
			if($DataFileList -eq [Void]$null)
			{
				Throw ("Unable to find any import data file in path {0}. Process ended." -f $Path)
			}
		}
		else
		{
			Throw "Unable to find path for Import data files. Process ended."
		}
	}
	Catch
	{
		$ExceptionCaught = $true
		Write-Error $_.Exception
	}
}
#######################################################################################
# SCRIPT BLOCK                                                                        #
#######################################################################################
Process
{
	Try
	{
		# Process list of data files
		$i = 1
		foreach($DataFile in $DataFileList)
		{
			# Show data files processing progress
			Write-Progress -Activity "Processing data files" -Status "Percent processed: " -PercentComplete (($i++ / $DataFileList.Count)*100) -Id 1
			# Extract Values
			$DataType = $DataFile.Name.Split(".")[($DataFile.Name.Split(".")).Count - 1 ]		##### IMPORTANT: change the matching value if needed #####
			$ComputerName = $DataFile.Name.Split(".")[0]										##### IMPORTANT: change the matching value if needed #####
			# Rename data file regarding the data type
			if($DataType -eq "passwd")		##### IMPORTANT: change the matching value if needed #####
			{
				# Process User data file
				$OutputFileName = ("{0}_Users.txt" -f $ComputerName.ToLower())
			}
			elseif($DataType -eq "group")	##### IMPORTANT: change the matching value if needed #####
			{
				# Process Group data file
				$OutputFileName = ("{0}_Groups.txt" -f $ComputerName.ToLower())
			}
			else
			{
				Write-Warning ("Unknown data type {0}. Skip file {1}." -f $DataType, $DataFile.Name)
			}
			# Write the output data file
			if(-not [String]::IsNullOrEmpty($OutputFileName))
			{
				Write-Verbose ("Copying file {0}" -f $OutputFileName)
				$OutputFile = ("{0}\{1}" -f $Output, $OutputFileName)
				if($ConvertEOL.IsPresent)
				{
					# Convert Unix format to Windows format by changing EOL from LF to CRLF
					$Data = Get-Content $DataFile.PSPath
					$ConvertedData = @()
					foreach($Line in $Data)
					{
						$ConvertedData += $Line.Replace("`n", "`r`n")
					}
					$ConvertedData | Set-Content $OutputFile
				}
				else
				{
					# Just copy file
					Copy-Item $DataFile.PSPath -Destination $OutputFile
				}
			}
		}
		# Done.
	}	
	Catch
	{
		$ExceptionCaught = $true
		Write-Error $_.Exception
	}
}
#######################################################################################
# RETURN RESULTS                                                                      #
#######################################################################################
End
{
	Try
	{
		# Nothing to do here
	}
	Catch
	{
		$ExceptionCaught = $true
		Write-Error $_.Exception
	}	
	if(-not $ExceptionCaught)
	{
		Write-Verbose "User data files generated."
	}
	return [Void]$null
}