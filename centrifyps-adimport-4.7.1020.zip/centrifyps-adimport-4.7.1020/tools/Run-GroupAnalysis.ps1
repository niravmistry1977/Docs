###########################################################################################
# RUN GROUP ANALYSIS
# Analyse UnixName and GID collisions and generate Group Data files to be imported into AD
#
# Author : Fabrice Viguier
# Contact: fabrice.viguier AT centrify.com
# Release: 03/08/2012
# Version: 1.1.0.0803   First release, Generate UNIXData files for using with ADImport
#          1.1.1.0806   Script optimized to process User data files
#          1.3.1.1001   Fix bug in analysis mechanism and UID collision detection
#          2.0.0.0312   Improv log ouput, fix bugs, add to the new set of tools
#          3.7.1206     Fix tools scripts to match new CSF file format and data structure.
###########################################################################################

#######################################################################################
# PARAMETERS                                                                          #
#######################################################################################
Param
(
	[Parameter(Position = 0, Mandatory = $false, HelpMessage = "Specify Centrify Zone to process (if not specified, process all found Zones under ADImport folder).")]
	[Alias("z")]
	[String]$Zone
)

#######################################################################################
# MAIN LOGIC                                                                          #
#######################################################################################
Try
{
	Clear-Host
	if ([String]::IsNullOrEmpty($Zone))
	{
		# Search for all Zone folders
		$ZoneFolderList = Get-ChildItem -Path ".." -Filter "*" | Where-Object { ($_.Mode -eq "d----") -and ($_.Name -notmatch "^(_Archives|data|import|tools)$")  
		if ($ZoneFolderList -ne [Void]$null)
		{
			$ZoneList = @()
			foreach ($ZoneFolder in $ZoneFolderList)
			{
				# Add Zone name to ZoneList
				$ZoneList += $ZoneFolder.Name
			}
		}
		else
		{
			Throw "Unable to find any Zone Folder in ADImport folder. Process ended"
		}
	}
	else
	{
		# Process only Zone given in parameter
		$ZoneList = $Zone
	}
	$i = 1
	foreach ($ZoneName in $ZoneList)
	{		
		# Show data files processing progress
		if ($ZoneList.Count -eq [Void]$null) { $nbZones = 1 }
		else { $nbZones = $ZoneList.Count }
		$ProgressActivity	= ("Processing Zone {0} [{1}/{2}]" -f $ZoneName, $i, $nbZones)
		$ProgressStatus		= "Percent processed: "
		$ProgressComplete	= (($i++ / $nbZones)*100)
		Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 0
		# Load import data
		$Data = @()
		$Path = ("..\{0}\import" -f $ZoneName)
		if (Test-Path -Path $Path)
		{
			$DataFileList = Get-ChildItem -Path $Path -Filter "*_Groups.csv"
			if ($DataFileList -ne [Void]$null)
			{
				# Correlate data
				foreach ($DataFile in $DataFileList)
				{
					$Data += Import-Csv $DataFile.FullName
				}
			}
			else
			{
				Write-Warning ("Unable to find any import data file in path {0}. Skip Zone {1}." -f $Path, $ZoneName)
			}
		}
		else
		{
			Write-Warning ("Unable to find path for Import data files. Skip Zone {1}." -f $Path, $ZoneName)
		}
		if ($Data -ne [Void]$null)
		{
			# Set Data values
			$ZoneData = @()
			$ComputersData = $Data
			$CollisionedData = @()
			
			#####
			# ANALYSE GROUP COLLISIONS AT ZONE LEVEL
			# Determine Group best profile (Zone Data), others profiles are considered exceptions (Computers Data)
			#####	
			# Create the User_Collisions data analysis
			$AnalysisFile = ("..\{0}\analysis\Groups.log" -f $ZoneName)
			$Content = ("Group Preferred Profiles Analysis`n--------------------------------------`nLast run: {0}`n`n" -f [DateTime]::Now)
			$Content | Set-Content $AnalysisFile
			# Get unique AD Group list
			$ADGroupList = $Data | Select-Object -Property Group -Unique
			$j = 1
			foreach ($Item.Group in $ADGroupList)
			{
				# Show data files processing progress
				if ($ADGroupList.Count -eq [Void]$null) { $nbGroups = 1 }
				else { $nbGroups = $ADGroupList.Count }
				$ProgressActivity	= ("Processing User {0} [{1}/{2}]" -f $Item.Group, $j, $nbGroups)
				$ProgressStatus		= "Percent processed: "
				$ProgressComplete	= (($j++ / $nbGroups)*100)
				Write-Progress -Activity $ProgressActivity -Status $ProgressStatus -PercentComplete $ProgressComplete -Id 1 -ParentId 0
				# Get UnixName values for this Group
				$Entries = $Data | Where-Object { $_.Group -eq $Item.Group } | Select-Object -Property UnixName , GID , Members -Unique
				if (($Entries -ne [Void]$null))
				{
					$GroupProfiles = @()
					if (($Entries.Count -gt 1))
					{
						# Multiple values found for Group
						foreach ($Entry in $Entries)
						{
							# Count occurence of each Profile
							$Profiles = $Data | Where-Object { ($_.Group -eq $Item.Group) -and ($_.UnixName -eq $Entry.UnixName) -and ($_.GID -eq $Entry.GID) -and ($_.Members -eq $Entry.Members) }
							# Build Profile List			
							$Object = New-Object System.Object
							$Object | Add-Member -MemberType NoteProperty -Name Profile -Value $Entry
							$Object | Add-Member -MemberType NoteProperty -Name Rank -Value $Profiles.Count
							# Add data to list of Profiles
							$GroupProfiles += $Object
						}
						# Sort profiles
						$GroupProfiles = $GroupProfiles | Sort-Object -Property Rank -Descending
					}
					else
					{
						# Unique value found for Group
						$Profiles = $Data | Where-Object { ($_.Group -eq $Item.Group) -and ($_.UnixName -eq $Entries.UnixName) -and ($_.GID -eq $Entries.GID) -and ($_.Members -eq $Entries.Members) }
						# Build Profile List			
						$Object = New-Object System.Object
						$Object | Add-Member -MemberType NoteProperty -Name Profile -Value $Entries
						$Object | Add-Member -MemberType NoteProperty -Name Rank -Value $Profiles.Count
						# Add data to list of Profiles
						$GroupProfiles += $Object
					}
					# Determine if there is a best profile
					if (($GroupProfiles[0].Rank -gt 1) -and ($GroupProfiles[0].Rank -ne $GroupProfiles[1].Rank))
					{
						# User Profile exist on more than 1 computer
						$Rank = $GroupProfiles[0].Rank
						# Build Best Profile
						$Object = New-Object System.Object
						$Object | Add-Member -MemberType NoteProperty -Name Zone -Value $ZoneName
						$Object | Add-Member -MemberType NoteProperty -Name Group -Value $Item.Group
						$Object | Add-Member -MemberType NoteProperty -Name UnixName -Value $GroupProfiles[0].Profile.UnixName
						$Object | Add-Member -MemberType NoteProperty -Name GID -Value $GroupProfiles[0].Profile.GID
						$Object | Add-Member -MemberType NoteProperty -Name Members -Value $GroupProfiles[0].Profile.Members
						# Add Best Profile to Zone Data				
						$ZoneData += $Object
						# Remove Best Profile from ComputersData				
						$ComputersData = $ComputersData | Where-Object { -not (($_.UnixName -eq $Object.UnixName) -and ($_.GID -eq $Object.GID) -and ($_.Members -eq $Object.Members)) }
						# Log result
						$Result = ("{0},{1}`n{2}:{3}:{4}`n" -f $Object.Group, $GroupProfiles[0].Rank, $Object.UnixName, $Object.GID, $Object.Members)
					}
					else
					{
						# Unable to find best profile (either there is only unique profile or the same number of best profiles)
						$Result =  ("Unable to find best profile for Group {0}`n" -f $Item.Group)
					}
					# Add Result to Analysis file
					$Result | Add-Content $AnalysisFile
				}
			}

			#####
			# ANALYSE REMAINING COLLISIONS AT ZONE LEVEL
			# Determine UnixName and GID collisions against Zone Data (among best profiles for the Zone)
			#####	
			# Create the Group_Collisions_by_UnixName data analysis
			$Collisions_by_UnixName = ("..\{0}\analysis\Group_Collisions_by_UnixName.log" -f $ZoneName)
			$Content = ("Group Collisions by UnixName Analysis`n--------------------------------------`nLast run: {0}`n`n" -f [DateTime]::Now)
			$Content | Set-Content $Collisions_by_UnixName
			# Get unique AD Group list
			$UnixNameList = $ZoneData | Select-Object -Property UnixName -Unique
			foreach ($Item.UnixName in $UnixNameList)
			{
				# Get Group values for this UnixName
				$Entries = $ZoneData | Where-Object { $_.UnixName -eq $Item.UnixName } | Select-Object -Property Group -Unique
				if ($Entries.Count -gt 1)
				{
					# Multiple values found for User
					$Collisions = ("{0},{1}`n" -f $Item.UnixName, $Entries.Count)
					foreach ($Entry in $Entries)
					{
						# Search Profile on each Computer
						$Computers = [String]::Empty
						$Profiles = $Data | Where-Object { ($_.UnixName -eq $Item.UnixName) -and ($_.Group -eq $Entry.Group) }
						foreach ($Value in $Profiles)
						{
							# Build Collisioned Profile
							$Object = New-Object System.Object
							$Object | Add-Member -MemberType NoteProperty -Name Zone -Value $Value.Hostname
							$Object | Add-Member -MemberType NoteProperty -Name Group -Value $Value.Group
							$Object | Add-Member -MemberType NoteProperty -Name UnixName -Value $Value.UnixName
							$Object | Add-Member -MemberType NoteProperty -Name GID -Value $Value.GID
							$Object | Add-Member -MemberType NoteProperty -Name Members -Value $Value.Members
							# Add Collisioned Profile to Collisioned Data
							$CollisionedData += $Object
							# Build list of Computers for this Profile
							if ([String]::IsNullOrEmpty($Computers))
							{
								# First computer in the list
								$Computers = $Value.Hostname
							}
							else
							{
								# Add computer to the list
								$Computers += (",{0}" -f $Value.Hostname)
							}
						}
						# Add entry to Collisions list
						$Collisions += ("{0}`t({1})`n" -f $Entry.Group, $Computers)
					}
					# Add collisions to Analysis file
					$Collisions | Add-Content $Collisions_by_UnixName
				}
			}	

			# Create the Group_Collisions_by_GID data analysis
			$Collisions_by_GID = ("..\{0}\analysis\Group_Collisions_by_GID.log" -f $ZoneName)
			$Content = ("Group Collisions by GID Analysis`n---------------------------------`nLast run: {0}`n`n" -f [DateTime]::Now)
			$Content | Set-Content $Collisions_by_GID
			# Get unique GID list
			$GIDList = $ZoneData | Select-Object -Property GID -Unique
			foreach ($Item.GID in $GIDList)
			{
				# Get GID values for this Group
				$Entries = $ZoneData | Where-Object { ($_.GID -eq $Item.GID) } | Select-Object -Property Group -Unique
				if ($Entries.Count -gt 1)
				{
					# Multiple values found for Group
					$Collisions = ("{0},{1}`n" -f $Item.GID, $Entries.Count)
					foreach ($Entry in $Entries)
					{
						# Search Profile on each Computer
						$Computers = [String]::Empty
						$Profiles = $Data | Where-Object { ($_.GID -eq $Item.GID) -and ($_.Group -eq $Entry.Group) }
						foreach ($Value in $Profiles)
						{
							# Build Collisioned Profile
							$Object = New-Object System.Object
							$Object | Add-Member -MemberType NoteProperty -Name Zone -Value $Value.Hostname
							$Object | Add-Member -MemberType NoteProperty -Name Group -Value $Value.Group
							$Object | Add-Member -MemberType NoteProperty -Name UnixName -Value $Value.UnixName
							$Object | Add-Member -MemberType NoteProperty -Name GID -Value $Value.GID
							$Object | Add-Member -MemberType NoteProperty -Name Members -Value $Value.Members
							# Add Collisioned Profile to Collisioned data
							$CollisionedData += $Object
							# Build list of Computers for this Profile
							if ([String]::IsNullOrEmpty($Computers))
							{
								# First computer in the list
								$Computers = $Value.Hostname
							}
							else
							{
								# Add computer to the list
								$Computers += (",{0}" -f $Value.Hostname)
							}
						}
						# Add entry to Collisions list
						$Collisions += ("{0}`t({1})`n" -f $Entry.Group, $Computers)
					}
					# Add collisions to Analysis file
					$Collisions | Add-Content $Collisions_by_GID
				}
			}	

			# Remove Collision from Zone data
			foreach ($Collision in $CollisionedData)
			{
				$ZoneData = $ZoneData | Where-Object { -not (($_.Group -eq $Collision.Group) -and (($_.UnixName -eq $Collision.UnixName) -or ($_.GID -eq $Collision.GID) -or ($_.Members -eq $Collision.Members))) }
			}
			
			# Add Collisioned Data if not already exist in Computers data
			foreach ($Collision in $CollisionedData)
			{
				$CollisionExist = $ComputersData | Where-Object { $_ -eq $Collision }
				if (-not $CollisionExist)
				{
					$ComputersData += $Collision
				}
			}
			# Commit UNIX Groups data file
			$UNIXGroupsDataFile = ("..\{0}\UNIXData-Groups.csv" -f $ZoneName)
			$ZoneData + $ComputersData | Sort-Object -Property Zone , Group | Export-Csv $UNIXGroupsDataFile -NoTypeInformation
		}
	}
	# Done.
	Write-Host "Group analysis done."
}
Catch
{
	$ExceptionCaught = $true
	Write-Error $_.Exception
}