package CSPM_CLIENT_WIN;

use strict;
use warnings;
require Exporter;

our @ISA    = qw(Exporter);
our @EXPORT = qw($EXEC $PROJECT_HOME $GETCR);

my $PROJECT_HOME="c:\cspm\cloakware\cspmclient\bin";
our $EXEC="$PROJECT_HOME\cspmclient.exe ";

$GETCR  = qq{$EXEC };

__END__
