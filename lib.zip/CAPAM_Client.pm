package CAPAM_Client;

use strict;
use warnings;
require Exporter;

our @ISA    = qw(Exporter);
our @EXPORT = qw($GETCR);

my $HOME;
if (defined($ENV{'CSPM_CLIENT_HOME'})) {
	$HOME=$ENV{'CSPM_CLIENT_HOME'};
} else {
	$HOME="c:\cspm\cloakware";
}
my $EXEC="$HOME\\cspmclient\\bin\\cspmclient.exe ";

our $GETCR  = qq{$EXEC };

__END__
